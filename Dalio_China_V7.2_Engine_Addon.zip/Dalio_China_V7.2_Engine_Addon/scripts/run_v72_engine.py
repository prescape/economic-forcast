
from engine.alpha import rank_assets
from engine.dalio_regime import score_regime

print(score_regime({
    'growth':0.5,
    'credit':0.5,
    'liquidity':0.7,
    'policy':0.6,
    'inflation':0.4
}))

print(rank_assets({
    '沪深300':{'earnings_revision':0.5,'valuation':0.6,'flow':0.4},
    '科创50':{'earnings_revision':0.8,'valuation':0.2,'flow':0.9}
}))
