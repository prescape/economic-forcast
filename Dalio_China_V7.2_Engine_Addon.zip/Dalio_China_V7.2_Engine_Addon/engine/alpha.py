
WEIGHTS = {
    "earnings_revision": 0.25,
    "valuation": 0.20,
    "flow": 0.20,
    "momentum": 0.15,
    "crowding": 0.10,
    "policy_theme": 0.05,
    "macro_style": 0.05
}

def calculate_alpha(features):
    return sum(features.get(k, 0) * w for k, w in WEIGHTS.items())

def rank_assets(asset_features):
    return sorted(
        [{"asset": k, "alpha_score": calculate_alpha(v)} for k, v in asset_features.items()],
        key=lambda x: x["alpha_score"],
        reverse=True
    )
