
def allocation(regime):
    return {"Risk-On":0.8,"Neutral":0.55,"Risk-Off":0.3}.get(regime,0.5)
