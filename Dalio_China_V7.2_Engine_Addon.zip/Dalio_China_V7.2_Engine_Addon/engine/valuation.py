
def valuation_score(pe_percentile=0.5, pb_percentile=0.5):
    return (1-pe_percentile + 1-pb_percentile)/2
