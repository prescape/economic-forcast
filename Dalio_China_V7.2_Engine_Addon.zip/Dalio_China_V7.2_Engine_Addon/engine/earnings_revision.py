
def earnings_revision_score(revision_1m=0, revision_3m=0):
    return 0.4*revision_1m + 0.6*revision_3m
