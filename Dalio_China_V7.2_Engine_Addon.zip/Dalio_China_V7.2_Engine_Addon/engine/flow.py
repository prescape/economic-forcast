
def flow_score(etf_flow=0, margin_flow=0, turnover=0):
    return 0.4*etf_flow + 0.3*margin_flow + 0.3*turnover
