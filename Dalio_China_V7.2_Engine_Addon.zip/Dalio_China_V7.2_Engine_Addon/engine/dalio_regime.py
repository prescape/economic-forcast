
def score_regime(features):
    weights = {
        "growth":0.25,
        "credit":0.20,
        "liquidity":0.20,
        "policy":0.20,
        "inflation":0.15
    }
    score = sum(features.get(k,0)*v for k,v in weights.items())
    if score >= 0.6:
        regime="Risk-On"
    elif score <= 0.35:
        regime="Risk-Off"
    else:
        regime="Neutral"
    return {"score":score,"regime":regime}
