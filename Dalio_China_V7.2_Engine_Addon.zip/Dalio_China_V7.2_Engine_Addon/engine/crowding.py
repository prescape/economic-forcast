
def crowding_score(turnover=0, momentum=0, valuation=0):
    return 0.4*turnover + 0.3*momentum + 0.3*valuation
