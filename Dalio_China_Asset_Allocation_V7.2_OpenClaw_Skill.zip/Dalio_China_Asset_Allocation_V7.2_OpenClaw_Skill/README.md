# Dalio China Asset Allocation V7.2 + PIT Data Engine

这是可安装的 OpenClaw Skill 工程骨架，包含冻结版 V7.2 配置、PIT 数据结构、泄漏审计、快照构建、评分与 Walk-Forward 框架。

## 重要说明
安装包**不包含商业金融数据库的历史数据**，也不会伪造 Earnings Revision、ETF Flow 或历史估值快照。
要完成严格的 2021-01 至 2026-06 66个月回测，需要自行导入具有 Point-in-Time 属性的数据。

## 安装

OpenClaw 当前的本地 Skill 安装要求：安装源必须是一个目录，且目录根部包含 `SKILL.md`。
因此 ZIP 需要先解压，不能直接把 ZIP 路径交给 `openclaw skills install`。

### Windows PowerShell
```powershell
Expand-Archive .\Dalio_China_Asset_Allocation_V7.2_OpenClaw_Skill.zip -DestinationPath .\DalioV72
openclaw skills install .\DalioV72\Dalio_China_Asset_Allocation_V7.2_OpenClaw_Skill --as dalio-china-v7-2
openclaw skills list
```

如果修改 Skill 后当前会话未刷新，可新开会话或：
```powershell
openclaw gateway restart
```

## Python 环境
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
pip install -r requirements.txt
```

## 快速自检
```bash
python scripts/leakage_audit.py --input data/pit/example_pit.csv --as-of 2026-05-31
python scripts/build_snapshot.py --input data/pit/example_pit.csv --date 2026-05-31
python scripts/run_v72.py --snapshot data/snapshots/snapshot_20260531.csv
```

## PIT CSV 标准列
`entity,feature,observation_date,release_date,available_date,revision_date,value,source,data_quality`

`available_date` 是回测最重要的字段。

## 66个月 Walk-Forward
完整预测区间：
2021-01 到 2026-06。

为了预测 2021-01，至少需要 2020-12-31 或更早的 PIT 数据和足够的滚动历史。

```bash
python scripts/walk_forward.py \
  --input data/pit/your_pit.csv \
  --returns data/raw/next_month_returns.csv \
  --start 2021-01 \
  --end 2026-06
```

## 当前脚本定位
这是一个工程化、可扩展的研究框架。`run_v72.py` 只对已经准备好的冻结版标准化因子评分，不会凭空生成缺失的真实金融数据。
