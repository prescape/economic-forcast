import argparse
from pathlib import Path
import pandas as pd
import yaml

p = argparse.ArgumentParser()
p.add_argument("--snapshot", required=True)
p.add_argument("--config", default=str(Path(__file__).resolve().parents[1]/"config"/"model_v7_2.yaml"))
args = p.parse_args()

with open(args.config, "r", encoding="utf-8") as f:
    cfg = yaml.safe_load(f)
if not cfg.get("frozen"):
    raise SystemExit("V7.2 config must remain frozen.")

df = pd.read_csv(args.snapshot)
features = list(cfg["alpha_weights"].keys())
sub = df[df["feature"].isin(features)].copy()
sub["value"] = pd.to_numeric(sub["value"], errors="coerce")
wide = sub.pivot_table(index="entity", columns="feature", values="value", aggfunc="last")

for f in features:
    if f not in wide:
        wide[f] = float("nan")

missing = wide[features].isna().sum(axis=1)
valid = wide[missing == 0].copy()
if valid.empty:
    raise SystemExit("No entity has all frozen V7.2 alpha features. Do not impute silently.")

valid["alpha_score"] = 0.0
for f, w in cfg["alpha_weights"].items():
    valid["alpha_score"] += valid[f] * float(w)

valid = valid.sort_values("alpha_score", ascending=False)
print(valid[features + ["alpha_score"]].to_string())
