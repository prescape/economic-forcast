import argparse
from pathlib import Path
import pandas as pd

p = argparse.ArgumentParser()
p.add_argument("--input", required=True)
p.add_argument("--date", required=True)
p.add_argument("--output")
args = p.parse_args()

asof = pd.Timestamp(args.date)
df = pd.read_csv(args.input)
for c in ["observation_date","release_date","available_date","revision_date"]:
    if c in df.columns:
        df[c] = pd.to_datetime(df[c], errors="coerce")

df = df[df["available_date"] <= asof].copy()
df = df.sort_values(["entity","feature","available_date"])
snap = df.groupby(["entity","feature"], as_index=False).tail(1)

out = Path(args.output) if args.output else Path(__file__).resolve().parents[1] / "data" / "snapshots" / f"snapshot_{asof:%Y%m%d}.csv"
out.parent.mkdir(parents=True, exist_ok=True)
snap.to_csv(out, index=False)
print(out)
