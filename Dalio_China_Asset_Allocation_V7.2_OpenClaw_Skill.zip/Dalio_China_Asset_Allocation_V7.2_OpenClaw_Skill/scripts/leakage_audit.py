import argparse
import pandas as pd
import sys

p = argparse.ArgumentParser()
p.add_argument("--input", required=True)
p.add_argument("--as-of", required=True)
args = p.parse_args()

df = pd.read_csv(args.input)
required = ["entity","feature","observation_date","release_date","available_date","value","source","data_quality"]
missing = [c for c in required if c not in df.columns]
if missing:
    print("BACKTEST INVALID")
    print("Missing columns:", missing)
    sys.exit(2)

asof = pd.Timestamp(args.as_of)
for c in ["observation_date","release_date","available_date","revision_date"]:
    if c in df.columns:
        df[c] = pd.to_datetime(df[c], errors="coerce")

bad = df[df["available_date"] > asof]
if len(bad):
    print("BACKTEST INVALID")
    print(f"FUTURE DATA DETECTED: {len(bad)} rows")
    print(bad[["entity","feature","available_date"]].head(20).to_string(index=False))
    sys.exit(1)

badq = df[~df["data_quality"].isin(["A","B","C","D"])]
if len(badq):
    print("BACKTEST INVALID")
    print("Invalid data_quality values")
    sys.exit(3)

print("LEAKAGE AUDIT PASSED")
print(f"rows={len(df)}, as_of={asof.date()}")
