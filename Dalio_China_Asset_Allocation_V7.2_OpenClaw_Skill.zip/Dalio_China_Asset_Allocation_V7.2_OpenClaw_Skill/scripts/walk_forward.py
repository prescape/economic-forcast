import argparse
from pathlib import Path
import subprocess, sys
import pandas as pd

p = argparse.ArgumentParser()
p.add_argument("--input", required=True)
p.add_argument("--returns", required=False)
p.add_argument("--start", default="2021-01")
p.add_argument("--end", default="2026-06")
args = p.parse_args()

root = Path(__file__).resolve().parents[1]
months = pd.period_range(args.start, args.end, freq="M")

print(f"V7.2 frozen walk-forward plan: {len(months)} prediction months")
print("NOTE: prediction for month t uses the previous month-end snapshot.")
for target in months:
    asof = (target - 1).end_time.normalize()
    audit = [sys.executable, str(root/"scripts"/"leakage_audit.py"), "--input", args.input, "--as-of", str(asof.date())]
    r = subprocess.run(audit)
    if r.returncode != 0:
        raise SystemExit(f"Stopped at target={target}: leakage audit failed.")
    build = [sys.executable, str(root/"scripts"/"build_snapshot.py"), "--input", args.input, "--date", str(asof.date())]
    r = subprocess.run(build, capture_output=True, text=True, check=True)
    snapshot = r.stdout.strip().splitlines()[-1]
    print(f"{target}: snapshot={snapshot}")

print("Snapshots/audits completed. Evaluation requires a properly licensed next-month return file.")
