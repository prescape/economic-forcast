---
name: dalio-china-v7-2
description: 中国宏观周期、政策、流动性、市场定价与A股资产配置研究；使用PIT数据、防未来函数，并执行V7.2冻结模型。
user-invocable: true
---

# Dalio China Asset Allocation V7.2

## 定位
这是一个研究型资产配置 Skill，不是收益保证工具。核心原则：
1. 达利欧宏观框架用于识别经济/信用/通胀/流动性 Regime。
2. Cross-Section Alpha 用于指数与行业相对排序。
3. 所有历史回测必须使用 Point-in-Time (PIT) 数据。
4. 严禁未来数据、修订后数据和事后调权。
5. V7.2 权重已冻结；若要改权重，必须创建新版本，不能覆盖 V7.2 历史成绩。

## 冻结模型

### Asset Allocation / Beta Regime
- Macro / Growth: 25%
- Credit: 20%
- China Policy: 20%
- Liquidity: 20%
- Inflation / Valuation: 15%

### Cross-Section Alpha
- Earnings Revision: 25%
- Relative Valuation: 20%
- Fund Flow: 20%
- Medium-term Momentum: 15%
- Crowding / Reversal: 10%
- Policy Theme: 5%
- Dalio Macro Style: 5%

## 默认指数池
- 000300 沪深300
- 000852 中证1000
- 399006 创业板指
- 000688 科创50
- 000016 上证50
- 930740 300红利低波

## PIT 硬规则
每个特征必须至少保留：
- observation_date
- release_date
- available_date
- revision_date（如适用）
- source
- value
- data_quality

在预测日 `as_of_date`：
`available_date > as_of_date` 的任何记录均不得进入模型。

运行回测前必须先运行 `{baseDir}/scripts/leakage_audit.py`。
若审计失败，必须输出 `BACKTEST INVALID`，禁止继续报告回测绩效。

## 数据质量
- A: 官方原始数据且发布日期明确
- B: 交易所/指数公司/权威金融数据库
- C: 第三方金融数据
- D: 代理变量

主回测优先使用 A/B。C 只作为补充；D 必须明确标记为 Proxy，不能伪装成真实 Earnings Revision / Flow / Valuation。

## 工作流
1. 阅读 `{baseDir}/config/model_v7_2.yaml` 与 `universe.yaml`。
2. 抓取/导入数据到 `data/raw/`。
3. 规范化成 PIT 长表写入 `data/pit/`。
4. 运行 leakage auditor。
5. 用 `build_snapshot.py --date YYYY-MM-DD` 生成当时点快照。
6. 用 `run_v72.py` 生成冻结版评分与排名。
7. Walk-Forward 时，预测文件写入 `data/predictions/`，生成后视为锁定。
8. 用下一月真实收益仅在 evaluation 阶段评分，不得进入 feature table。

## 输出
至少输出：
- Economic Regime
- Policy / Liquidity 状态
- Risk-On / Neutral / Risk-Off
- 六指数 Alpha Ranking
- 每个指数的 Earnings Revision / Valuation / Flow / Momentum / Crowding 分项
- 数据质量与缺失项
- 主要风险
- 若是回测：Rank IC、Top-1、Top-2、Alpha、Sharpe、MDD、Calmar及Benchmark

## 禁止事项
- 不得用今天重算的历史值冒充历史当时点快照。
- 不得根据2021-2026回测结果修改V7.2权重。
- 不得把价格代理变量称为真实资金流或真实盈利预期。
- 不得把单次命中包装成模型有效。
- 不得输出保证收益、确定性涨跌或伪精确概率。
