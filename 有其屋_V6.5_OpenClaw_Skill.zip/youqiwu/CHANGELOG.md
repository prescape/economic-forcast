# CHANGELOG

## V6.5.0
- 新增 Evidence Trace Layer，贯穿数据研究、估值、IRR、BUY/HOLD/SELL 与 Pairwise。
- 新增 S/A/B/C/D Source Tier 与 VERIFIED/CORROBORATED/RECONSTRUCTED/UNVERIFIED/MODEL_ASSUMPTION/MISSING 状态。
- 新增 `scripts/evidence_trace_v65.py`，生成 Evidence ID、证据置信度、覆盖率和 Evidence Gate。
- 新增 `assets/evidence-trace-schema.json` 与 `data/evidence-source-tiers.csv`。
- Fair Value、MOS、IRR 和关键评分必须保留父证据与转换链；无证据不得输出伪精确。
- 严格 Walk-Forward 仅接受 PIT_VERIFIED；RECONSTRUCTED 仅允许 Research Gate。
- Pairwise 新增证据质量对齐原则，避免低质量标的因伪精确评分被错误选优。
- V6.4 New House Market Intelligence 与 V6.3 Pairwise 继续保留并向后兼容。


## V6.4.0
- 新增 New-House Absorption Engine：按取证批次、30/90天去化、MOI、新增供应冲击分析新房销售质量。
- 新增 Primary/Secondary Market Divergence Engine：识别“新房结构性回暖、二手仍弱”的退出风险。
- 新增 Launch & Inventory Timing Engine：判断新推/库存/选货/折扣窗口。
- 新增 `buy_hold_sell_v64.py`：对新房 BUY 增加去化、二手退出与入市时机约束；只允许降级，不允许绕过 V6.2 Gate 升级。
- V6.3 Pairwise Engine 保留并可调用上述新房指标进行解释；单盘底层决策继续优先。
- 升级输出 Schema、报告模板和调用示例。

## V6.3.0
- 新增 Pairwise Comparison Engine。
- 新增候选盘 A/B 风险调整后相对价值评分。
- 新增 BUY_NEITHER 与 NO_MATERIAL_ADVANTAGE，禁止强制二选一。
- 新增 Replacement Comparison：卖出现有房 A 换购 B，要求交易摩擦后增量 IRR 达标。
- 新增 `scripts/pairwise_comparison_v63.py` 与 `references/21-v63-pairwise-comparison-engine.md`。
- 保留 V6.2 单盘 Quant Decision Engine 作为底层约束。

# Changelog

## 6.1.0
- 基于已安装 V6.0 做向后兼容增量升级。
- 新增 Regional Data Engine：城市→区/板块→小区→具体房源。
- 新增深圳黄埔雅苑 Benchmark 与固定观察日回测协议。
- 新增 `irr_scenario.py`，强化 Bear/Base/Bull 情景 IRR。
- 新增 `buy_hold_sell.py`，强化持有物业的 SELL/TRIM/HOLD 信号。
- 新增独立 Risk Override 参考模块；保留 V6.0 原有脚本与模块兼容路径。

## 6.0.0
- 从“买入分析”升级为完整 Buy / Hold / Sell 投资决策框架。
- 新增供需与库存、现金流/IRR、流动性、卖出信号、持仓监控与决策审计。
- 强化多方法估值、安全边际、价格纪律和 Risk Override。
- 新增 `irr.py`、`liquidity.py`、`decision.py`，升级评分与输出 Schema。
- 保留 V5.0 宏观、政策、周期、城市、家庭、回测和数据质量能力。


## V6.1 Benchmark Data Pack — 2026-08-16
- Added structured Huangpuyayuan benchmark master CSV and field dictionary.
- Added source registry and initial unverified transaction seed samples.
- Added PIT observation schedule, minimum-data gate and benchmark KPI protocol.
- Added reference 19 for benchmark data collection.


## V6.1 Benchmark Data Run 2026-08-16
- Filled Huangpuyayuan phase 1-4 historical transaction seed dataset from traceable public sources.
- Added current listing/rent samples and Shenzhen/Futian market context.
- Ran first strict PIT walk-forward; full decision gate fails due missing historical rent/listing snapshots, preventing look-ahead leakage.

## V6.1 Benchmark PIT Completion — 2026-08-16
- Added `historical_listing_pit.csv`: reconstructed 2020-2024 Huangpu Yayuan listing-price history plus dated listing records.
- Added `historical_rent_pit.csv`: official district rent reference/proxies and direct Huangpu Yayuan rent evidence from 2025 onward.
- Added `walk_forward_v61_second_run.csv` with separate Research Gate vs Strict PIT Gate.
- Added `PIT_COMPLETION_REPORT.md` and `second_run_status.json`.
- No current rent/listing values are backfilled into historical observation dates.

## 6.2.0 — 有其屋 Quant Decision Engine
- 正式品牌命名为“有其屋”。
- MOS 从直接 BUY 触发器改为 BUY/STRONG_BUY CANDIDATE。
- 新增 Trend Confirmation、Cycle、Liquidity、Supply、IRR、Confidence 多重买入确认。
- 新增 `buy_hold_sell_v62.py` 与 `confidence_v62.py`。
- 新增 `20-v62-quant-decision-engine.md`。
- 对 V6.1 黄埔雅苑 5 个 Research Gate 节点执行 V6.2 replay；V6.1 的两个过早 BUY 均被确认门拦截。
- 保留全部 V6.1 Benchmark/PIT/诊断数据用于版本对照，禁止覆盖历史结果。
