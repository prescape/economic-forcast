# 有其屋 V6.5 — RealVest New House Market Intelligence

面向住宅房地产的专业投资决策 Skill。核心目标不是评价“房子好不好”，而是回答：**什么价格值得买、是否继续持有、什么时候应该卖。**

## V6.5 核心变化

- 新增 New-House Absorption Engine：按取证批次、30/90天去化、库存月数判断销售质量。
- 新增 Primary/Secondary Divergence Engine：识别新房热销但二手退出弱的结构性风险。
- 新增 Launch & Inventory Timing Engine：识别新推、库存、选货和议价窗口。
- 新增 V6.5 新房决策门与 Pairwise 扩展，新房热度不得绕过 Fair Value、IRR 和 V6.2 Gate。
- 品牌正式命名为“有其屋”。
- MOS（安全边际）由直接 BUY 触发器改为 BUY CANDIDATE。
- 新增 Trend Confirmation Gate，阻止持续下跌中的“价值陷阱式抄底”。
- 新增 Cycle / Liquidity / Supply / IRR / Confidence 多重确认。
- 新增 Confidence Score 与 DATA_INSUFFICIENT 纪律。
- 保留深圳黄埔雅苑 Benchmark、PIT 数据和 V6.1 历史诊断结果。
- 新增 V6.3 replay，用同一历史节点检查过早 BUY 是否被拦截。

## OpenClaw
推荐技能目录名：`youqiwu`。

旧 V6.1 可以保留用于版本对照；V6.5 是新版本，不应覆盖历史 Benchmark 结果。


## V6.5 新增
- Pairwise Comparison Engine：双盘候选比较。
- Replacement Comparison：卖 A 换 B 的增量 IRR 决策。
- 支持 BUY_NEITHER / NO_MATERIAL_ADVANTAGE / HOLD_A。
- 相对评分不覆盖 V6.2 独立 BUY/HOLD/SELL Gate。


## V6.5 Evidence Trace
关键事实与模型输出均应可追溯到 Evidence ID。核心数据使用 S/A/B/C/D 来源等级、PIT 状态与验证状态；模型假设必须显式标记。证据质量不足时禁止高置信度 BUY/SELL。
