# Real Estate Investment Decision Agent V5.0

这是一个符合 OpenClaw / Agent Skills 目录规范的房地产投资决策 Skill 包。

## 安装

将整个 `real-estate-investment-decision-v5` 文件夹复制到 OpenClaw 的技能目录，确保父目录名与 `SKILL.md` 中的 `name` 一致。推荐将目录改名为：

```text
real-estate-investment-decision
```

## 目录

- `SKILL.md`：主路由与执行流程
- `references/`：七大引擎和数据、评分规范
- `scripts/`：估值、房贷、评分、回测和公开网页抓取示例
- `assets/`：报告、输入与输出模板
- `data/`：城市参考库和指标字典
- `examples/`：调用示例

## 快速测试

```bash
python scripts/valuation.py --input examples/sample-property.json
python scripts/mortgage.py --principal 2000000 --annual-rate 0.031 --years 30
python scripts/scoring.py --input examples/sample-scores.json
python scripts/backtest.py --input examples/sample-backtest.json
```

## 注意

脚本只负责确定性计算和公开页面的合规抓取框架；政策解释、城市判断、数据交叉验证与决策仍由 Agent 按 `SKILL.md` 执行。
