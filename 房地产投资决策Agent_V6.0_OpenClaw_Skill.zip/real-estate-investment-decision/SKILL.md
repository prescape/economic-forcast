---
name: real-estate-investment-decision
version: "6.0.0"
description: "Professional residential real-estate Buy/Hold/Sell analysis with market regimes, supply-demand, comparable valuation, intrinsic value, IRR, liquidity, safety margin, sell signals, risk overrides, and decision auditing."
license: MIT
compatibility: Requires Python 3.10+ for bundled calculators. Network access is recommended for current policy, market, transaction, land, rental, project, and developer data.
metadata: {"author":"openai-assisted","version":"6.0.0","language":"zh-CN","domain":"real-estate","progressive-disclosure":true}
allowed-tools: web browser search fetch files read exec python
---

# 房地产投资决策 Agent V6.0

目标不是“评价楼盘”，而是回答：**现在是否可以买、已持有是否继续持有、何时应该卖、什么价格才值得行动。**

## 核心输出纪律

每次完整分析必须尽量给出：`BUY / HOLD / SELL / WAIT / REJECT`、合理价值区间、安全买入价、目标价/退出条件、3/5年IRR、流动性、核心风险、数据置信度。数据不足时宁可扩大区间或输出 WAIT，不得伪造精确值。

## 渐进式披露导航

按需读取，不要一次加载全部：
- 宏观与信贷：`references/01-macro-engine.md`
- 政策：`references/02-policy-engine.md`
- 房地产周期：`references/03-cycle-engine.md`
- 城市与板块：`references/04-city-engine.md`
- 项目与微观估值：`references/05-valuation-engine.md`
- 家庭资产配置：`references/06-household-engine.md`
- 情景、谈判与决策：`references/07-decision-engine.md`
- 历史回测：`references/08-backtest-engine.md`
- 数据获取与质量：`references/09-data-workflow.md`
- 评分与输出：`references/10-scoring-output.md`
- 供需与库存：`references/11-supply-demand-engine.md`
- 现金流、IRR与情景：`references/12-return-irr-engine.md`
- 流动性：`references/13-liquidity-engine.md`
- Buy/Hold/Sell 与卖出信号：`references/14-buy-hold-sell-engine.md`
- 风险覆盖、持仓监控与审计：`references/15-risk-monitoring-audit.md`

城市分析优先读取 `data/city-reference-library.json`；没有数据则建立待采集字段，不编造数值。

## Step 0：任务模式

- `quick_scan`：快速判断 BUY/HOLD/SELL/WAIT/REJECT。
- `full_analysis`：完整投资委员会式分析。
- `unit_valuation`：具体房源估值与最高买入价。
- `comparison`：多个楼盘/房源横向比较。
- `portfolio_review`：已持有物业是否继续持有或卖出。
- `sell_check`：专门检查卖出信号。
- `backtest`：历史时点回测，严格防止未来数据泄漏。
- `policy_impact`：政策冲击分析。

## Step 1：标准化对象与投资目标

至少识别国家、省、市、区、板块、项目、分期、楼栋、户型/房源、观察日、用途、自住/投资权重、预计持有期、资金与贷款约束。缺少关键字段时先列缺口；能通过公开数据补齐则先检索。

## Step 2：建立证据账本

按 `references/09-data-workflow.md` 建立字段级证据表。区分成交价与挂牌价、官方规划与营销承诺、已兑现与待兑现。记录数据期、发布日期、来源等级、交叉验证和异常值。

## Step 3：运行九大分析域

1. Macro & Credit Regime
2. Policy
3. Real Estate Cycle
4. City & Submarket
5. Project / Unit Quality
6. Supply & Demand
7. Valuation & Margin of Safety
8. Cash Flow / IRR & Liquidity
9. Household / Portfolio Fit

## Step 4：估值必须多方法交叉

优先级：同套重复成交 > 同楼栋同户型 > 同小区同类成交 > 同板块竞品成交 > 租金资本化 > 历史价格位置 > 重置/替代成本。

完整分析尽量输出：
- Comparable fair value
- Income/rent implied value
- Replacement/substitution value
- Historical-position value
- Blended intrinsic value low/mid/high
- Margin of Safety
- `strong_buy_price`、`buy_price`、`fair_price`、`do_not_chase_price`

运行 `scripts/valuation.py`；不得用挂牌价冒充成交估值。

## Step 5：收益与压力测试

运行 `scripts/irr.py`，至少构建 Bear/Base/Bull 三情景。现金流纳入：首付、贷款、利息、税费、中介、装修、物业、维修、空置、租金、卖出成本。输出3年/5年IRR；数据允许时扩展10年。

## Step 6：流动性

运行 `scripts/liquidity.py` 或按 `references/13-liquidity-engine.md` 评分。成交量、挂牌库存、成交周期、议价率、主流总价/户型、房龄与替代供应共同决定“能不能卖掉”，不得只看价格涨跌。

## Step 7：风险一票否决 Risk Override

任一重大法律/产权/结构安全/交付/现金流断裂风险，或关键投资逻辑依赖未经证实信息，优先 `REJECT/WAIT`。高综合分不能覆盖硬风险。

## Step 8：Buy / Hold / Sell 决策

运行 `scripts/decision.py`。决策必须同时考虑：资产质量、估值安全边际、周期/趋势、供需、流动性、IRR、机会成本、家庭适配和 Risk Override。

动作集合：
- `STRONG_BUY`
- `BUY`
- `NEGOTIATE_BUY`
- `WAIT`
- `HOLD`
- `REDUCE`
- `SELL`
- `REJECT`

卖出不能只因“涨了很多”；至少给出触发证据：明显高估、基本面恶化、供给冲击、流动性恶化、周期转弱、预期IRR低于机会成本、家庭资产配置需要或硬风险。

## Step 9：评分与置信度

V6 默认投资评分维度：宏观、政策、周期、城市/板块、资产质量、供需、估值安全、现金流收益、流动性、家庭适配、数据可信、风险控制。用途不同可调整权重，但必须披露权重。

置信度与投资评分分开。高分低置信度不得输出强买。

## Step 10：输出投资委员会报告

按 `assets/report-template.md`：
1. Executive Decision
2. BUY/HOLD/SELL + 置信度
3. 当前价 vs 内在价值
4. 强买/买入/合理/不追价区间
5. 城市周期与板块
6. 项目/房源质量
7. 供需与库存
8. 估值与安全边际
9. Bear/Base/Bull + 3/5年IRR
10. 流动性
11. 家庭/组合适配
12. Risk Override
13. 买入触发条件
14. 卖出触发条件
15. 数据缺口与下一步
16. 结构化 JSON

## 防幻觉与投资纪律

禁止：把挂牌价说成成交价；一笔成交代表全盘；规划当兑现；营销材料当独立证据；缺数据仍给精确IRR；回测偷看未来；总分掩盖硬风险；用“必涨/稳赚/绝对抄底”。
