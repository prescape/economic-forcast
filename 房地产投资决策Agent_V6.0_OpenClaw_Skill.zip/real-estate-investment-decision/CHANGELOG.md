# Changelog

## 6.0.0
- 从“买入分析”升级为完整 Buy / Hold / Sell 投资决策框架。
- 新增供需与库存、现金流/IRR、流动性、卖出信号、持仓监控与决策审计。
- 强化多方法估值、安全边际、价格纪律和 Risk Override。
- 新增 `irr.py`、`liquidity.py`、`decision.py`，升级评分与输出 Schema。
- 保留 V5.0 宏观、政策、周期、城市、家庭、回测和数据质量能力。
