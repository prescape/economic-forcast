# 房地产投资决策报告 V6.0

## 1. Executive Decision
- Action: BUY / HOLD / SELL / WAIT / REJECT
- Confidence:
- One-line thesis:

## 2. Price Discipline
- Current price:
- Intrinsic value low/mid/high:
- Margin of safety:
- Strong-buy price:
- Buy price:
- Fair price:
- Do-not-chase price:

## 3. Market Regime
宏观、政策、城市周期、板块状态。

## 4. Asset Quality
项目、房源、通勤、产品、开发商/物业、硬伤。

## 5. Supply & Demand
库存、去化、二手挂牌、未来供给、需求基础。

## 6. Valuation
可比成交、租金资本化、历史位置、替代/重置成本与融合估值。

## 7. Returns
Bear/Base/Bull；3Y/5Y IRR；机会成本；现金流压力。

## 8. Liquidity
流动性评分、成交周期、议价、强制出售风险。

## 9. Household / Portfolio Fit
杠杆、现金储备、集中度、自住价值。

## 10. Risk Override
是否触发一票否决及证据。

## 11. Buy Triggers
价格/成交量/政策/供需等可验证触发条件。

## 12. Sell Triggers
高估、基本面、供给、流动性、机会成本、组合再平衡。

## 13. Data Confidence
缺失项、来源等级、观察日期、模型分歧。

## 14. Next Actions
下一步核实、议价、监控或退出动作。
