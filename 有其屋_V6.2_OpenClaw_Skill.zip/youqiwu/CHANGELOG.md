# Changelog

## 6.1.0
- 基于已安装 V6.0 做向后兼容增量升级。
- 新增 Regional Data Engine：城市→区/板块→小区→具体房源。
- 新增深圳黄埔雅苑 Benchmark 与固定观察日回测协议。
- 新增 `irr_scenario.py`，强化 Bear/Base/Bull 情景 IRR。
- 新增 `buy_hold_sell.py`，强化持有物业的 SELL/TRIM/HOLD 信号。
- 新增独立 Risk Override 参考模块；保留 V6.0 原有脚本与模块兼容路径。

## 6.0.0
- 从“买入分析”升级为完整 Buy / Hold / Sell 投资决策框架。
- 新增供需与库存、现金流/IRR、流动性、卖出信号、持仓监控与决策审计。
- 强化多方法估值、安全边际、价格纪律和 Risk Override。
- 新增 `irr.py`、`liquidity.py`、`decision.py`，升级评分与输出 Schema。
- 保留 V5.0 宏观、政策、周期、城市、家庭、回测和数据质量能力。


## V6.1 Benchmark Data Pack — 2026-08-16
- Added structured Huangpuyayuan benchmark master CSV and field dictionary.
- Added source registry and initial unverified transaction seed samples.
- Added PIT observation schedule, minimum-data gate and benchmark KPI protocol.
- Added reference 19 for benchmark data collection.


## V6.1 Benchmark Data Run 2026-08-16
- Filled Huangpuyayuan phase 1-4 historical transaction seed dataset from traceable public sources.
- Added current listing/rent samples and Shenzhen/Futian market context.
- Ran first strict PIT walk-forward; full decision gate fails due missing historical rent/listing snapshots, preventing look-ahead leakage.

## V6.1 Benchmark PIT Completion — 2026-08-16
- Added `historical_listing_pit.csv`: reconstructed 2020-2024 Huangpu Yayuan listing-price history plus dated listing records.
- Added `historical_rent_pit.csv`: official district rent reference/proxies and direct Huangpu Yayuan rent evidence from 2025 onward.
- Added `walk_forward_v61_second_run.csv` with separate Research Gate vs Strict PIT Gate.
- Added `PIT_COMPLETION_REPORT.md` and `second_run_status.json`.
- No current rent/listing values are backfilled into historical observation dates.

## 6.2.0 — 有其屋 Quant Decision Engine
- 正式品牌命名为“有其屋”。
- MOS 从直接 BUY 触发器改为 BUY/STRONG_BUY CANDIDATE。
- 新增 Trend Confirmation、Cycle、Liquidity、Supply、IRR、Confidence 多重买入确认。
- 新增 `buy_hold_sell_v62.py` 与 `confidence_v62.py`。
- 新增 `20-v62-quant-decision-engine.md`。
- 对 V6.1 黄埔雅苑 5 个 Research Gate 节点执行 V6.2 replay；V6.1 的两个过早 BUY 均被确认门拦截。
- 保留全部 V6.1 Benchmark/PIT/诊断数据用于版本对照，禁止覆盖历史结果。
