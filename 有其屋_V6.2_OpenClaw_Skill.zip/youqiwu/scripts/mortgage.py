#!/usr/bin/env python3
import argparse,json

def payment(p,r,n):
    m=r/12
    return p/n if m==0 else p*m*(1+m)**n/((1+m)**n-1)
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--principal',type=float,required=True);a.add_argument('--annual-rate',type=float,required=True);a.add_argument('--years',type=int,required=True);x=a.parse_args()
    n=x.years*12;pay=payment(x.principal,x.annual_rate,n)
    print(json.dumps({'monthly_payment':pay,'total_payment':pay*n,'total_interest':pay*n-x.principal},ensure_ascii=False,indent=2))
