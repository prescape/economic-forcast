#!/usr/bin/env python3
"""合规公开网页抓取示例。仅抓取无需登录的公开页面；使用前检查 robots.txt 和网站条款。"""
import argparse,time,urllib.request,urllib.robotparser

def allowed(url,agent='RealEstateSkillBot/1.0'):
    from urllib.parse import urlsplit
    p=urlsplit(url); robots=f'{p.scheme}://{p.netloc}/robots.txt'; rp=urllib.robotparser.RobotFileParser();rp.set_url(robots)
    try: rp.read(); return rp.can_fetch(agent,url)
    except Exception: return False
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('url');p.add_argument('--output',required=True);a=p.parse_args()
    if not allowed(a.url): raise SystemExit('robots.txt未明确允许，停止抓取')
    req=urllib.request.Request(a.url,headers={'User-Agent':'RealEstateSkillBot/1.0 (+research; low-rate)'})
    time.sleep(1)
    with urllib.request.urlopen(req,timeout=20) as r: data=r.read()
    open(a.output,'wb').write(data);print(a.output)
