#!/usr/bin/env python3
import argparse,json
W={'transaction_activity':25,'inventory_absorption':20,'days_on_market':15,'negotiation_spread':10,'ticket_mainstream':10,'layout_fungibility':8,'age_quality':6,'substitute_supply':6}
def main():
 p=argparse.ArgumentParser();p.add_argument('--input',required=True);a=p.parse_args();d=json.load(open(a.input,encoding='utf-8'));s=d.get('scores',d)
 avail={k:float(s[k]) for k in W if k in s and s[k] is not None}; den=sum(W[k] for k in avail); score=sum(avail[k]*W[k] for k in avail)/den if den else None
 label=None if score is None else ('Excellent' if score>=80 else 'Good' if score>=65 else 'Normal' if score>=50 else 'Weak' if score>=35 else 'Illiquid')
 print(json.dumps({'liquidity_score':round(score,2) if score is not None else None,'liquidity_grade':label,'coverage':round(den/100,2)},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
