#!/usr/bin/env python3
import csv,json
from pathlib import Path
from buy_hold_sell_v62 import decide
root=Path(__file__).resolve().parents[1]
p=root/'data/benchmarks/shenzhen-huangpuyayuan/v61_buy_hold_sell_historical_test.csv'
out=root/'data/benchmarks/shenzhen-huangpuyayuan/v62_decision_replay.csv'
rows=[]
with p.open(encoding='utf-8-sig') as f:
    for r in csv.DictReader(f):
        trend=float(r['trailing_12m_fair_value_change_pct']) if r['trailing_12m_fair_value_change_pct'] else None
        mos=float(r['margin_of_safety_pct'])/100
        # Research-gate replay: reconstructed listing and proxy rent imply confidence below production BUY gate.
        conf=60.0
        cycle='DOWNTREND' if trend is not None and trend<=-3 else 'NEUTRAL'
        d={'margin_of_safety':mos,'price_trend_12m_pct':trend,'cycle_state':cycle,
           'liquidity_score':None,'supply_pressure_score':None,'confidence_score':conf}
        z=decide(d)
        nxt=float(r['next_12m_change_pct']) if r['next_12m_change_pct'] else None
        rows.append({**r,'v62_candidate':z.get('candidate'),'v62_action':z['action'],'v62_reason_codes':'|'.join(z.get('reason_codes',[])),'v62_avoids_premature_buy': bool(r['entry_decision_v61']=='BUY' and z['action']!='BUY')})
with out.open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
summary={'nodes':len(rows),'v61_buy_nodes':sum(r['entry_decision_v61']=='BUY' for r in rows),'v62_buy_nodes':sum(r['v62_action'] in ('BUY','STRONG_BUY') for r in rows),'premature_v61_buy_nodes_blocked':sum(r['v62_avoids_premature_buy'] for r in rows),'note':'Research-gate replay only; not a strict PIT performance claim.'}
(root/'data/benchmarks/shenzhen-huangpuyayuan/v62_replay_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
