#!/usr/bin/env python3
import argparse, json

def npv(rate, flows):
    return sum(v/((1+rate)**i) for i,v in enumerate(flows))

def irr(flows):
    if not flows or min(flows) >= 0 or max(flows) <= 0: return None
    lo, hi = -0.9999, 10.0
    flo, fhi = npv(lo,flows), npv(hi,flows)
    if flo*fhi > 0: return None
    for _ in range(220):
        mid=(lo+hi)/2; fm=npv(mid,flows)
        if abs(fm)<1e-9: return mid
        if flo*fm<=0: hi=mid
        else: lo=mid; flo=fm
    return (lo+hi)/2

def scenario(d,s):
    years=int(s.get('years',5)); price=float(d['purchase_price']); down=float(d.get('down_payment',price)); loan=price-down
    buy_cost=float(d.get('buy_cost',0)); annual_debt=float(d.get('annual_debt_service',0)); rent=float(d.get('annual_rent',0)); op=float(d.get('annual_operating_cost',0))
    rent_g=float(s.get('rent_growth',0)); exit_g=float(s.get('price_growth',0)); vacancy=float(s.get('vacancy_rate',0)); sell_cost=float(s.get('sell_cost_rate',0.02)); remaining=float(s.get('remaining_loan',max(0,loan-years*max(0,annual_debt*0.45))))
    flows=[-(down+buy_cost)]
    for y in range(1,years+1):
        net=rent*((1+rent_g)**(y-1))*(1-vacancy)-op-annual_debt
        if y==years:
            exit_price=price*((1+exit_g)**years); net += exit_price*(1-sell_cost)-remaining
        flows.append(net)
    r=irr(flows)
    return {'years':years,'cash_flows':flows,'levered_irr':r,'equity_multiple':sum(v for v in flows[1:] if v>0)/(-flows[0]) if flows[0]<0 else None}

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--input',required=True); a=p.parse_args(); d=json.load(open(a.input,encoding='utf-8'))
    print(json.dumps({k:scenario(d,v) for k,v in d.get('scenarios',{}).items()},ensure_ascii=False,indent=2))
