#!/usr/bin/env python3
import argparse,json
def npv(r,f):return sum(v/(1+r)**i for i,v in enumerate(f))
def irr(f):
 if min(f)>=0 or max(f)<=0:return None
 lo,hi=-.999,10
 for _ in range(200):
  m=(lo+hi)/2
  if npv(m,f)>0:lo=m
  else:hi=m
 return (lo+hi)/2
def run(d,s):
 y=int(d.get('years',5));p=d['purchase_price'];down=d.get('down_payment',p);loan=max(0,p-down);rent=d.get('annual_rent',0);debt=d.get('annual_debt_service',0);op=d.get('annual_operating_cost',0);rg=s.get('rent_growth',0);pg=s.get('price_growth',0);vac=s.get('vacancy_rate',.05);flows=[-(down+d.get('buy_cost',0)+d.get('renovation',0))];flows += [rent*(1+rg)**(i-1)*(1-vac)-op-debt for i in range(1,y)];sale=p*(1+pg)**y*(1-s.get('sell_cost_rate',.03))-d.get('remaining_loan_at_exit',loan);flows.append(rent*(1+rg)**(y-1)*(1-vac)-op-debt+sale);r=irr(flows);return {'irr_pct':round(r*100,2) if r is not None else None,'cashflows':flows}
p=argparse.ArgumentParser();p.add_argument('--input',required=True);a=p.parse_args();d=json.load(open(a.input,encoding='utf-8'));print(json.dumps({k:run(d,v) for k,v in d['scenarios'].items()},ensure_ascii=False,indent=2))
