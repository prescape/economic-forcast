#!/usr/bin/env python3
import argparse,json,math

def weighted_value(methods):
    valid=[m for m in methods if m.get('value') is not None and m.get('quality',0)>=50 and m.get('weight',0)>0]
    if not valid:return None
    s=sum(m['weight']*m['quality']/100 for m in valid)
    return sum(m['value']*m['weight']*m['quality']/100 for m in valid)/s if s else None

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);a=p.parse_args()
    d=json.load(open(a.input,encoding='utf-8'))
    fair=weighted_value(d.get('valuation_methods',[])); price=d.get('purchase_price')
    margin=(fair-price)/fair if fair and price else None
    width=d.get('range_width',0.12)
    out={'fair_value_mid':fair,'fair_value_low':fair*(1-width) if fair else None,'fair_value_high':fair*(1+width) if fair else None,'safety_margin':margin}
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
