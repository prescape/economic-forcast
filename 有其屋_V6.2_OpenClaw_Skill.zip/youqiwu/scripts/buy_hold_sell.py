#!/usr/bin/env python3
import argparse,json
def f(d):
 if d.get('hard_override'):return {'action':'REJECT'}
 if d.get('currently_owned'):
  n=sum(bool(d.get(k)) for k in ['valuation_sell_signal','cycle_sell_signal','fundamental_sell_signal','supply_sell_signal','liquidity_sell_signal','opportunity_cost_sell_signal']);return {'action':'STRONG_SELL' if n>=3 else 'SELL' if n>=2 else 'TRIM' if n==1 else 'HOLD','sell_signal_count':n}
 m=d.get('margin_of_safety');l=d.get('liquidity_score');i=d.get('base_irr_pct')
 if m is None or (l is not None and l<35) or (i is not None and i<d.get('minimum_required_irr_pct',4)):return {'action':'WATCH'}
 return {'action':'STRONG_BUY' if m>=.2 else 'BUY' if m>=.1 else 'NEGOTIATE' if m>=0 else 'WATCH'}
p=argparse.ArgumentParser();p.add_argument('--input',required=True);a=p.parse_args();print(json.dumps(f(json.load(open(a.input,encoding='utf-8'))),ensure_ascii=False,indent=2))
