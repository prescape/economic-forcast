#!/usr/bin/env python3
import argparse,json
DEFAULT={'macro':6,'policy':7,'cycle':8,'city_submarket':11,'asset_quality':12,'supply_demand':10,'valuation_safety':14,'cashflow_return':9,'liquidity':8,'household_fit':6,'data_confidence':4,'risk_control':5}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--input',required=True);a=p.parse_args();d=json.load(open(a.input,encoding='utf-8'));scores=d['scores'];weights=d.get('weights',DEFAULT);avail={k:v for k,v in weights.items() if k in scores and scores[k] is not None};total=sum(avail.values());raw=sum(float(scores[k])*v for k,v in avail.items())/total if total else None;dq=float(scores.get('data_confidence',d.get('data_quality',50)));adj=raw*(0.6+0.4*dq/100) if raw is not None else None
 print(json.dumps({'raw_investment_score':round(raw,2) if raw is not None else None,'adjusted_investment_score':round(adj,2) if adj is not None else None,'coverage':round(total/sum(weights.values()),3),'weights':weights},ensure_ascii=False,indent=2))
