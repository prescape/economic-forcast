#!/usr/bin/env python3
import argparse,json,datetime,math
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);a=p.parse_args();d=json.load(open(a.input,encoding='utf-8'))
    obs=datetime.date.fromisoformat(d['observation_date']); bad=[x for x in d.get('decision_data',[]) if datetime.date.fromisoformat(x['publication_date'])>obs]
    start=d.get('initial_equity'); end=d.get('ending_equity'); years=d.get('years',1)
    ann=(end/start)**(1/years)-1 if start and end and years else None
    print(json.dumps({'future_data_violations':bad,'annualized_return':ann,'valid':not bad},ensure_ascii=False,indent=2))
