#!/usr/bin/env python3
import argparse, json

def decide(d):
    if d.get('hard_override'):
        return {'action':'REJECT','reason_codes':['HARD_RISK_OVERRIDE']}
    if d.get('currently_owned'):
        keys=['valuation_sell_signal','cycle_sell_signal','fundamental_sell_signal','supply_sell_signal','liquidity_sell_signal','opportunity_cost_sell_signal']
        n=sum(bool(d.get(k)) for k in keys)
        return {'action':'STRONG_SELL' if n>=3 else 'SELL' if n>=2 else 'TRIM' if n==1 else 'HOLD','sell_signal_count':n}

    mos=d.get('margin_of_safety')
    if mos is None:
        return {'action':'DATA_INSUFFICIENT','candidate':'NONE','reason_codes':['MISSING_MOS']}
    candidate='STRONG_BUY_CANDIDATE' if mos>=.20 else 'BUY_CANDIDATE' if mos>=.10 else 'NEGOTIATE' if mos>=0 else 'WATCH'
    if candidate in ('NEGOTIATE','WATCH'):
        return {'action':candidate,'candidate':candidate,'reason_codes':['VALUATION_GATE']}

    reasons=[]
    trend=d.get('price_trend_12m_pct')
    cycle=str(d.get('cycle_state','')).upper()
    liq=d.get('liquidity_score')
    supply=d.get('supply_pressure_score')
    irr=d.get('base_irr_pct')
    minirr=d.get('minimum_required_irr_pct',4)
    conf=d.get('confidence_score')

    # Missing confirmation evidence is not silently treated as pass.
    missing=[]
    for k,v in [('price_trend_12m_pct',trend),('cycle_state',cycle or None),('liquidity_score',liq),('supply_pressure_score',supply),('confidence_score',conf)]:
        if v is None: missing.append(k)
    if trend is not None and trend <= -3: reasons.append('TREND_NOT_CONFIRMED')
    if cycle in {'DOWNTREND','DETERIORATING','RISK_OFF'}: reasons.append('CYCLE_NOT_CONFIRMED')
    if liq is not None and liq < 50: reasons.append('LIQUIDITY_WEAK')
    if supply is not None and supply > 70: reasons.append('SUPPLY_PRESSURE_HIGH')
    if irr is not None and irr < minirr: reasons.append('IRR_BELOW_HURDLE')
    if conf is not None and conf < 70: reasons.append('CONFIDENCE_BELOW_BUY_GATE')

    if missing:
        reasons.append('MISSING_CONFIRMATION:'+','.join(missing))
    if reasons:
        # A valuation candidate that fails confirmation is not a BUY.
        action='WATCH' if any(x in reasons for x in ['TREND_NOT_CONFIRMED','CYCLE_NOT_CONFIRMED','LIQUIDITY_WEAK','SUPPLY_PRESSURE_HIGH']) else 'NEGOTIATE'
        return {'action':action,'candidate':candidate,'confirmation_pass':False,'reason_codes':reasons}
    return {'action':'STRONG_BUY' if candidate=='STRONG_BUY_CANDIDATE' else 'BUY','candidate':candidate,'confirmation_pass':True,'reason_codes':['ALL_GATES_PASS']}

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);a=p.parse_args()
    with open(a.input,encoding='utf-8') as f:d=json.load(f)
    print(json.dumps(decide(d),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
