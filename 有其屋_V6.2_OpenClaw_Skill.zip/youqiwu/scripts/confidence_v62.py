#!/usr/bin/env python3
import argparse,json
WEIGHTS={'comparables':35,'freshness':20,'listing_liquidity':15,'rent':10,'regional_cycle':10,'supply':10}
MULT={'PIT_VERIFIED':1.0,'VERIFIED':1.0,'RECONSTRUCTED':0.75,'PROXY':0.5,'MISSING':0.0}
def score(d):
    parts={k:WEIGHTS[k]*MULT.get(str(d.get(k,'MISSING')).upper(),0) for k in WEIGHTS}
    total=round(sum(parts.values()),1)
    return {'confidence_score':total,'grade':'HIGH' if total>=80 else 'MEDIUM' if total>=60 else 'LOW','components':parts}
p=argparse.ArgumentParser();p.add_argument('--input',required=True);a=p.parse_args();print(json.dumps(score(json.load(open(a.input,encoding='utf-8'))),ensure_ascii=False,indent=2))
