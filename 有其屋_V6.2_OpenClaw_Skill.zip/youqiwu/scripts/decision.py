#!/usr/bin/env python3
import argparse,json

def decide(d):
    if d.get('risk_override'): return 'REJECT'
    held=bool(d.get('already_owned'))
    mos=d.get('safety_margin'); score=d.get('investment_score'); conf=d.get('confidence_score',0); irr=d.get('forward_irr'); opp=d.get('opportunity_cost'); sell=d.get('sell_signal_count',0)
    if held:
        if sell>=2 or (irr is not None and opp is not None and irr < opp and sell>=1): return 'SELL'
        if sell==1: return 'REDUCE' if (score is not None and score<55) else 'HOLD'
        return 'HOLD'
    if conf<60: return 'WAIT'
    if mos is not None and mos>=0.20 and (score is None or score>=75): return 'STRONG_BUY'
    if mos is not None and mos>=0.10 and (score is None or score>=68): return 'BUY'
    if mos is not None and mos>=0 and (score is None or score>=60): return 'NEGOTIATE_BUY'
    return 'WAIT'
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--input',required=True);a=p.parse_args();d=json.load(open(a.input,encoding='utf-8'));print(json.dumps({'decision':decide(d)},ensure_ascii=False,indent=2))
