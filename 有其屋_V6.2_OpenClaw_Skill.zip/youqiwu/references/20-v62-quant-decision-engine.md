# V6.2 Quant Decision Engine

## 目标
V6.1 黄埔雅苑 Research Gate 历史诊断发现：2022H2、2023H1 在安全边际超过 10% 时给出 BUY，但随后 12 个月价格继续下降约 10.38% 和 8.36%。V6.2 因此禁止“便宜=立即买入”。

## 两阶段买入机制
### Stage A — Valuation Candidate
- MOS >= 20%: STRONG_BUY_CANDIDATE
- MOS >= 10%: BUY_CANDIDATE
- 0 <= MOS < 10%: NEGOTIATE
- MOS < 0: WATCH

### Stage B — Confirmation Gate
BUY_CANDIDATE 必须检查：
1. Trend Confirmation：12个月价格趋势不得处于明显下行；默认 `price_trend_12m_pct <= -3%` 阻止 BUY。
2. Cycle Confirmation：`DOWNTREND/DETERIORATING/RISK_OFF` 阻止 BUY；`BOTTOMING/STABILIZING/RECOVERY/RISK_ON` 可通过。
3. Liquidity：默认 >= 50；<35 直接 WATCH/REJECT 风险。
4. Supply：Supply Pressure > 70 阻止 BUY；50–70 降级并要求更大安全边际。
5. IRR：Base IRR 必须达到用户最低要求；Bear IRR 用于风险披露。
6. Confidence：>=70 才允许正式 BUY；50–69 最高 NEGOTIATE；<50 DATA_INSUFFICIENT/WATCH。

## 决策纪律
- MOS 是必要但非充分条件。
- 下跌趋势中的低估优先定义为 VALUE_TRAP_RISK。
- 数据缺失不得自动当作“通过”。关键确认字段不足时最高输出 NEGOTIATE/WATCH。
- Risk Override 永远优先于综合分。

## 持有/卖出
已持有物业继续使用六类 SELL signal，同时增加 forward-return/opportunity-cost 约束。出现硬风险直接 SELL/REJECT；信号数仅作为辅助，不得替代证据解释。

## Confidence Score
建议组成：成交可比 35%、数据时效 20%、挂牌/流动性 15%、租金 10%、区域/周期 10%、供给 10%。每一项必须记录 evidence status：PIT_VERIFIED / RECONSTRUCTED / PROXY / MISSING。
