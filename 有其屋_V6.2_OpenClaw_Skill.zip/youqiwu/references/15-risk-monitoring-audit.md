# Risk Override, Monitoring & Audit

## Risk Override
法律产权、结构/消防/污染、重大停工交付、无法正常交易融资、家庭压力情景现金流断裂、重大信息真实性问题可覆盖总分。

## 持仓监控
建议保存 acquisition_price、all_in_cost、loan_balance、rent、latest_comps、listing_inventory、transaction_volume、days_on_market、policy_regime、supply_pipeline、thesis_status。

每次复评输出：thesis_intact、new_sell_signals、valuation_gap、forward_3y_irr、liquidity_change、next_review_trigger。

## 决策审计
保存 observation_date、当时可获得的数据、版本号、评分、估值区间、决策、置信度。回测只允许使用 observation_date 当日及以前发布的数据。
