# Liquidity Engine

## 目的
评估“合理价格下多久能卖掉、需要多大折价”。

## 维度
成交活跃度25%、挂牌消化20%、成交周期15%、议价率10%、总价主流度10%、户型通用性8%、房龄/品质6%、替代供应6%。

## 输出
0-100 liquidity_score，并标记：Excellent >=80；Good 65-79；Normal 50-64；Weak 35-49；Illiquid <35。

同时输出 estimated_days_to_sell_range 与 forced_sale_discount_range；没有可靠样本时只给等级，不伪造天数。
