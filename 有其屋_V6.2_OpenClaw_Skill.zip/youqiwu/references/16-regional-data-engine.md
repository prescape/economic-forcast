# Regional Data Engine
建立城市→区/板块→小区→房源画像。必采：人口就业、产业收入、交通配套、供地/在建/库存、二手挂牌/成交/价格/周期/议价率、租金与未来供应。所有关键字段记录 source、observation_date、definition、sample_size、source_grade。
