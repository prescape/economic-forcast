# Risk Override
Hard Reject：产权/查封/无法过户、重大安全、重大交付风险。Conditional：严重高估、极低流动性、现金流压力测试失败、关键价值依赖未兑现承诺、未来供应冲击。
