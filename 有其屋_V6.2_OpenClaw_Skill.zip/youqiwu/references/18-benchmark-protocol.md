# Benchmark — 深圳黄埔雅苑（V6.1 数据验证协议）

## 目标
将黄埔雅苑作为固定回归案例，验证估值、流动性、IRR 与 BUY/HOLD/SELL，而不是作为演示样例。

## 数据层级
深圳 → 福田区 → 福田中心/莲花微板块 → 黄埔雅苑 → 一/二/三/四期 → 具体房源。

## PIT 规则
每个 observation_date 只能使用 `as_of_date <= observation_date` 的记录。禁止用后来公布的成交、挂牌、政策或租金反推过去。

## 最低数据闸门
在输出有效 Benchmark 决策前，至少需要：同小区有效成交 8 笔、同一期 4 笔、租金样本 3 笔、一个挂牌库存快照，以及深圳官方成交环境数据。未满足时只能输出 DATA INSUFFICIENT。

## 固定观察时点
2021H1 起每半年一次至 2026H1。每个时点记录 fair value、MOS、Base/Bear/Bull IRR、liquidity、supply pressure、decision，并复盘未来 6/12/24 个月。

## KPI
Fair Value MAE、方向命中率、BUY 后 12/24 月收益、最大不利变动、信号数量、数据覆盖率。不能靠“永远不买”获得虚假高命中率。

## 数据可信度
官方=高；可追溯成交平台=中；经纪/挂牌=中低。挂牌价不得当作成交价。单一第三方逐笔成交默认 `verified=false`，需第二来源交叉验证后才能升级。
