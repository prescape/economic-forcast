# 有其屋 V6.2 — RealVest Quant Decision Engine

面向住宅房地产的专业投资决策 Skill。核心目标不是评价“房子好不好”，而是回答：**什么价格值得买、是否继续持有、什么时候应该卖。**

## V6.2 核心变化
- 品牌正式命名为“有其屋”。
- MOS（安全边际）由直接 BUY 触发器改为 BUY CANDIDATE。
- 新增 Trend Confirmation Gate，阻止持续下跌中的“价值陷阱式抄底”。
- 新增 Cycle / Liquidity / Supply / IRR / Confidence 多重确认。
- 新增 Confidence Score 与 DATA_INSUFFICIENT 纪律。
- 保留深圳黄埔雅苑 Benchmark、PIT 数据和 V6.1 历史诊断结果。
- 新增 V6.2 replay，用同一历史节点检查过早 BUY 是否被拦截。

## OpenClaw
推荐技能目录名：`youqiwu`。

旧 V6.1 可以保留用于版本对照；V6.2 是新版本，不应覆盖历史 Benchmark 结果。
