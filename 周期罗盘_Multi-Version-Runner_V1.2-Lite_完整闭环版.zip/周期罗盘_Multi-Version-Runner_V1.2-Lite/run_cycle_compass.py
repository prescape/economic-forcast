#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import argparse,subprocess,sys,json,shutil,importlib.util,pandas as pd,numpy as np
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'outputs';OUT.mkdir(exist_ok=True);SHARED=ROOT/'shared_data'/'china_pit';GEN=ROOT/'shared_data'/'generated';GEN.mkdir(parents=True,exist_ok=True);FROZEN=ROOT/'shared_data'/'reference'/'V7.3_factor_panel_completed.csv';V751=ROOT/'versions'/'V7.5.1-RC2'/'dalio-china-asset-allocation';FETCH=V751/'scripts'/'fetch_all_pit.py';DQ=V751/'scripts'/'data_quality_gate.py';MODEL=V751/'data'/'pit';BUILDER=ROOT/'scripts'/'build_current_factor_panel.py';ASSETS=['000300','000852','399006','000688','000016'];PTS=np.array([5,4,3,2,1],float);ALLOC={'Risk-On':.8,'Neutral':.55,'Risk-Off':.3}
def cmd(c,cwd=None):
 p=subprocess.run(c,cwd=cwd,capture_output=True,text=True);return p.returncode,p.stdout,p.stderr
def sync(a,b):
 b.mkdir(parents=True,exist_ok=True)
 for p in a.glob('*.csv'):shutil.copy2(p,b/p.name)
def mod():
 p=V751/'engine'/'walk_forward_v75.py';s=importlib.util.spec_from_file_location('v75',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def calc(run_id):
 rc,so,se=cmd([sys.executable,str(BUILDER),'--pit-dir',str(SHARED),'--frozen-panel',str(FROZEN),'--out-dir',str(GEN)]); 
 if rc:raise RuntimeError(se[-2000:])
 f=pd.read_csv(GEN/'current_factor_panel.csv',dtype={'asset':str});f.asset=f.asset.str.zfill(6);asof=pd.Timestamp(f.as_of_date.iloc[0]);v=mod();pit=pd.read_csv(SHARED/'unified_pit.csv',low_memory=False,dtype={'entity':str});pit.entity=pit.entity.map(v.norm_code);pit.observation_date=pd.to_datetime(pit.observation_date,errors='coerce');pit.available_date=pd.to_datetime(pit.available_date,errors='coerce');pit.value=pd.to_numeric(pit.value,errors='coerce')
 macpath=next((ROOT/'versions'/'V7.5.1-RC2').rglob('V7.5_macro_regime_132_nodes.csv'));mh=pd.read_csv(macpath);lr=mh.iloc[-1];cur=str(lr['regime']);prev_des=str(lr['desired_regime']);up=0;last=(str(lr['quadrant']),cur)
 mm=v.build_macro(pit,asof,asof);des=mm['desired_regime']
 if v.REGIME_LEVEL[des]<v.REGIME_LEVEL[cur]:cur=des;up=0
 elif v.REGIME_LEVEL[des]>v.REGIME_LEVEL[cur]:
  up=up+1 if des==prev_des else 1
  if up>=2:cur=v.LEVEL_REGIME[min(v.REGIME_LEVEL[cur]+1,v.REGIME_LEVEL[des])];up=0
 else:up=0
 risk=ALLOC[cur];f=f.set_index('asset').reindex(ASSETS);ranked=f.alpha_v75.sort_values(ascending=False).index.tolist();raw={a:risk*p/PTS.sum() for p,a in zip(PTS,ranked)};hist=pd.read_csv(next((ROOT/'versions'/'V7.5.1-RC2').rglob('V7.5_walk_forward_132_nodes_results.csv')));prev={a:float(hist.iloc[-1][f'w_{a}']) for a in ASSETS};blend={a:.5*prev[a]+.5*raw[a] for a in ASSETS};ss=sum(blend.values());prod={a:blend[a]*risk/ss for a in ASSETS}
 breadth={a:float(v.hist_series(pit,'close',a,asof).iloc[-1]/v.hist_series(pit,'close',a,asof).iloc[-120:].mean()-1) for a in ASSETS};top=max(breadth,key=breadth.get);bottom=min(breadth,key=breadth.get);eligible=mm['quadrant']=='Reflation' or cur=='Risk-On';prev_elig=bool(last and (last[0]=='Reflation' or last[1]=='Risk-On'));tilt=.1*risk
 v728=prod.copy();
 if eligible:
  mv=min(tilt,v728[bottom]);v728[bottom]-=mv;v728[top]+=mv
 gate2=eligible and prev_elig;v7285=prod.copy()
 if gate2:
  mv=min(tilt,v7285[bottom]);v7285[bottom]-=mv;v7285[top]+=mv
 return {'run_id':run_id,'as_of_date':asof.date().isoformat(),'macro':{'quadrant':mm['quadrant'],'desired_regime':des,'regime':cur,'risk_allocation':risk,'CSI300_ret20':mm['CSI300_ret20'],'CSI300_below_MA120':bool(mm['CSI300_below_MA120'])},'factor_rank':ranked,'breadth':{'top':top,'bottom':bottom,'eligible':eligible,'previous_formal_eligible':prev_elig},'tracks':{'V7.5.1-RC2':{'role':'PRODUCTION','weights':prod,'cash':1-sum(prod.values())},'V7.28.4-OOS':{'role':'OOS_CHALLENGER','weights':v728,'cash':1-sum(v728.values()),'tilt_active':eligible},'V7.28.5-Gate2Confirm':{'role':'RESEARCH_SHADOW','weights':v7285,'cash':1-sum(v7285.values()),'tilt_active':gate2}}}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--no-refresh',action='store_true');a=ap.parse_args();run=datetime.now().strftime('%Y%m%dT%H%M%S');sync(SHARED,MODEL);refresh=True
 if not a.no_refresh:
  rc,so,se=cmd([sys.executable,str(FETCH)],cwd=str(V751));refresh=rc==0;sync(MODEL,SHARED)
 dqf=OUT/f'{run}_data_quality.json';rc,so,se=cmd([sys.executable,str(DQ),'--pit-dir',str(SHARED),'--output',str(dqf)]);dq=rc==0
 try:r=calc(run);ok=True
 except Exception as e:r={'run_id':run,'error':str(e)};ok=False
 s={'runner_version':'V1.2','run_id':run,'DATA_REFRESH_OK':refresh,'DATA_QUALITY_OK':dq,'FACTOR_PANEL_BUILD_OK':ok,'ALL_3_VERSIONS_INVOKED':'PASS' if ok else 'FAIL','ALL_3_VERSIONS_OK':'PASS' if dq and ok else 'FAIL','result':r};(OUT/'latest_runner_status.json').write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(s,ensure_ascii=False,indent=2));raise SystemExit(0 if s['ALL_3_VERSIONS_OK']=='PASS' else 2)
if __name__=='__main__':main()
