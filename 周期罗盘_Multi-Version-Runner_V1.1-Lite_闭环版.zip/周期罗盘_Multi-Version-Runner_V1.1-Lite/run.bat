@echo off
python run_cycle_compass.py --allow-stale
pause
