"""周期罗盘 V7.25-Shadow-RecoverySuite

Architecture:
Domestic Regime
    -> V7.20 Frozen RecoveryVelocityController
    -> executable recovery allocation

In parallel:
Recovery Event
    -> V7.22 Frozen CRQ4
    -> OOS diagnostic score/log only

Hard governance:
- V7.20 Persistence threshold = 60: FROZEN
- V7.20 velocity mapping 10/15/25: FROZEN
- CRQ4 weights Breadth/Credit/RMB/Policy = 25/20/15/15: FROZEN
- CRQ4 has ZERO sizing authority.
- CRQ4 cannot trigger recovery, accelerate recovery, slow recovery, or de-risk.
- New CRQ4 evidence is appended OOS only.
"""
V725_VERSION = "V7.25-Shadow-RecoverySuite"

V720_FROZEN = {
    "persistence_threshold": 60,
    "velocity": {
        "persistence_ge_80": 0.10,
        "persistence_60_79": 0.15,
        "persistence_40_59": 0.25,
        "persistence_lt_40": None,
    }
}

CRQ4_FROZEN_WEIGHTS = {
    "breadth": 25,
    "credit": 20,
    "rmb": 15,
    "policy": 15,
}

def recovery_step_limit(persistence_score):
    if persistence_score >= 80:
        return 0.10
    if persistence_score >= 60:
        return 0.15
    if persistence_score >= 40:
        return 0.25
    return None

def crq4_score(breadth=None, credit=None, rmb=None, policy=None):
    values = {
        "breadth": breadth,
        "credit": credit,
        "rmb": rmb,
        "policy": policy,
    }
    numerator = 0.0
    denominator = 0.0
    for name, value in values.items():
        if value is not None:
            w = CRQ4_FROZEN_WEIGHTS[name]
            numerator += w * float(value)
            denominator += w
    return None if denominator == 0 else 100.0 * numerator / denominator

def evaluate_recovery(domestic_previous, domestic_target, persistence_score,
                      breadth=None, credit=None, rmb=None, policy=None):
    # V7.20 is the only execution authority.
    if domestic_target <= domestic_previous:
        executable_risk = domestic_target
        action = "DOMESTIC_BRAKE_OR_HOLD"
    else:
        limit = recovery_step_limit(persistence_score)
        if limit is None:
            executable_risk = domestic_target
            action = "FULL_RECOVERY"
        else:
            executable_risk = min(domestic_target, domestic_previous + limit)
            action = ("VELOCITY_LIMITED_RECOVERY"
                      if executable_risk < domestic_target else "FULL_RECOVERY")

    # V7.22 is observation only.
    diagnostic = crq4_score(breadth, credit, rmb, policy)
    return {
        "version": V725_VERSION,
        "domestic_target": domestic_target,
        "executable_risk": executable_risk,
        "v720_action": action,
        "crq4_score": diagnostic,
        "crq4_authority": "OOS_DIAGNOSTIC_ONLY",
    }
