# 周期罗盘 Multi-Version Runner V1.0

一次调用三轨并行：

- V7.5.1-RC2：Production，唯一正式投资建议来源。
- V7.28.4：Frozen OOS Challenger，只做旁路对照/OOS积累。
- V7.28.5 Gate-2Confirm：Research Shadow，只做非对称Alpha转换研究。

运行：
- Windows：run.bat
- Linux/macOS：./run.sh
- 或 python run_cycle_compass.py

输出：
- outputs/latest_runner_status.json
- outputs/三版本统一摘要.csv

治理：
- 不自动晋级。
- Challenger/Shadow 永远不能自动覆盖 Production。
