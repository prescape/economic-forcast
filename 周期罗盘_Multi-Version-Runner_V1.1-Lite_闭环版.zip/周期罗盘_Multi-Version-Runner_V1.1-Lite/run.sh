#!/bin/bash
python3 run_cycle_compass.py --allow-stale
