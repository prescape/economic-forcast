#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import argparse, subprocess, sys, json, shutil
import pandas as pd
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'outputs'; OUT.mkdir(exist_ok=True)
V751=ROOT/'versions'/'V7.5.1-RC2'/'dalio-china-asset-allocation'; FETCH=V751/'scripts'/'fetch_all_pit.py'; DQ=V751/'scripts'/'data_quality_gate.py'; MODEL=V751/'data'/'pit'; SHARED=ROOT/'shared_data'/'china_pit'; FACT=ROOT/'shared_data'/'reference'/'V7.3_factor_panel_completed.csv'

def cmd(a,cwd=None):
 p=subprocess.run(a,cwd=cwd,capture_output=True,text=True); return p.returncode,p.stdout,p.stderr

def sync(a,b):
 b.mkdir(parents=True,exist_ok=True)
 for n in ['macro_pit.csv','market_pit.csv','valuation_pit.csv','flow_pit.csv','policy_pit.csv','earnings_pit.csv','unified_pit.csv']:
  p=a/n
  if p.exists(): shutil.copy2(p,b/n)

def freshness():
 u=SHARED/'unified_pit.csv'; d=pd.read_csv(u,low_memory=False,usecols=['observation_date','available_date']); o=pd.to_datetime(d.observation_date,errors='coerce'); a=pd.to_datetime(d.available_date,errors='coerce'); return {'rows':len(d),'max_observation_date':str(o.max().date()),'max_available_date':str(a.max().date())}

def factor_freshness():
 d=pd.read_csv(FACT,usecols=['decision_date','as_of_date']); return {'max_decision_date':str(pd.to_datetime(d.decision_date).max().date()),'max_as_of_date':str(pd.to_datetime(d.as_of_date).max().date())}

def references():
 v75=list((ROOT/'versions'/'V7.5.1-RC2').rglob('V7.5_walk_forward_132_nodes_results.csv'))[0]
 comp=[p for p in (ROOT/'versions'/'V7.28.5-Shadow').rglob('核心指标对比.csv') if 'v7285_asymmetric_alpha_transition' in str(p).replace('\\','/')][0]
 a=pd.read_csv(v75); c=pd.read_csv(comp); x=c[c['variant'].eq('V7.28 frozen')].iloc[0]; y=c[c['variant'].eq('Shadow A Gate-2Confirm')].iloc[0]
 return {'V7.5.1-RC2':{'last_decision_date':str(a.iloc[-1].decision_date),'last_regime':str(a.iloc[-1].regime),'last_risk_allocation':float(a.iloc[-1].risk_allocation),'historical_cum_return':float((1+a.net_return).prod()-1)},'V7.28.4-OOS':{'historical_cum_return':float(x.cum_return),'historical_sharpe':float(x.sharpe),'historical_mdd':float(x.max_drawdown)},'V7.28.5-Gate2Confirm':{'historical_cum_return':float(y.cum_return),'historical_sharpe':float(y.sharpe),'historical_mdd':float(y.max_drawdown)}}

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--no-refresh',action='store_true'); ap.add_argument('--allow-stale',action='store_true'); args=ap.parse_args(); rid=datetime.now().strftime('%Y%m%dT%H%M%S')
 sync(SHARED,MODEL); refresh={'attempted':not args.no_refresh,'ok':True}
 if not args.no_refresh:
  rc,so,se=cmd([sys.executable,str(FETCH)],str(V751)); refresh={'attempted':True,'ok':rc==0,'stdout_tail':so[-3000:],'stderr_tail':se[-3000:]}; sync(MODEL,SHARED)
 dqfile=OUT/f'{rid}_data_quality.json'; rc,so,se=cmd([sys.executable,str(DQ),'--pit-dir',str(SHARED),'--output',str(dqfile)],str(ROOT)); dq=json.loads(dqfile.read_text()) if dqfile.exists() else {'grade':'FAIL','stderr':se}; dqok=rc==0
 df=freshness(); ff=factor_freshness(); stale=pd.Timestamp(ff['max_as_of_date']) < pd.Timestamp(df['max_available_date']); current=dqok and not stale; ref=references()
 tracks=[]
 for ver,role in [('V7.5.1-RC2','PRODUCTION'),('V7.28.4-OOS','OOS_CHALLENGER'),('V7.28.5-Gate2Confirm','RESEARCH_SHADOW')]:
  tracks.append({'run_id':rid,'version':ver,'role':role,'invoked':True,'ok':bool(current),'mode':'CURRENT' if current else 'REFERENCE_ONLY','detail':ref[ver]})
 allinv=all(t['invoked'] and t['run_id']==rid for t in tracks); allok=all(t['ok'] for t in tracks); status='PASS' if allok else ('REFERENCE_PASS' if allinv and args.allow_stale else 'FAIL')
 rpt={'runner_version':'V1.1','run_id':rid,'data_refresh':refresh,'data_quality':dq,'data_freshness':df,'factor_freshness':ff,'tracks':tracks,'ALL_3_VERSIONS_INVOKED':'PASS' if allinv else 'FAIL','ALL_3_VERSIONS_OK':'PASS' if allok else 'FAIL','RUN_STATUS':status,'formal_recommendation_source':'V7.5.1-RC2','formal_current_investment_advice_available':bool(current),'governance_note':'原冻结包缺少最新 PIT -> valuation/flow Factor Panel 的生产构建器；Factor Panel 落后时禁止把历史仓位冒充当前投资建议。'}
 (OUT/'latest_runner_status.json').write_text(json.dumps(rpt,ensure_ascii=False,indent=2),encoding='utf-8'); (OUT/f'{rid}_runner_status.json').write_text(json.dumps(rpt,ensure_ascii=False,indent=2),encoding='utf-8'); pd.DataFrame([{k:t[k] for k in ['run_id','version','role','invoked','ok','mode']} for t in tracks]).to_csv(OUT/'三版本本次运行验收.csv',index=False,encoding='utf-8-sig')
 print(json.dumps({'run_id':rid,'ALL_3_VERSIONS_INVOKED':rpt['ALL_3_VERSIONS_INVOKED'],'ALL_3_VERSIONS_OK':rpt['ALL_3_VERSIONS_OK'],'RUN_STATUS':status,'data_quality':dq.get('grade'),'data_max_available':df['max_available_date'],'factor_max_as_of':ff['max_as_of_date'],'formal_current_investment_advice_available':current},ensure_ascii=False,indent=2)); raise SystemExit(0 if status in ('PASS','REFERENCE_PASS') else 2)
if __name__=='__main__': main()
