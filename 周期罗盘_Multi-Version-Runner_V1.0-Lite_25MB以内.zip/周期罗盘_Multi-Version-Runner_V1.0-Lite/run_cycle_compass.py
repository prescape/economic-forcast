#!/usr/bin/env python3
from pathlib import Path
import pandas as pd, json

ROOT=Path(__file__).resolve().parent
V=ROOT/"versions"
OUT=ROOT/"outputs"; OUT.mkdir(exist_ok=True)

def find_one(root,name):
    m=list(root.rglob(name))
    if not m: raise FileNotFoundError(name)
    return m[0]

def find_suffix(root,suffix):
    m=[p for p in root.rglob("*.csv") if str(p).replace("\\","/").endswith(suffix)]
    if not m: raise FileNotFoundError(suffix)
    return m[0]

def main():
    v751=pd.read_csv(find_one(V/"V7.5.1-RC2","V7.5_walk_forward_132_nodes_results.csv"))
    comp=pd.read_csv(find_suffix(V/"V7.28.5-Shadow","outputs/v7285_asymmetric_alpha_transition/核心指标对比.csv"))

    prod_cum=float((1+v751["net_return"]).prod()-1)
    r728=comp.loc[comp["variant"].eq("V7.28 frozen")].iloc[0]
    r7285=comp.loc[comp["variant"].eq("Shadow A Gate-2Confirm")].iloc[0]

    ledgers=list((V/"V7.28.4-OOS").rglob("V7.28.4_OOS_LEDGER_APPEND_ONLY.csv"))
    oos_rows=evaluated=0
    if ledgers:
        led=pd.read_csv(ledgers[0])
        oos_rows=len(led)
        if "oos_status" in led.columns:
            evaluated=int((led["oos_status"]=="EVALUATED").sum())

    report={
      "formal_recommendation_source":"V7.5.1-RC2",
      "production":{"cum_return":prod_cum,"last_regime":str(v751.iloc[-1]["regime"]),
                    "last_risk_allocation":float(v751.iloc[-1]["risk_allocation"])},
      "v7.28.4":{"role":"OOS_CHALLENGER","historical_cum_return":float(r728["cum_return"]),
                 "historical_sharpe":float(r728["sharpe"]),"historical_mdd":float(r728["max_drawdown"])},
      "v7.28.5":{"role":"RESEARCH_SHADOW","historical_cum_return":float(r7285["cum_return"]),
                 "historical_sharpe":float(r7285["sharpe"]),"historical_mdd":float(r7285["max_drawdown"])},
      "oos":{"rows":int(oos_rows),"evaluated":int(evaluated)},
      "governance":"Only V7.5.1-RC2 has production authority; no auto-promotion."
    }
    (OUT/"latest_runner_status.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    pd.DataFrame([
      ["V7.5.1-RC2","Production",prod_cum,None,None],
      ["V7.28.4","OOS Challenger",float(r728["cum_return"]),float(r728["sharpe"]),float(r728["max_drawdown"])],
      ["V7.28.5 Gate-2Confirm","Research Shadow",float(r7285["cum_return"]),float(r7285["sharpe"]),float(r7285["max_drawdown"])]
    ],columns=["version","role","historical_cum_return","historical_sharpe","historical_mdd"]).to_csv(
      OUT/"三版本统一摘要.csv",index=False,encoding="utf-8-sig"
    )
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=="__main__":
    main()
