---
name: dalio-china-asset-allocation-v7-6-experimental-recovery
description: Research-only recovery-engine branch derived from V7.5.1-RC2. Tests faster Risk-Off recovery without changing the frozen 55/45 alpha layer or base 80/55/30 risk budgets.
version: 7.6-experimental-recovery
---

# Dalio China Asset Allocation V7.6-EXPERIMENTAL-Recovery


## Experimental status
This branch MUST NOT replace V7.5.1-RC2. It exists only to test the Recovery Engine found by the 132-node attribution audit. The current lead candidate is `combined`: immediate Risk-Off→Neutral when the baseline desired regime has recovered to Neutral, plus a low-rebound override when CSI300 remains below MA120 but 20-day return is positive and policy is non-tightening.

Run: `python engine/walk_forward_v76_recovery.py --input data/pit/unified_pit.csv --factors data/reference/V7.3_factor_panel_completed.csv --recovery-mode combined --output-dir outputs/v76_experimental_recovery/full_engine_combined`

Read `V7.6_EXPERIMENTAL_RECOVERY_REPORT.md` before any promotion decision.

## Purpose
Run the V7.5.1-RC2 China asset-allocation workflow with PIT-safe data, semi-monthly walk-forward evaluation, and a unified freeze decision. RC2 is an engineering/audit release; model parameters are unchanged from V7.5.1.

## Frozen model design
- Cross-sectional alpha: 55% valuation + 45% fund flow.
- Growth: PMI level + 3-month direction; GDP is slow confirmation.
- Inflation: CPI/PPI 3-month direction.
- Credit: M2 3-month acceleration.
- Policy: LPR/RRR easing signal with corrected RRR sign.
- Fast brake: CSI300 below 120-day MA and negative 20-day return => immediate Risk-Off.
- Hysteresis: downside immediate; upside requires two consecutive semi-monthly confirmations.
- Risk budgets: Risk-On 80%, Neutral 55%, Risk-Off 30%.
- Default one-way transaction cost: 10 bps.

## Standard workflow
1. Install dependencies: `pip install -r requirements.txt`
2. Refresh PIT data when network access is available: `python scripts/fetch_all_pit.py`
3. Reproduce the 132-node baseline: `python run_backtest.py`
4. Run the unified RC2 gate: `python run_freeze_gate.py`
5. Read `outputs/v751_rc2/unified_freeze_report.md`.
6. Do not label the package `V7.5.1-FROZEN` while the unified grade is `CONDITIONAL PASS`.
7. Accumulate untouched future semi-monthly OOS observations without changing model parameters.

## Safety / research constraints
- Do not silently impute missing PIT features.
- Never use rows whose `available_date` is later than the decision as-of date.
- Do not optimize parameters after viewing robustness or OOS results; use a separate future branch for research changes.
- Treat demo/proxy data as lower-quality and report it explicitly.
- A data-quality or leakage hard failure blocks freezing.
