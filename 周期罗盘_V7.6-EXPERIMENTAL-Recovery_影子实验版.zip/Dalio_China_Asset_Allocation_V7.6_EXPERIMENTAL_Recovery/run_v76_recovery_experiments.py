#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,json
root=Path(__file__).resolve().parent
modes=['baseline','fast_neutral','rebound_policy','rebound_2pct','rebound_confirmed','combined']
for mode in modes:
    out=root/'outputs'/'v76_experimental_recovery'/mode
    cmd=[sys.executable,str(root/'engine'/'walk_forward_v76_recovery.py'),'--input',str(root/'data/pit/unified_pit.csv'),'--factors',str(root/'data/reference/V7.3_factor_panel_completed.csv'),'--recovery-mode',mode,'--output-dir',str(out)]
    print('RUN',mode,flush=True)
    rc=subprocess.call(cmd)
    if rc: raise SystemExit(rc)
