from pathlib import Path
import pandas as pd, numpy as np, json
ROOT=Path(__file__).resolve().parents[1]
ASSETS=['000300','000852','399006','000688','000016']; PTS=np.array([5,4,3,2,1.],float)
ALLOC={'Risk-On':.8,'Neutral':.55,'Risk-Off':.3}; LV={'Risk-Off':0,'Neutral':1,'Risk-On':2}; RL={0:'Risk-Off',1:'Neutral',2:'Risk-On'}
MODES=['baseline','fast_neutral','rebound_policy','rebound_2pct','rebound_confirmed','combined','rebound_any','combined_any']

def override(row,mode):
    des=row.desired_regime; reason='baseline'; below=bool(row.CSI300_below_MA120); r20=float(row.CSI300_ret20); pol=float(row.policy_easing_score) if pd.notna(row.policy_easing_score) else 0.; pmi3=float(row.PMI_3m_change) if pd.notna(row.PMI_3m_change) else np.nan
    if des=='Risk-Off' and below and r20>0:
        if mode in ('rebound_any','combined_any'):
            des='Neutral'; reason='low_rebound_any'
        elif mode in ('rebound_policy','combined') and pol>=0: des='Neutral'; reason='low_rebound_policy_nonnegative'
        elif mode=='rebound_2pct' and r20>=.02: des='Neutral'; reason='low_rebound_ret20_ge_2pct'
        elif mode=='rebound_confirmed' and ((np.isfinite(pmi3) and pmi3>=0) or pol>=.20): des='Neutral'; reason='low_rebound_macro_or_policy_confirmed'
    return des,reason

def regimes(m,mode):
    cur='Neutral'; up=0; prev=None; ans=[]; ex=[]; rs=[]
    for row in m.itertuples():
        des,reason=override(row,mode); immediate=(mode in ('fast_neutral','combined','combined_any') and cur=='Risk-Off' and des=='Neutral')
        if LV[des]<LV[cur]: cur=des;up=0
        elif LV[des]>LV[cur]:
            if immediate: cur='Neutral';up=0;reason += '+immediate_RiskOff_to_Neutral'
            else:
                up=up+1 if des==prev else 1
                if up>=2: cur=RL[min(LV[cur]+1,LV[des])];up=0
        else: up=0
        ans.append(cur);ex.append(des);rs.append(reason);prev=des
    return ans,ex,rs

def perf(r):
    r=pd.Series(r,dtype=float);nav=(1+r).cumprod();tot=float(nav.iloc[-1]-1);sd=float(r.std(ddof=1));dd=nav/nav.cummax()-1
    return {'total_return':tot,'sharpe':float(r.mean()/sd*np.sqrt(24)),'max_drawdown':float(dd.min())}

def rm_top(ref,cand,k,monthly=False):
    x=pd.DataFrame({'date':ref.decision_date,'ref':ref.net_return,'cand':cand.net_return});x['adv']=x.cand-x.ref
    if monthly:
        x['bucket']=pd.to_datetime(x.date).dt.to_period('M').astype(str);top=x.groupby('bucket').adv.sum().nlargest(k).index;keep=~x.bucket.isin(top)
    else: top=x.nlargest(k,'adv').index;keep=~x.index.isin(top)
    return perf(x.loc[keep,'cand'])['total_return']-perf(x.loc[keep,'ref'])['total_return']

m=pd.read_csv(ROOT/'outputs/v75_output/V7.5_macro_regime_132_nodes.csv');m['decision_date']=pd.to_datetime(m.decision_date)
f=pd.read_csv(ROOT/'data/reference/V7.3_factor_panel_completed.csv');f['decision_date']=pd.to_datetime(f.decision_date);f['asset']=f.asset.astype(str).str.replace(r'\.0$','',regex=True).str.zfill(6)
rbase=pd.read_csv(ROOT/'outputs/v75_output/V7.5_walk_forward_132_nodes_results.csv');rbase['decision_date']=pd.to_datetime(rbase.decision_date)
v74=pd.read_csv(ROOT/'outputs/v74_output/V7.4_walk_forward_132_nodes_results.csv');v74['decision_date']=pd.to_datetime(v74.decision_date)
out=ROOT/'outputs/v76_experimental_recovery';out.mkdir(parents=True,exist_ok=True)
rows=[]
for mode in MODES:
    reg,ex,reason=regimes(m,mode);prev={a:0. for a in ASSETS};pc=1.;rr=[]
    for i,row in m.iterrows():
        risk=ALLOC[reg[i]];g=f[f.decision_date==row.decision_date].set_index('asset').reindex(ASSETS).copy();g['alpha']=.55*g.valuation+.45*g.flow
        ranked=g[['alpha']].reset_index().sort_values(['alpha','asset'],ascending=[False,False],kind='mergesort').asset.tolist();raw={a:0. for a in ASSETS}
        for p,a in zip(PTS,ranked):raw[a]=risk*p/PTS.sum()
        if i:
            blend={a:.5*prev[a]+.5*raw[a] for a in ASSETS};ss=sum(blend.values());w={a:blend[a]*risk/ss for a in ASSETS}
        else:w=raw
        cash=1-sum(w.values());turn=.5*(sum(abs(w[a]-prev[a]) for a in ASSETS)+abs(cash-pc));cost=turn*.001
        ar={a:float(rbase.loc[i,f'r_{a}']) for a in ASSETS};gross=sum(w[a]*ar[a] for a in ASSETS);net=gross-cost
        rec={'decision_date':row.decision_date,'baseline_desired':row.desired_regime,'experimental_desired':ex[i],'recovery_reason':reason[i],'regime':reg[i],'risk_allocation':risk,'turnover':turn,'transaction_cost':cost,'net_return':net}
        for a in ASSETS:rec[f'w_{a}']=w[a];rec[f'r_{a}']=ar[a]
        rr.append(rec);prev=w;pc=cash
    x=pd.DataFrame(rr);x.to_csv(out/f'{mode}_132_nodes.csv',index=False)
    p=perf(x.net_return);adv=x.net_return-v74.net_return
    y=pd.DataFrame({'year':x.decision_date.dt.year,'adv':adv}).groupby('year').adv.sum().to_dict()
    recov=((x.regime!=rbase.regime).sum())
    row={'mode':mode,**p,'wins_vs_v751':int((x.net_return-rbase.net_return>1e-12).sum()),'losses_vs_v751':int((x.net_return-rbase.net_return<-1e-12).sum()),'changed_regime_nodes':int(recov),'top5_node_adv_vs_v74':rm_top(v74,x,5,False),'top5_month_adv_vs_v74':rm_top(v74,x,5,True),'adv_2025':float(y.get(2025,0)),'adv_2026H1':float(y.get(2026,0)),'mean_turnover':float(x.turnover.mean())}
    # v751 comparison
    bp=perf(rbase.net_return);row['delta_return_vs_v751']=p['total_return']-bp['total_return'];row['delta_sharpe_vs_v751']=p['sharpe']-bp['sharpe'];row['delta_mdd_vs_v751']=p['max_drawdown']-bp['max_drawdown']
    rows.append(row)
res=pd.DataFrame(rows);res.to_csv(out/'V7.6_recovery_AB_summary.csv',index=False)
print(res.to_string(index=False))
