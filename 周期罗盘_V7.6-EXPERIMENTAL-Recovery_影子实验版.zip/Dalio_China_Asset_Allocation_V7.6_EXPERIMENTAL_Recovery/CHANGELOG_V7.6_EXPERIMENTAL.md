# V7.6-EXPERIMENTAL-Recovery Changelog

- Forked from V7.5.1-RC2; parent baseline left unchanged.
- Added `engine/walk_forward_v76_recovery.py`.
- Added pre-specified Recovery A/B modes and `tests/evaluate_v76_recovery_fast.py`.
- Added 132-node attribution evidence.
- Lead candidate: `combined` Recovery.
- No change to 55/45 alpha, base 80/55/30 risk budgets, MA120 fast brake, or default 10bps cost.
- Status remains EXPERIMENTAL; not eligible to replace V7.5.1-RC2 based on in-sample evidence alone.
