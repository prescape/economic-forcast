"""V7.6-EXPERIMENTAL-Recovery.

Research-only branch derived from V7.5.1-RC2.
Frozen components: 55% valuation + 45% flow alpha, 80/55/30 risk budgets,
MA120 fast brake, 10 bps one-way cost, portfolio smoothing.
Only the Risk-Off recovery transition is varied through pre-specified modes.
"""
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd

ASSETS=["000300","000852","399006","000688","000016"]
RANK_POINTS=np.array([5,4,3,2,1],dtype=float)
REGIME_ALLOC={"Risk-On":0.80,"Neutral":0.55,"Risk-Off":0.30}
REGIME_LEVEL={"Risk-Off":0,"Neutral":1,"Risk-On":2}
LEVEL_REGIME={0:"Risk-Off",1:"Neutral",2:"Risk-On"}
MODES=["baseline","fast_neutral","rebound_policy","rebound_2pct","rebound_confirmed","combined"]

def norm_code(x):
    s=str(x).strip()
    if s.endswith('.0') and s[:-2].isdigit(): s=s[:-2]
    if s.isdigit() and len(s)<6: s=s.zfill(6)
    return s

def hist_series(d,feature,entity,asof):
    q=d[(d.feature==feature)&(d.entity==entity)&(d.available_date<=asof)&(d.observation_date<=asof)].copy()
    q=q.dropna(subset=["observation_date","value"]).sort_values(["observation_date","available_date"])
    q=q.drop_duplicates("observation_date",keep="last")
    return q.set_index("observation_date").value.astype(float)

def lastv(s): return float(s.iloc[-1]) if len(s) else np.nan

def delta_months(s,months):
    if len(s)<2:return np.nan
    cutoff=s.index[-1]-pd.DateOffset(months=months); p=s[s.index<=cutoff]
    return float(s.iloc[-1]-p.iloc[-1]) if len(p) else np.nan

def build_macro(d,decision,asof):
    pmi=hist_series(d,"PMI","CN",asof); cpi=hist_series(d,"CPI_yoy","CN",asof)
    ppi=hist_series(d,"PPI_yoy","CN",asof); m2=hist_series(d,"M2_yoy","CN",asof)
    gdp=hist_series(d,"GDP_yoy","CN",asof); lpr=hist_series(d,"LPR_1Y","CN",asof)
    rrr=hist_series(d,"RRR_change","CN",asof)
    pv,pd3=lastv(pmi),delta_months(pmi,3); cv,cd3=lastv(cpi),delta_months(cpi,3)
    ppv,ppd3=lastv(ppi),delta_months(ppi,3); mv,md3=lastv(m2),delta_months(m2,3)
    lpr6=delta_months(lpr,6); recent=rrr[rrr.index>=asof-pd.Timedelta(days=180)]
    pol=0.0
    if np.isfinite(lpr6): pol+=0.6*np.clip(-lpr6/0.0025,-1,1)
    if len(recent): pol+=0.4*np.clip(-float(recent.sum())/0.5,-1,1)
    gu=bool(np.isfinite(pv) and np.isfinite(pd3) and pv>=50 and pd3>=0)
    gw=bool(np.isfinite(pv) and np.isfinite(pd3) and (pv<50 or pd3<=-0.5))
    parts=[]
    if np.isfinite(cd3):parts.append(cd3)
    if np.isfinite(ppd3):parts.append(ppd3/3)
    idir=float(np.mean(parts)) if parts else 0.0; iu,idd=idir>0.15,idir<-0.15
    if gu and idd:q="Goldilocks"
    elif gu and iu:q="Reflation"
    elif gw and iu:q="Stagflation"
    elif gw and idd:q="Deflation"
    else:q="Mixed"
    cw=bool(np.isfinite(md3) and md3<0); cs=bool(np.isfinite(md3) and md3>=0)
    s=hist_series(d,"close","000300",asof); price=float(s.iloc[-1]); ma120=float(s.iloc[-120:].mean())
    r20=float(price/s.iloc[-21]-1); r60=float(price/s.iloc[-61]-1); below=price<ma120
    desired="Neutral"
    if gu and cs and (not below) and r60>0: desired="Risk-On"
    if gw and (cw or q=="Stagflation") and r60<=0: desired="Risk-Off"
    if below and r20<0: desired="Risk-Off"
    return {"quadrant":q,"desired_regime":desired,"GDP_yoy":lastv(gdp),"PMI":pv,"PMI_3m_change":pd3,
            "CPI_yoy":cv,"CPI_3m_change":cd3,"PPI_yoy":ppv,"PPI_3m_change":ppd3,
            "M2_yoy":mv,"M2_3m_change":md3,"policy_easing_score":pol,
            "CSI300_MA120":ma120,"CSI300_ret20":r20,"CSI300_ret60":r60,"CSI300_below_MA120":below}

def recovery_override(row, mode):
    """Return experimental desired regime and reason. Uses only decision-time fields."""
    des=row.desired_regime; reason="baseline"
    below=bool(row.CSI300_below_MA120); r20=float(row.CSI300_ret20); pmi3=float(row.PMI_3m_change) if pd.notna(row.PMI_3m_change) else np.nan
    pol=float(row.policy_easing_score) if pd.notna(row.policy_easing_score) else 0.0
    if des=="Risk-Off" and below and r20>0:
        if mode in ("rebound_policy","combined") and pol>=0:
            des="Neutral"; reason="low_rebound_policy_nonnegative"
        elif mode=="rebound_2pct" and r20>=0.02:
            des="Neutral"; reason="low_rebound_ret20_ge_2pct"
        elif mode=="rebound_confirmed" and ((np.isfinite(pmi3) and pmi3>=0) or pol>=0.20):
            des="Neutral"; reason="low_rebound_macro_or_policy_confirmed"
    return des,reason

def apply_regime(m,mode):
    cur="Neutral"; up_count=0; prev_des=None; final=[]; exp_des=[]; reasons=[]
    for row in m.itertuples():
        des,reason=recovery_override(row,mode)
        # Experimental asymmetry: Risk-Off -> Neutral may recover immediately when baseline desired is Neutral.
        immediate_neutral=(mode in ("fast_neutral","combined") and cur=="Risk-Off" and des=="Neutral")
        if REGIME_LEVEL[des]<REGIME_LEVEL[cur]:
            cur=des;up_count=0
        elif REGIME_LEVEL[des]>REGIME_LEVEL[cur]:
            if immediate_neutral:
                cur="Neutral";up_count=0;reason=reason+"+immediate_RiskOff_to_Neutral"
            else:
                up_count=up_count+1 if des==prev_des else 1
                if up_count>=2:
                    cur=LEVEL_REGIME[min(REGIME_LEVEL[cur]+1,REGIME_LEVEL[des])];up_count=0
        else: up_count=0
        final.append(cur); exp_des.append(des); reasons.append(reason); prev_des=des
    return final,exp_des,reasons

def perf(r):
    r=pd.Series(r).astype(float);nav=(1+r).cumprod();total=float(nav.iloc[-1]-1);yrs=len(r)/24;dd=nav/nav.cummax()-1
    sd=float(r.std(ddof=1)); sh=float(r.mean()/sd*np.sqrt(24)) if sd>0 else np.nan
    return {"total_return":total,"annualized_return":float((1+total)**(1/yrs)-1),"annualized_volatility":float(sd*np.sqrt(24)),"sharpe":sh,"max_drawdown":float(dd.min()),"positive_node_rate":float((r>0).mean())}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--input',required=True); ap.add_argument('--factors',required=True)
    ap.add_argument('--start',default='2021-01'); ap.add_argument('--end',default='2026-06'); ap.add_argument('--cost-bps',type=float,default=10.0)
    ap.add_argument('--recovery-mode',choices=MODES,default='baseline'); ap.add_argument('--output-dir',required=True)
    args=ap.parse_args();out=Path(args.output_dir);out.mkdir(parents=True,exist_ok=True)
    d=pd.read_csv(args.input,low_memory=False); d['entity']=d.entity.map(norm_code);d['observation_date']=pd.to_datetime(d.observation_date,errors='coerce');d['available_date']=pd.to_datetime(d.available_date,errors='coerce');d['value']=pd.to_numeric(d.value,errors='coerce')
    p=pd.read_csv(args.factors);p['decision_date']=pd.to_datetime(p.decision_date);p['as_of_date']=pd.to_datetime(p.as_of_date);p['asset']=p.asset.map(norm_code)
    p=p[(p.decision_date.dt.to_period('M')>=pd.Period(args.start))&(p.decision_date.dt.to_period('M')<=pd.Period(args.end))]
    nodes=p[['decision_date','as_of_date']].drop_duplicates().sort_values('decision_date').reset_index(drop=True)
    macros=[build_macro(d,r.decision_date,r.as_of_date) for r in nodes.itertuples()];m=pd.concat([nodes,pd.DataFrame(macros)],axis=1)
    final,exp_des,reasons=apply_regime(m,args.recovery_mode);m['experimental_desired_regime']=exp_des;m['recovery_reason']=reasons;m['regime']=final
    m.to_csv(out/f'V7.6_{args.recovery_mode}_macro_regime_132_nodes.csv',index=False)
    c=d[(d.feature=='close')&d.entity.isin(ASSETS)].copy().sort_values(['entity','observation_date','available_date']).drop_duplicates(['entity','observation_date'],keep='last');px=c.pivot(index='observation_date',columns='entity',values='value').sort_index()
    end_date=pd.Period(args.end).end_time.normalize();prev_w={a:0.0 for a in ASSETS};prev_cash=1.0;rows=[]
    for i,n in m.iterrows():
        dt=n.decision_date;g=p[p.decision_date==dt].set_index('asset').reindex(ASSETS).copy();g['alpha']=0.55*g['valuation']+0.45*g['flow'];risk=REGIME_ALLOC[n.regime]
        ranked=g[['alpha']].reset_index().sort_values(['alpha','asset'],ascending=[False,False],kind='mergesort').asset.tolist();raw={a:0.0 for a in ASSETS}
        for pts,a in zip(RANK_POINTS,ranked):raw[a]=risk*pts/RANK_POINTS.sum()
        if i:
            blend={a:0.5*prev_w[a]+0.5*raw[a] for a in ASSETS};ss=sum(blend.values());w={a:blend[a]*risk/ss for a in ASSETS}
        else:w=raw.copy()
        cash=1-sum(w.values());turn=.5*(sum(abs(w[a]-prev_w[a]) for a in ASSETS)+abs(cash-prev_cash));cost=turn*args.cost_bps/10000
        nxt=m.decision_date.iloc[i+1] if i+1<len(m) else end_date;rr={}
        for a in ASSETS:
            s=px[a].dropna();s0=s[s.index<=dt];s1=s[s.index<=nxt];rr[a]=float(s1.iloc[-1]/s0.iloc[-1]-1)
        gross=sum(w[a]*rr[a] for a in ASSETS);net=gross-cost
        row={'decision_date':dt.date(),'as_of_date':n.as_of_date.date(),'period_end':pd.Timestamp(nxt).date(),'quadrant':n.quadrant,'desired_regime':n.desired_regime,'experimental_desired_regime':n.experimental_desired_regime,'recovery_reason':n.recovery_reason,'regime':n.regime,'risk_allocation':risk,'cash_weight':cash,'turnover':turn,'transaction_cost':cost,'gross_return':gross,'net_return':net,'benchmark_return':rr['000300']}
        for a in ASSETS:row[f'w_{a}']=w[a];row[f'r_{a}']=rr[a]
        rows.append(row);prev_w=w;prev_cash=cash
    r=pd.DataFrame(rows);r['net_nav']=(1+r.net_return).cumprod();r.to_csv(out/f'V7.6_{args.recovery_mode}_132_nodes_results.csv',index=False)
    summ={'version':'V7.6-EXPERIMENTAL-Recovery','recovery_mode':args.recovery_mode,'net':perf(r.net_return),'mean_turnover_per_node':float(r.turnover.mean()),'total_transaction_cost_nav_points':float(r.transaction_cost.sum()),'cost_bps_one_way':args.cost_bps}
    (out/f'V7.6_{args.recovery_mode}_summary.json').write_text(json.dumps(summ,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(summ,ensure_ascii=False))
if __name__=='__main__':main()
