
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from scripts.adapters.shenzhen_open_data import ShenzhenOpenDataAdapter
from scripts.adapters.leyoujia_huangpu import LeyoujiaHuangpuAdapter
P=json.loads((ROOT/"config/projects.json").read_text(encoding="utf-8"))["huangpuyayuan"]; P["id"]="huangpuyayuan"
o=ShenzhenOpenDataAdapter(ROOT/"data/raw").fetch(P)
print("OFFICIAL")
for k,v in o["datasets"].items(): print(k,"status=",v.get("status"),"api_status=",v.get("api_status"),"records=",len(v.get("records",[])))
p=LeyoujiaHuangpuAdapter(ROOT/"data/raw").fetch(P)
print("\nPLATFORM")
for ph,v in p["phases"].items(): print(ph,"sale=",v["sale_status"],len(v["listings"]),"rent=",v["rent_status"],len(v["rents"]))
