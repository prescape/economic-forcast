
from pathlib import Path
import json, sys
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from scripts.adapters.wuhan_official import WuhanOfficialHousingAdapter

projects = json.loads((ROOT/"config/projects.json").read_text(encoding="utf-8"))
adapter = WuhanOfficialHousingAdapter(ROOT/"data/raw")
for pid in ["chengningfu","chubaoli"]:
    p = dict(projects[pid]); p["id"] = pid
    d = adapter.fetch(p)
    print("\n==", pid, "==")
    print("status:", d["status"], "matches:", len(d["matches"]))
    for h in d["hosts"]:
        print(h["host"], "status=", h["home_status"], "blocked=", h["blocked_reason"], "endpoints=", h["endpoint_count"])
