
REQUIRED = ["target_unit","filing_price","actual_discount","subsidy_stackability","floor","orientation","delivery_node"]

def verify(checks):
    missing = [k for k in REQUIRED if not checks.get(k, False)]
    if not missing:
        status = "PASS"
    elif len(missing) >= 4:
        status = "FAIL"
    else:
        status = "VERIFY_BEFORE_BUY"
    return {"status": status, "missing_checks": missing, "checks": checks}

def enforce_on_action(action, gate_status):
    if gate_status == "PASS":
        return action
    if action == "STRONG_BUY":
        return "NEGOTIATE_BUY"
    if action == "BUY":
        return "VERIFY_BEFORE_BUY"
    return action
