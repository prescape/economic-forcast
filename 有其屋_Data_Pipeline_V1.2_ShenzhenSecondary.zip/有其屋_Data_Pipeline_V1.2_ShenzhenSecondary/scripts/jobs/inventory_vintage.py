
from datetime import datetime
from scripts.core.normalize import inventory_bucket

def enrich_inventory_vintage(records, permit_map):
    out = []
    for r in records:
        p = permit_map.get(r.get("permit_id"))
        age = None
        if p and r.get("observed_at"):
            age = (datetime.fromisoformat(r["observed_at"]) - datetime.fromisoformat(p["permit_date"])).days
        x = dict(r)
        x["inventory_age_days"] = age
        x["inventory_vintage_bucket"] = inventory_bucket(age)
        out.append(x)
    return out
