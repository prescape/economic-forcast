
from pathlib import Path
from datetime import datetime, timezone
import json,sys
ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from scripts.adapters.shenzhen_open_data import ShenzhenOpenDataAdapter
from scripts.adapters.shenzhen_open_data_normalizer import normalize_official
from scripts.adapters.leyoujia_huangpu import LeyoujiaHuangpuAdapter
from scripts.core.storage import append_jsonl,write_snapshot
from scripts.core.evidence import make_evidence
PROJECTS=json.loads((ROOT/"config/projects.json").read_text(encoding="utf-8"))

def add_evidence(record,field_name,source,tier,status,pit_status,confidence,note):
    ev=make_evidence(project_id="huangpuyayuan",field_name=field_name,
        raw_value={k:v for k,v in record.items() if not k.startswith("_")},
        source=source,source_tier=tier,observed_at=str(record.get("observed_at") or datetime.now(timezone.utc).date().isoformat()),
        verification_status=status,pit_status=pit_status,confidence=confidence,notes=note)
    record["evidence_id"]=ev["evidence_id"]; append_jsonl(ROOT/"data/evidence/evidence_registry.jsonl",ev); return record

def run(mode="weekly"):
    p=dict(PROJECTS["huangpuyayuan"]); p["id"]="huangpuyayuan"
    official=ShenzhenOpenDataAdapter(ROOT/"data/raw").fetch(p); norm=normalize_official("huangpuyayuan",official["datasets"])
    for r in norm["market_context"]:
        add_evidence(r,"official_market_context","深圳市政府数据开放平台","S","VERIFIED","PIT_VERIFIED",0.95,"Official open-data record.")
        append_jsonl(ROOT/"data/pit/market_context/shenzhen.jsonl",r)
    for r in norm["rents"]:
        add_evidence(r,"official_rent_reference","深圳市政府数据开放平台","S","VERIFIED","PIT_VERIFIED",0.95,"Official reference rent; not an individual signed rent.")
        append_jsonl(ROOT/"data/pit/rents/huangpuyayuan_official.jsonl",r)
    platform=LeyoujiaHuangpuAdapter(ROOT/"data/raw").fetch(p); lc=rc=0
    for phase,pd in platform["phases"].items():
        for r in pd["listings"]:
            add_evidence(r,"secondary_listing","乐有家","B","CORROBORATED","CURRENT_ONLY",0.75,"Public asking listing; not transaction price.")
            append_jsonl(ROOT/"data/pit/secondary_listings/huangpuyayuan.jsonl",r); lc+=1
        for r in pd["rents"]:
            add_evidence(r,"asking_rent","乐有家","B","CORROBORATED","CURRENT_ONLY",0.75,"Public asking rent; not signed rent.")
            append_jsonl(ROOT/"data/pit/rents/huangpuyayuan_platform.jsonl",r); rc+=1
    snap={"project_id":"huangpuyayuan","job":"shenzhen_secondary_"+mode,"run_at":datetime.now(timezone.utc).isoformat(),
        "official_dataset_status":{k:v.get("status") for k,v in official["datasets"].items()},
        "official_market_records":len(norm["market_context"]),"official_rent_records":len(norm["rents"]),
        "platform_listing_records":lc,"platform_rent_records":rc,
        "platform_phase_status":{ph:{"sale":x["sale_status"],"rent":x["rent_status"]} for ph,x in platform["phases"].items()}}
    sp=write_snapshot(ROOT/"data/snapshots","huangpuyayuan","shenzhen_secondary_"+mode,snap); snap["snapshot"]=str(sp)
    append_jsonl(ROOT/"logs/pipeline_runs.jsonl",snap); print(json.dumps(snap,ensure_ascii=False,indent=2))
if __name__=="__main__":
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument("--mode",choices=["daily","weekly"],default="weekly"); args=ap.parse_args(); run(args.mode)
