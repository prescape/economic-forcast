
from collections import defaultdict
from datetime import datetime

WINDOWS = [7,30,60,90,180]

def build_absorption_curve(permit_records, sales_records):
    permits = {p["building_id"]: p for p in permit_records}
    grouped = defaultdict(list)
    for s in sales_records:
        grouped[s["building_id"]].append(s)
    out = []
    for building_id, permit in permits.items():
        pdate = datetime.fromisoformat(permit["permit_date"])
        supply = permit["supply_units"]
        for w in WINDOWS:
            eligible = []
            for s in grouped.get(building_id, []):
                od = datetime.fromisoformat(s["observed_at"])
                if 0 <= (od-pdate).days <= w:
                    eligible.append(s)
            sold = max([x["sold_units"] for x in eligible], default=None)
            out.append({
                "project_id": permit["project_id"],
                "building_id": building_id,
                "permit_id": permit.get("permit_id"),
                "window_days": w,
                "sold_units": sold,
                "supply_units": supply,
                "absorption_rate": None if sold is None or not supply else sold/supply,
                "status": "MISSING" if sold is None else "OBSERVED"
            })
    return out
