
def build_graph(evidence_records):
    nodes = {e["evidence_id"]: e for e in evidence_records}
    edges = []
    missing_parents = []
    for e in evidence_records:
        for p in e.get("parent_evidence_ids", []):
            edges.append((p, e["evidence_id"]))
            if p not in nodes:
                missing_parents.append({"child": e["evidence_id"], "missing_parent": p})
    return {"nodes": nodes, "edges": edges, "missing_parents": missing_parents}

def trace_upstream(graph, evidence_id):
    parents = {}
    for p,c in graph["edges"]:
        parents.setdefault(c, []).append(p)
    seen, stack = set(), [evidence_id]
    while stack:
        x = stack.pop()
        if x in seen: continue
        seen.add(x)
        stack.extend(parents.get(x, []))
    return [graph["nodes"][x] for x in seen if x in graph["nodes"]]
