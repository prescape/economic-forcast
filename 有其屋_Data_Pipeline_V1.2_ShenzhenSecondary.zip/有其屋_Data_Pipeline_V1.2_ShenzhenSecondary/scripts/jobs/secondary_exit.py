
def secondary_exit_facts(project_units=None, listing_count=None, monthly_transactions=None,
                         median_days_on_market=None, investor_ratio=None):
    # No generalized score here. Return auditable facts + unknowns.
    result = {
        "project_units": project_units,
        "listing_count": listing_count,
        "monthly_transactions": monthly_transactions,
        "median_days_on_market": median_days_on_market,
        "investor_ratio": investor_ratio,
        "investor_ratio_status": "MODEL_ASSUMPTION" if investor_ratio is not None else "MISSING"
    }
    if listing_count is not None and monthly_transactions:
        result["months_of_inventory"] = listing_count / monthly_transactions
    else:
        result["months_of_inventory"] = None
    return result
