
from pathlib import Path
from datetime import datetime, timezone
import json, sys
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from scripts.adapters.wuhan_official import WuhanOfficialHousingAdapter
from scripts.adapters.wuhan_official_normalizer import normalize_tables
from scripts.core.storage import append_jsonl, write_snapshot
from scripts.core.evidence import make_evidence

PROJECTS = json.loads((ROOT/"config/projects.json").read_text(encoding="utf-8"))

def run_one(project_id):
    p = dict(PROJECTS[project_id]); p["id"] = project_id
    adapter = WuhanOfficialHousingAdapter(ROOT/"data/raw")
    diag = adapter.fetch(p)
    tables = []
    for m in diag.get("matches", []):
        tables.extend(m.get("tables", []))
    norm = normalize_tables(project_id, tables)
    for kind, rows in norm.items():
        for r in rows:
            ev = make_evidence(
                project_id=project_id,
                field_name="official_" + kind,
                raw_value={k:v for k,v in r.items() if not k.startswith("_")},
                source=adapter.source_name, source_tier="S",
                observed_at=r.get("observed_at") or datetime.now(timezone.utc).date().isoformat(),
                verification_status="VERIFIED", pit_status="PIT_VERIFIED",
                confidence=0.95,
                notes="Parsed only from explicit labels in Wuhan official public query response."
            )
            r["evidence_id"] = ev["evidence_id"]
            append_jsonl(ROOT/"data/evidence/evidence_registry.jsonl", ev)
            target = {
                "permits": ROOT/"data/pit/permits"/f"{project_id}.jsonl",
                "sales": ROOT/"data/pit/newhouse_sales"/f"{project_id}.jsonl",
                "inventory": ROOT/"data/pit/inventory"/f"{project_id}.jsonl"
            }[kind]
            append_jsonl(target, r)
    snapshot = {
        "project_id": project_id, "job": "wuhan_official_daily",
        "run_at": datetime.now(timezone.utc).isoformat(),
        "adapter_status": diag.get("status"),
        "matches": len(diag.get("matches", [])),
        "normalized_counts": {k: len(v) for k,v in norm.items()},
        "diagnostics": diag
    }
    sp = write_snapshot(ROOT/"data/snapshots", project_id, "wuhan_official_daily", snapshot)
    snapshot["snapshot"] = str(sp)
    append_jsonl(ROOT/"logs/pipeline_runs.jsonl", snapshot)
    return snapshot

def main():
    out = {pid: run_one(pid) for pid in ["chengningfu","chubaoli"]}
    print(json.dumps(out, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
