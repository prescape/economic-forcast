
import argparse, json
from pathlib import Path
from datetime import datetime, timezone
from scripts.core.storage import write_snapshot, append_jsonl

ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT/"config/projects.json").read_text(encoding="utf-8"))

def run(project_id, job):
    if project_id not in CONFIG:
        raise SystemExit(f"Unknown project: {project_id}")
    project = CONFIG[project_id]
    payload = {
        "project_id": project_id,
        "project": project,
        "job": job,
        "run_at": datetime.now(timezone.utc).isoformat(),
        "status": "FRAMEWORK_ONLY",
        "message": "No live source adapter configured. No data fabricated."
    }
    snap = write_snapshot(ROOT/"data/snapshots", project_id, job, payload)
    append_jsonl(ROOT/"logs/pipeline_runs.jsonl", payload | {"snapshot": str(snap)})
    print(json.dumps(payload | {"snapshot": str(snap)}, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", required=True, choices=CONFIG.keys())
    ap.add_argument("--job", required=True, choices=["daily","weekly","monthly","event","transaction"])
    args = ap.parse_args()
    run(args.project, args.job)
