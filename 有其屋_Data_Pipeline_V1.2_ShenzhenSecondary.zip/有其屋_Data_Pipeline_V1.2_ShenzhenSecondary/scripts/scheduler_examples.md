# 调度示例

## cron
```cron
# 每天 08:10 新房项目
10 8 * * * cd ~/.openclaw/workspace/data/youqiwu && python3 scripts/run_pipeline.py --project chengningfu --job daily
15 8 * * * cd ~/.openclaw/workspace/data/youqiwu && python3 scripts/run_pipeline.py --project chubaoli --job daily

# 每周一 09:00 二手/租金
0 9 * * 1 cd ~/.openclaw/workspace/data/youqiwu && python3 scripts/run_pipeline.py --project huangpuyayuan --job weekly

# 每月 2 日 09:30 市场上下文
30 9 2 * * cd ~/.openclaw/workspace/data/youqiwu && python3 scripts/run_pipeline.py --project chubaoli --job monthly
```


## 武汉官方取证/网签 Daily Job（V1.1）
```cron
20 8 * * * cd ~/.openclaw/workspace/data/youqiwu && python3 scripts/jobs/wuhan_official_daily.py >> logs/wuhan_official_cron.log 2>&1
```

首次部署：
```bash
pip install -r requirements.txt
python3 scripts/test_wuhan_official_connection.py
python3 scripts/jobs/wuhan_official_daily.py
```


## 深圳黄埔雅苑二手房（V1.2）
```cron
10 9 * * 1,4 cd ~/.openclaw/workspace/data/youqiwu && python3 scripts/jobs/shenzhen_huangpu_secondary.py --mode weekly >> logs/shenzhen_huangpu_cron.log 2>&1
```
首次：
```bash
python3 scripts/test_shenzhen_secondary_connection.py
python3 scripts/jobs/shenzhen_huangpu_secondary.py --mode weekly
```
