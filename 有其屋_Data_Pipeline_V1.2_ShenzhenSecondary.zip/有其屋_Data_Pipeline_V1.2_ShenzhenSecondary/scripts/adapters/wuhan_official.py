
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import urljoin
import json, re, hashlib
import requests
from bs4 import BeautifulSoup
from .base import BaseAdapter

@dataclass
class FetchResult:
    url: str
    status_code: int | None
    content_type: str | None
    text: str
    blocked_reason: str | None = None

class WuhanOfficialHousingAdapter(BaseAdapter):
    source_name = "武汉市住房和城市更新局-商品房公开查询"
    source_tier = "S"

    def __init__(self, raw_root, timeout=20):
        self.raw_root = Path(raw_root)
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "YouQiWuDataPipeline/1.1 (+public-real-estate-research)",
            "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
        })
        self.hosts = ["https://spfxm.whfgxx.org.cn/", "http://spfxm.whfgxx.org.cn/"]

    def _now(self):
        return datetime.now(timezone.utc)

    def _get(self, url):
        try:
            r = self.session.get(url, timeout=self.timeout, allow_redirects=True)
            low = r.text.lower()
            blocked = None
            if any(x in low for x in ["captcha", "验证码", "访问过于频繁", "请登录"]):
                blocked = "LOGIN_OR_ANTI_BOT"
            return FetchResult(r.url, r.status_code, r.headers.get("content-type"), r.text, blocked)
        except Exception as e:
            return FetchResult(url, None, None, "", "NETWORK_ERROR:" + str(e))

    def _save_raw(self, project_id, kind, result):
        now = self._now()
        day = now.strftime("%Y-%m-%d")
        ts = now.strftime("%Y%m%dT%H%M%SZ")
        h = hashlib.sha256((result.url + result.text[:5000]).encode("utf-8", "ignore")).hexdigest()[:10]
        ext = ".json" if "json" in (result.content_type or "").lower() else ".html"
        path = self.raw_root / "official" / "wuhan" / day / project_id / f"{kind}_{ts}_{h}{ext}"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(result.text, encoding="utf-8", errors="ignore")
        meta = {
            "url": result.url,
            "status_code": result.status_code,
            "content_type": result.content_type,
            "retrieved_at": now.isoformat(),
            "blocked_reason": result.blocked_reason,
            "sha256": hashlib.sha256(result.text.encode("utf-8", "ignore")).hexdigest()
        }
        path.with_suffix(path.suffix + ".meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    def _discover(self, base_url):
        result = self._get(base_url)
        if result.status_code is None or result.blocked_reason:
            return result, []
        soup = BeautifulSoup(result.text, "html.parser")
        endpoints = []
        for form in soup.find_all("form"):
            action = urljoin(result.url, form.get("action") or "")
            method = (form.get("method") or "GET").upper()
            fields = []
            for inp in form.find_all(["input", "select", "textarea"]):
                if inp.get("name"):
                    fields.append({"name": inp.get("name"), "type": inp.get("type"), "value": inp.get("value")})
            endpoints.append({"kind": "form", "url": action, "method": method, "fields": fields})
        for a in soup.find_all("a", href=True):
            txt = " ".join(a.stripped_strings)
            href = urljoin(result.url, a["href"])
            if any(k in txt for k in ["项目", "预售", "商品房", "许可证"]) or any(k in href.lower() for k in ["project","presale","permit","spfxm"]):
                endpoints.append({"kind": "link", "url": href, "text": txt})
        seen, uniq = set(), []
        for e in endpoints:
            key = (e.get("kind"), e.get("url"), e.get("method"))
            if key not in seen:
                seen.add(key)
                uniq.append(e)
        return result, uniq

    def _score_endpoint(self, ep):
        blob = json.dumps(ep, ensure_ascii=False).lower()
        return sum(1 for token in ["项目","project","预售","permit","presale","许可证","search","query"] if token in blob)

    def _candidate_query_params(self, endpoint, keyword):
        fields = [f["name"] for f in endpoint.get("fields", [])]
        names = [x for x in fields if re.search(r"(project|xmmc|name|mc|keyword|key|query|search)", x, re.I)]
        names += ["projectName","xmmc","name","keyword","keyWord","searchValue"]
        out, seen = [], set()
        for name in names:
            item = {name: keyword}
            s = json.dumps(item, ensure_ascii=False, sort_keys=True)
            if s not in seen:
                seen.add(s)
                out.append(item)
        return out[:10]

    def _search_get(self, url, params):
        try:
            r = self.session.get(url, params=params, timeout=self.timeout, allow_redirects=True)
            low = r.text.lower()
            blocked = None
            if any(x in low for x in ["captcha", "验证码", "访问过于频繁", "请登录"]):
                blocked = "LOGIN_OR_ANTI_BOT"
            return FetchResult(r.url, r.status_code, r.headers.get("content-type"), r.text, blocked)
        except Exception as e:
            return FetchResult(url, None, None, "", "NETWORK_ERROR:" + str(e))

    def _extract_tables(self, html, project_keywords):
        soup = BeautifulSoup(html, "html.parser")
        records = []
        for idx, table in enumerate(soup.find_all("table")):
            rows = []
            for tr in table.find_all("tr"):
                cells = [" ".join(td.stripped_strings) for td in tr.find_all(["th","td"])]
                if cells:
                    rows.append(cells)
            blob = "\n".join("\t".join(r) for r in rows)
            if any(k in blob for k in project_keywords):
                records.append({"table_index": idx, "rows": rows})
        return records

    def fetch(self, project):
        project_id = project.get("id") or project.get("project_id") or "unknown"
        q = project.get("official_query") or {}
        keywords = [k for k in (q.get("keywords") or [project.get("name")]) if k]
        diagnostics = {
            "project_id": project_id,
            "source": self.source_name,
            "source_tier": self.source_tier,
            "run_at": self._now().isoformat(),
            "hosts": [], "matches": [], "status": "NO_PUBLIC_MATCH"
        }
        for host in self.hosts:
            home, endpoints = self._discover(host)
            home_path = self._save_raw(project_id, "portal_discovery", home)
            diagnostics["hosts"].append({
                "host": host, "home_status": home.status_code,
                "blocked_reason": home.blocked_reason,
                "raw_path": str(home_path), "endpoint_count": len(endpoints)
            })
            if home.status_code is None or home.blocked_reason:
                continue
            ranked = sorted(endpoints, key=self._score_endpoint, reverse=True)
            for ep in ranked[:20]:
                if ep["kind"] == "link":
                    rr = self._get(ep["url"])
                    rp = self._save_raw(project_id, "candidate", rr)
                    tables = self._extract_tables(rr.text, keywords) if rr.text else []
                    if tables:
                        diagnostics["matches"].append({"url": rr.url, "params": None, "raw_path": str(rp), "tables": tables})
                        diagnostics["status"] = "MATCH_FOUND"
                if ep["kind"] == "form" and ep.get("method") == "GET":
                    for kw in keywords:
                        for params in self._candidate_query_params(ep, kw):
                            rr = self._search_get(ep["url"], params)
                            rp = self._save_raw(project_id, "query", rr)
                            tables = self._extract_tables(rr.text, keywords) if rr.text else []
                            if tables:
                                diagnostics["matches"].append({"url": rr.url, "params": params, "raw_path": str(rp), "tables": tables})
                                diagnostics["status"] = "MATCH_FOUND"
                                break
        return diagnostics
