
from datetime import datetime, timezone

def _pick(row,candidates):
    for c in candidates:
        for k,v in row.items():
            if c in str(k): return v
    return None

def normalize_official(project_id,datasets):
    market_context=[]; rents=[]; now=datetime.now(timezone.utc).isoformat()
    for ds,payload in datasets.items():
        for row in payload.get("records",[]):
            if "二手房成交信息" in ds:
                date=_pick(row,["日期","统计日期","成交日期","时间"])
                volume=_pick(row,["成交套数","套数","成交量"])
                area=_pick(row,["成交面积","面积"])
                if date is not None and volume is not None:
                    market_context.append({"city":"深圳","district":None,"submarket":None,"scope":"CITY",
                        "metric":"secondary_daily_transactions","value":volume,"unit":"套",
                        "observed_at":str(date),"retrieved_at":now,"_dataset":ds,"_raw":row})
                if date is not None and area is not None:
                    market_context.append({"city":"深圳","district":None,"submarket":None,"scope":"CITY",
                        "metric":"secondary_daily_transaction_area","value":area,"unit":"㎡",
                        "observed_at":str(date),"retrieved_at":now,"_dataset":ds,"_raw":row})
            elif "小区租赁参考价格" in ds:
                name=_pick(row,["小区名称","项目名称","住宅小区"])
                if name and "黄埔雅苑" in str(name):
                    value=_pick(row,["租赁参考价格","参考租金","租金"])
                    try: val=float(str(value).replace(",",""))
                    except Exception: val=None
                    if val is not None:
                        rents.append({"project_id":project_id,"rent_id":"official-reference-"+str(name),
                            "phase":str(name).replace("黄埔雅苑","").strip() or None,
                            "area_sqm":1.0,"monthly_rent":val,"rent_per_sqm":val,"rent_type":"DISTRICT_PROXY",
                            "observed_at":now[:10],"retrieved_at":now,"_dataset":ds,"_raw":row})
    return {"market_context":market_context,"rents":rents}
