
from pathlib import Path
from datetime import datetime, timezone
import os, json, hashlib, csv, requests
from .base import BaseAdapter

class ShenzhenOpenDataAdapter(BaseAdapter):
    source_name="深圳市政府数据开放平台"
    source_tier="S"
    def __init__(self, raw_root, timeout=20):
        self.raw_root=Path(raw_root); self.timeout=timeout
        self.api_url=os.getenv("SZ_OPENDATA_API_URL")
        self.token=os.getenv("SZ_OPENDATA_TOKEN")
        self.download_dir=Path(os.getenv("SZ_OPENDATA_DOWNLOAD_DIR", str(self.raw_root/"official"/"shenzhen"/"manual_downloads")))
    def _save(self, project_id,dataset,text,source_ref,ext=".json"):
        now=datetime.now(timezone.utc); day=now.strftime("%Y-%m-%d"); ts=now.strftime("%Y%m%dT%H%M%SZ")
        h=hashlib.sha256((source_ref+text[:5000]).encode("utf-8","ignore")).hexdigest()[:10]
        p=self.raw_root/"official"/"shenzhen"/day/project_id/f"{dataset}_{ts}_{h}{ext}"
        p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text,encoding="utf-8",errors="ignore")
        p.with_suffix(p.suffix+".meta.json").write_text(json.dumps({
            "source":self.source_name,"source_tier":"S","dataset":dataset,"source_ref":source_ref,
            "retrieved_at":now.isoformat(),"sha256":hashlib.sha256(text.encode("utf-8","ignore")).hexdigest()
        },ensure_ascii=False,indent=2),encoding="utf-8")
        return p
    def fetch_api(self,project,dataset):
        if not self.api_url: return {"status":"API_NOT_CONFIGURED","records":[]}
        headers={}
        if self.token: headers["Authorization"]="Bearer "+self.token
        try:
            r=requests.get(self.api_url,params={"dataset":dataset},headers=headers,timeout=self.timeout)
            self._save(project["id"],dataset,r.text,r.url,".json")
            if r.status_code!=200: return {"status":f"HTTP_{r.status_code}","records":[]}
            try: data=r.json()
            except Exception: return {"status":"NON_JSON_RESPONSE","records":[]}
            if isinstance(data,list): records=data
            elif isinstance(data,dict): records=data.get("data") or data.get("rows") or data.get("records") or []
            else: records=[]
            return {"status":"OK","records":records}
        except Exception as e:
            return {"status":"NETWORK_ERROR:"+str(e),"records":[]}
    def fetch_downloads(self,project,dataset):
        if not self.download_dir.exists(): return {"status":"NO_DOWNLOAD_DIR","records":[]}
        records=[]; matched=[]
        for p in self.download_dir.iterdir():
            if not p.is_file() or dataset not in p.name: continue
            matched.append(str(p))
            try:
                if p.suffix.lower()==".json":
                    obj=json.loads(p.read_text(encoding="utf-8")); records.extend(obj if isinstance(obj,list) else [obj])
                elif p.suffix.lower()==".csv":
                    with p.open("r",encoding="utf-8-sig",newline="") as f: records.extend(list(csv.DictReader(f)))
            except Exception:
                pass
        return {"status":"OK" if matched else "NO_MATCHING_DOWNLOAD","records":records,"files":matched}
    def fetch(self,project):
        out={"project_id":project["id"],"source":self.source_name,"datasets":{}}
        for ds in project.get("official_query",{}).get("official_datasets",[]):
            api=self.fetch_api(project,ds)
            if api["records"]: out["datasets"][ds]=api
            else:
                dl=self.fetch_downloads(project,ds); dl["api_status"]=api["status"]; out["datasets"][ds]=dl
        return out
