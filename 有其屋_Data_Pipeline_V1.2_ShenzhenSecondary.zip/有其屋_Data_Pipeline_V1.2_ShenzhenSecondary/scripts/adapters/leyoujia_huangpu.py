
from pathlib import Path
from datetime import datetime, timezone
import requests,re,json,hashlib
from bs4 import BeautifulSoup
from .base import BaseAdapter

class LeyoujiaHuangpuAdapter(BaseAdapter):
    source_name="乐有家-黄埔雅苑公开页面"; source_tier="B"
    def __init__(self,raw_root,timeout=20):
        self.raw_root=Path(raw_root); self.timeout=timeout; self.s=requests.Session()
        self.s.headers.update({"User-Agent":"YouQiWuDataPipeline/1.2 (+public-listing-research)"})
    def _save(self,phase,kind,url,text):
        now=datetime.now(timezone.utc); day=now.strftime("%Y-%m-%d"); ts=now.strftime("%Y%m%dT%H%M%SZ")
        h=hashlib.sha256((url+text[:5000]).encode("utf-8","ignore")).hexdigest()[:10]
        p=self.raw_root/"platform"/"leyoujia"/day/"huangpuyayuan"/phase/f"{kind}_{ts}_{h}.html"
        p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text,encoding="utf-8",errors="ignore")
        p.with_suffix(".html.meta.json").write_text(json.dumps({"url":url,"retrieved_at":now.isoformat(),"source_tier":"B"},ensure_ascii=False,indent=2),encoding="utf-8")
        return str(p)
    def _get(self,url):
        try:
            r=self.s.get(url,timeout=self.timeout,allow_redirects=True); low=r.text.lower()
            if any(x in low for x in ["captcha","验证码","访问过于频繁","请登录"]):
                return {"status":"LOGIN_OR_ANTI_BOT","url":r.url,"text":r.text}
            return {"status":"OK" if r.status_code==200 else f"HTTP_{r.status_code}","url":r.url,"text":r.text}
        except Exception as e:
            return {"status":"NETWORK_ERROR:"+str(e),"url":url,"text":""}
    def _extract_sale(self,html,phase):
        text=BeautifulSoup(html,"html.parser").get_text("\n",strip=True); out=[]
        pat=re.compile(r"建筑面积\s*([0-9.]+)㎡(?P<body>.{0,500}?)([0-9]+)万\s*单价\s*([0-9]+)元/㎡",re.S)
        for i,m in enumerate(pat.finditer(text)):
            body=m.group("body"); orient=None
            for o in ["东南","东北","西南","西北","南北","东西","东","南","西","北"]:
                if o in body: orient=o; break
            fm=re.search(r"(低楼层|中楼层|高楼层)\(共([0-9]+)层\)",body)
            out.append({"project_id":"huangpuyayuan","listing_id":f"{phase}-sale-{i}","phase":phase,
                "area_sqm":float(m.group(1)),"asking_total":float(m.group(3))*10000,"asking_unit_price":float(m.group(4)),
                "floor":f"{fm.group(1)}(共{fm.group(2)}层)" if fm else None,"orientation":orient,"listed_at":None,
                "observed_at":datetime.now(timezone.utc).date().isoformat(),"retrieved_at":datetime.now(timezone.utc).isoformat()})
        return out
    def _extract_rent(self,html,phase):
        text=BeautifulSoup(html,"html.parser").get_text("\n",strip=True); out=[]
        pat=re.compile(r"建筑面积\s*([0-9.]+)㎡(?P<body>.{0,400}?)([0-9]+)元/月",re.S)
        for i,m in enumerate(pat.finditer(text)):
            area=float(m.group(1)); rent=float(m.group(3))
            out.append({"project_id":"huangpuyayuan","rent_id":f"{phase}-rent-{i}","phase":phase,
                "area_sqm":area,"monthly_rent":rent,"rent_per_sqm":round(rent/area,2) if area else None,
                "rent_type":"ASKING_RENT","observed_at":datetime.now(timezone.utc).date().isoformat(),
                "retrieved_at":datetime.now(timezone.utc).isoformat()})
        return out
    def fetch(self,project):
        out={"project_id":"huangpuyayuan","source":self.source_name,"phases":{}}
        for phase,cfg in project["platform_sources"]["leyoujia"]["phases"].items():
            cid=cfg["community_id"]; sale_url=f"https://shenzhen.leyoujia.com/xq/detail/esf/{cid}/"; rent_url=f"https://shenzhen.leyoujia.com/xq/detail/zf/{cid}/"
            sres=self._get(sale_url); rres=self._get(rent_url)
            out["phases"][phase]={
                "sale_status":sres["status"],"rent_status":rres["status"],
                "sale_raw":self._save(phase,"sale",sres["url"],sres["text"]) if sres["text"] else None,
                "rent_raw":self._save(phase,"rent",rres["url"],rres["text"]) if rres["text"] else None,
                "listings":self._extract_sale(sres["text"],phase) if sres["status"]=="OK" else [],
                "rents":self._extract_rent(rres["text"],phase) if rres["status"]=="OK" else []}
        return out
