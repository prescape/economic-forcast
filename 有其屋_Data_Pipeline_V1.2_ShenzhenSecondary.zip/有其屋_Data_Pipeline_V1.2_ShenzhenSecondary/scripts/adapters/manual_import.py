
import csv, json
from pathlib import Path
from .base import BaseAdapter

class ManualImportAdapter(BaseAdapter):
    source_name = "MANUAL_IMPORT"
    source_tier = "D"

    def __init__(self, path):
        self.path = Path(path)

    def fetch(self, project):
        if not self.path.exists():
            return []
        if self.path.suffix.lower() == ".json":
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else [data]
        if self.path.suffix.lower() == ".csv":
            with self.path.open("r", encoding="utf-8-sig", newline="") as f:
                return list(csv.DictReader(f))
        return []
