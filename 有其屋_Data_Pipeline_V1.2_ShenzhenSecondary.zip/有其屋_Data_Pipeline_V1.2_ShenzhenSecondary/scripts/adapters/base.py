
from abc import ABC, abstractmethod

class BaseAdapter(ABC):
    source_name = "UNKNOWN"
    source_tier = "D"

    @abstractmethod
    def fetch(self, project):
        """Return raw records. Never fabricate unavailable fields."""
        raise NotImplementedError

    def healthcheck(self):
        return {"ok": True, "source": self.source_name}
