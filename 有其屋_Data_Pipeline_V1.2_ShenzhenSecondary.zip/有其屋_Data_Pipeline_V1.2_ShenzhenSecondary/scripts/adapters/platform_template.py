
from .base import BaseAdapter

class PlatformTemplateAdapter(BaseAdapter):
    source_name = "PLATFORM_TEMPLATE"
    source_tier = "B"

    def fetch(self, project):
        # Respect site terms, login, robots and rate limits.
        # Do not bypass captcha or anti-bot controls.
        return []
