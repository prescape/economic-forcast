
from datetime import datetime, timezone
import re

def _find_header(rows):
    for i, row in enumerate(rows[:5]):
        blob = "|".join(row)
        if any(k in blob for k in ["项目名称","许可证","预售","楼栋","栋号"]):
            return i, row
    return None

def normalize_tables(project_id, tables):
    permits, sales, inventory = [], [], []
    for t in tables:
        rows = t.get("rows") or []
        hdr = _find_header(rows)
        if not hdr:
            continue
        hi, header = hdr
        index = {str(v).strip(): j for j,v in enumerate(header)}
        for row in rows[hi+1:]:
            def val(labels):
                for lab in labels:
                    for h,j in index.items():
                        if lab in h and j < len(row):
                            return row[j].strip()
                return None
            permit_id = val(["许可证号","预售许可证","预售证号"])
            permit_date = val(["发证日期","许可日期","批准日期"])
            building_id = val(["楼栋","栋号","幢号"])
            supply = val(["批准套数","预售套数","供应套数"])
            sold = val(["已售","已签","网签"])
            available = val(["可售","剩余"])
            nowd = datetime.now(timezone.utc).date().isoformat()
            nowt = datetime.now(timezone.utc).isoformat()
            if permit_id and permit_date:
                m = re.search(r"\d+", supply or "")
                permits.append({
                    "project_id": project_id, "permit_id": permit_id,
                    "building_id": building_id or "UNKNOWN", "permit_date": permit_date,
                    "supply_units": int(m.group()) if m else 0,
                    "observed_at": nowd, "retrieved_at": nowt,
                    "_normalization_status": "EXPLICIT_LABELS_ONLY"
                })
            if sold is not None and building_id:
                m = re.search(r"\d+", sold)
                if m:
                    sales.append({
                        "project_id": project_id, "building_id": building_id,
                        "observed_at": nowd, "sold_units": int(m.group()),
                        "retrieved_at": nowt, "_normalization_status": "EXPLICIT_LABELS_ONLY"
                    })
            if available is not None and building_id:
                m = re.search(r"\d+", available)
                if m:
                    inventory.append({
                        "project_id": project_id, "building_id": building_id,
                        "observed_at": nowd, "available_units": int(m.group()),
                        "inventory_vintage_bucket": "UNKNOWN",
                        "retrieved_at": nowt, "_normalization_status": "EXPLICIT_LABELS_ONLY"
                    })
    return {"permits": permits, "sales": sales, "inventory": inventory}
