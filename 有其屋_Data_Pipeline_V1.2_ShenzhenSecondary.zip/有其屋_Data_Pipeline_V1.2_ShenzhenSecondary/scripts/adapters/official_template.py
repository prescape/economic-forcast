
from .base import BaseAdapter

class OfficialTemplateAdapter(BaseAdapter):
    source_name = "OFFICIAL_TEMPLATE"
    source_tier = "S"

    def fetch(self, project):
        # Implement only against lawful public endpoints/files.
        # Expected raw output examples:
        # permits / signed units / official filing prices / saleable units
        return []
