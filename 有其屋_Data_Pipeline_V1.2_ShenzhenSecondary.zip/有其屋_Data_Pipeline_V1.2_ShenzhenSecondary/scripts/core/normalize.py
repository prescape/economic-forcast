
def normalize_unit_price(total_price, area_sqm):
    if not area_sqm:
        return None
    return round(float(total_price) / float(area_sqm), 2)

def inventory_bucket(age_days):
    if age_days is None:
        return "UNKNOWN"
    if age_days <= 30: return "FRESH_0_30D"
    if age_days <= 90: return "NORMAL_31_90D"
    if age_days <= 180: return "AGED_91_180D"
    return "STALE_180D_PLUS"
