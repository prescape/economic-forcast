
import hashlib, json
from datetime import datetime, timezone

def make_evidence_id(project_id, field_name, source, observed_at, raw_value):
    blob = json.dumps([project_id, field_name, source, observed_at, raw_value], ensure_ascii=False, sort_keys=True)
    return "EVD-" + hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]

def make_evidence(project_id, field_name, raw_value, source, source_tier,
                  observed_at, source_url=None, verification_status="UNVERIFIED",
                  pit_status="CURRENT_ONLY", confidence=0.5, **kwargs):
    return {
        "evidence_id": make_evidence_id(project_id, field_name, source, observed_at, raw_value),
        "project_id": project_id,
        "entity_id": kwargs.get("entity_id"),
        "field_name": field_name,
        "raw_value": raw_value,
        "unit": kwargs.get("unit"),
        "source": source,
        "source_url": source_url,
        "source_tier": source_tier,
        "observed_at": observed_at,
        "retrieved_at": datetime.now(timezone.utc).isoformat(),
        "as_of_date": kwargs.get("as_of_date"),
        "pit_status": pit_status,
        "verification_status": verification_status,
        "transformation": kwargs.get("transformation"),
        "parent_evidence_ids": kwargs.get("parent_evidence_ids", []),
        "confidence": confidence,
        "notes": kwargs.get("notes"),
    }
