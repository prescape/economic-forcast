
import json
from pathlib import Path

def validate_record(record, schema_path):
    try:
        import jsonschema
    except ImportError:
        return True, "jsonschema not installed; skipped"
    schema = json.loads(Path(schema_path).read_text(encoding="utf-8"))
    jsonschema.validate(record, schema)
    return True, "ok"
