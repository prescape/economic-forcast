# 有其屋 Data Pipeline V1.0

定位：为「有其屋 V6.6-FROZEN」持续提供可追溯、PIT-safe 的房地产数据。

## 核心原则
1. Skill/Data Separation：算法与数据分离。
2. Append-only：raw 与 snapshots 永不覆盖历史记录。
3. PIT-safe：每条数据至少记录 observed_at / retrieved_at / source。
4. Evidence-first：任何进入 BUY/HOLD/SELL 的关键字段必须能回溯 evidence_id。
5. No fabrication：抓不到就标记 MISSING / UNVERIFIED，不补造。
6. Schema-first：所有标准化数据通过 JSON Schema 校验。

## 建议部署位置
OpenClaw:
`~/.openclaw/workspace/data/youqiwu/`

Skill:
`~/.openclaw/workspace/skills/youqiwu/`

## 运行方式
```bash
python3 scripts/run_pipeline.py --project chubaoli --job daily
python3 scripts/run_pipeline.py --project chengningfu --job daily
python3 scripts/run_pipeline.py --project huangpuyayuan --job weekly
```

## 默认频率
- Daily: 预售证、网签、项目库存、加推、备案/一房一价
- Weekly: 二手挂牌、租金、竞品、二手成交
- Monthly: 城市/板块成交、土地、库存、宏观
- Event-driven: 政策、补贴、降息、新取证
- Transaction-time: Verification Gate 实时核验

## 目录
- data/raw: 原始抓取结果
- data/pit: 清洗后的 PIT 历史表
- data/evidence: Evidence Registry / Graph
- data/features: V6.6 五大模块派生特征
- data/snapshots: 每次运行冻结快照
- data/benchmarks: Benchmark 项目配置与样本

## 注意
本包提供抓取框架与接口，不绕过登录、验证码、反爬、付费墙或网站访问限制。具体站点适配器需按合法可用的数据接口实现。


## V1.1 武汉官方源接入
已新增 `WuhanOfficialHousingAdapter`，面向武汉市住房和城市更新局公开的商品房项目查询与预售许可证查询。

- 项目：承宁府、楚宝里
- 原始响应：`data/raw/official/wuhan/YYYY-MM-DD/...`
- 标准化 PIT：`permits / newhouse_sales / inventory`
- Evidence：所有明确解析出的官方字段写入 `data/evidence/evidence_registry.jsonl`
- 页面结构不明确时只保存 raw，不猜字段
- 遇到登录/验证码/反爬时停止并记录，不绕过

首次连接：
```bash
python3 scripts/test_wuhan_official_connection.py
```
每日抓取：
```bash
python3 scripts/jobs/wuhan_official_daily.py
```


## V1.2 深圳黄埔雅苑 Secondary Connector
保留 V1.1 武汉承宁府/楚宝里官方日频抓取，并新增黄埔雅苑一至四期。

### 官方 S 级
- 深圳市政府数据开放平台：二手房成交信息（按日统计）
- 深圳市住房和建设局：小区租赁参考价格
开放平台 API 可能需要注册/授权，因此支持 API 环境变量与官方下载文件导入两种方式。

### 平台 B 级
- 乐有家黄埔雅苑一期/二期/三期/四期公开二手挂牌
- 乐有家公开租赁挂牌
- 挂牌价不等于成交价；挂牌租金不等于签约租金

### PIT
- `data/pit/secondary_listings/huangpuyayuan.jsonl`
- `data/pit/rents/huangpuyayuan_platform.jsonl`
- `data/pit/rents/huangpuyayuan_official.jsonl`
- `data/pit/market_context/shenzhen.jsonl`

所有原始页面先进入 `data/raw/`，历史记录 append-only。
