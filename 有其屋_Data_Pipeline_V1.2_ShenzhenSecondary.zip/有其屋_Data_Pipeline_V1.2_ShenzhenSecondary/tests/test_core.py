
from scripts.core.normalize import inventory_bucket
from scripts.jobs.verification_gate import verify, enforce_on_action

def test_inventory_bucket():
    assert inventory_bucket(10) == "FRESH_0_30D"
    assert inventory_bucket(60) == "NORMAL_31_90D"
    assert inventory_bucket(120) == "AGED_91_180D"
    assert inventory_bucket(200) == "STALE_180D_PLUS"

def test_verification_gate():
    g = verify({"target_unit":True,"filing_price":True,"actual_discount":False,
                "subsidy_stackability":True,"floor":True,"orientation":True,"delivery_node":True})
    assert g["status"] == "VERIFY_BEFORE_BUY"
    assert enforce_on_action("STRONG_BUY", g["status"]) == "NEGOTIATE_BUY"
