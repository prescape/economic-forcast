#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
from datetime import datetime
import argparse, json, os, shutil, subprocess, sys, tempfile, yaml

SKILL_ROOT=Path(__file__).resolve().parents[1]
COLLECTOR=SKILL_ROOT/'data_pipeline/huangpu_v1_5'

def root(explicit=None):
    if explicit: return Path(explicit).expanduser().resolve()
    if os.getenv('YOUQI_WU_DATA_ROOT'): return Path(os.environ['YOUQI_WU_DATA_ROOT']).expanduser().resolve()
    return Path('~/.openclaw/workspace/data/youqiwu').expanduser().resolve()

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--data-root'); ap.add_argument('--skip-collect',action='store_true'); a=ap.parse_args()
    dr=root(a.data_root); dr.mkdir(parents=True,exist_ok=True)
    collector_root=dr/'collector_runs/huangpu_v1_5'
    collector_root.mkdir(parents=True,exist_ok=True)
    if not a.skip_collect:
        cfg=yaml.safe_load((COLLECTOR/'config.yaml').read_text(encoding='utf-8'))
        cfg['data_root']=str(collector_root)
        runtime_cfg=dr/'runtime_huangpu_v15_config.yaml'
        runtime_cfg.write_text(yaml.safe_dump(cfg,allow_unicode=True,sort_keys=False),encoding='utf-8')
        env=os.environ.copy(); env['PYTHONPATH']=str(COLLECTOR/'src')+(os.pathsep+env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
        p=subprocess.run([sys.executable,'-m','youqiwu_huangpu_skill.cli','--config',str(runtime_cfg)],cwd=COLLECTOR,env=env,text=True,capture_output=True)
        print(p.stdout,end='')
        if p.returncode!=0:
            print(p.stderr,file=sys.stderr); raise SystemExit(p.returncode)
    day=datetime.now().strftime('%Y-%m-%d')
    source=collector_root/'transactions/shenzhen/huangpuyayuan'/day
    bridge=subprocess.run([sys.executable,str(SKILL_ROOT/'scripts/sync_huangpu_v15_to_v66.py'),'--source-dir',str(source),'--data-root',str(dr)],text=True,capture_output=True)
    print(bridge.stdout,end='')
    if bridge.returncode!=0:
        print(bridge.stderr,file=sys.stderr); raise SystemExit(bridge.returncode)
    check=subprocess.run([sys.executable,str(SKILL_ROOT/'scripts/data_connector_v66.py'),'--project','huangpuyayuan','--data-root',str(dr)],text=True,capture_output=True)
    print(check.stdout,end='')
    if check.returncode!=0: raise SystemExit(check.returncode)

if __name__=='__main__': main()
