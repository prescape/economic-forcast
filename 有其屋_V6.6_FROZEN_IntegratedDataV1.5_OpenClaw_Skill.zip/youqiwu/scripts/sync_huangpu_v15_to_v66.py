#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, os

SKILL_ROOT=Path(__file__).resolve().parents[1]
CFG=json.loads((SKILL_ROOT/'config/integrated_data_v15.json').read_text(encoding='utf-8'))

def data_root(explicit=None):
    if explicit: return Path(explicit).expanduser().resolve()
    if os.getenv('YOUQI_WU_DATA_ROOT'): return Path(os.environ['YOUQI_WU_DATA_ROOT']).expanduser().resolve()
    return Path('~/.openclaw/workspace/data/youqiwu').expanduser().resolve()

def append_jsonl(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a',encoding='utf-8') as f: f.write(json.dumps(obj,ensure_ascii=False)+'\n')

def read_jsonl(path):
    if not path.exists(): return []
    out=[]
    for line in path.read_text(encoding='utf-8',errors='ignore').splitlines():
        try: out.append(json.loads(line))
        except Exception: pass
    return out

def fingerprint(r):
    blob=json.dumps([
      r.get('phase'),r.get('transaction_date'),r.get('area_sqm'),
      r.get('total_price_wan'),r.get('unit_price'),r.get('source')
    ],ensure_ascii=False,separators=(',',':'))
    return hashlib.sha256(blob.encode()).hexdigest()[:24]

def sync(source_dir:Path, root:Path):
    txfile=source_dir/'transactions.json'
    evfile=source_dir/'evidence.json'
    if not txfile.exists(): raise FileNotFoundError(txfile)
    rows=json.loads(txfile.read_text(encoding='utf-8'))
    target=root/'data/pit/secondary_transactions/huangpuyayuan.jsonl'
    existing=read_jsonl(target)
    keys=set()
    for r in existing:
        keys.add(r.get('evidence_id') or r.get('transaction_id') or fingerprint(r))
    accepted=[]; skipped=0
    for r in rows:
        if r.get('price_type') not in CFG['accepted_price_types'] or not r.get('pit_valid'):
            skipped+=1; continue
        key=r.get('evidence_id') or fingerprint(r)
        if key in keys: skipped+=1; continue
        total=(float(r['total_price_wan'])*10000 if r.get('total_price_wan') is not None else None)
        item={
          'project_id':'huangpuyayuan',
          'transaction_id':key,
          'phase':r.get('phase'),
          'transaction_date':r.get('transaction_date'),
          'area_sqm':r.get('area_sqm'),
          'total_price':total,
          'unit_price':r.get('unit_price'),
          'floor':r.get('floor'),'orientation':r.get('orientation'),
          'source':r.get('source'),'source_url':r.get('source_url'),
          'price_type':r.get('price_type'),'pit_valid':True,
          'publication_date':r.get('publication_date'),'retrieved_at':r.get('collected_at'),
          'evidence_id':r.get('evidence_id') or key,
          'collector_version':'1.5'
        }
        append_jsonl(target,item); accepted.append(item); keys.add(key)
    # evidence registry bridge
    evtarget=root/'data/evidence/evidence_registry.jsonl'
    existing_ev={x.get('evidence_id') for x in read_jsonl(evtarget) if isinstance(x,dict)}
    ev_added=0
    if evfile.exists():
        ev=json.loads(evfile.read_text(encoding='utf-8'))
        for e in ev.get('sources',[]):
            eid=e.get('evidence_id')
            if not eid or eid in existing_ev: continue
            rec={
              'evidence_id':eid,'project_id':'huangpuyayuan','entity_id':None,
              'field_name':'secondary_transaction','raw_value':None,'unit':None,
              'source':e.get('source','unknown'),'source_url':e.get('url'),
              'source_tier':'S' if e.get('price_type')=='OFFICIAL_SIGNED' else 'B',
              'observed_at':datetime.now(timezone.utc).date().isoformat(),
              'retrieved_at':datetime.now(timezone.utc).isoformat(),
              'as_of_date':None,'pit_status':'PIT_VERIFIED' if e.get('pit_valid') else 'UNKNOWN',
              'verification_status':'VERIFIED' if e.get('price_type')=='OFFICIAL_SIGNED' else 'CORROBORATED',
              'transformation':'V1.5 transaction record normalized into V6.6 secondary_transactions schema',
              'parent_evidence_ids':[],'confidence':0.95 if e.get('price_type')=='OFFICIAL_SIGNED' else 0.75,
              'notes':'Imported by V6.6/V1.5 integration bridge; raw snapshot preserved by collector.'
            }
            append_jsonl(evtarget,rec); existing_ev.add(eid); ev_added+=1
    return {'source_dir':str(source_dir),'accepted':len(accepted),'skipped_or_duplicate':skipped,'evidence_added':ev_added,'target':str(target)}

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--source-dir',required=True); ap.add_argument('--data-root')
    a=ap.parse_args(); print(json.dumps(sync(Path(a.source_dir),data_root(a.data_root)),ensure_ascii=False,indent=2))
