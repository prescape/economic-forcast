import hashlib, json, time, re
from pathlib import Path
from datetime import datetime
import requests
from requests.adapters import HTTPAdapter

PHASES=("一期","二期","三期","四期")

def now_iso(): return datetime.now().astimezone().isoformat()

def evidence_id(source,url,raw):
    return hashlib.sha256((source+'|'+(url or '')+'|'+(raw or '')).encode('utf-8','ignore')).hexdigest()[:20]

def normalize_phase(text):
    for p in PHASES:
        if p in (text or ''): return p
    m=re.search(r'黄埔雅苑\s*([一二三四1234])期?',text or '')
    if m:
        x=m.group(1); return {'1':'一期','2':'二期','3':'三期','4':'四期','一':'一期','二':'二期','三':'三期','四':'四期'}.get(x)
    return None

def get_session(cfg):
    s=requests.Session(); s.headers.update({
        'User-Agent':cfg.get('user_agent','Mozilla/5.0'),
        'Accept':'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
        'Accept-Language':'zh-CN,zh;q=0.9,en;q=0.5',
        'Cache-Control':'no-cache',
    })
    adapter=HTTPAdapter(pool_connections=4,pool_maxsize=4,max_retries=0)
    s.mount('http://',adapter); s.mount('https://',adapter)
    return s

def fetch(session,url,timeout=5,retries=0,method='GET',data=None,json_body=None,headers=None):
    last=None
    for i in range(int(retries)+1):
        try:
            t=time.time(); r=session.request(method,url,timeout=float(timeout),data=data,json=json_body,headers=headers,allow_redirects=True)
            elapsed=round(time.time()-t,3)
            r.raise_for_status()
            ctype=r.headers.get('content-type','')
            enc=r.encoding or r.apparent_encoding or 'utf-8'
            try: text=r.content.decode(enc,errors='replace')
            except Exception: text=r.text
            return text, {'status':r.status_code,'elapsed_s':elapsed,'content_type':ctype,'final_url':r.url,'bytes':len(r.content)}
        except Exception as e:
            last=e
            if i<retries: time.sleep(min(0.5*(i+1),1.5))
    raise last

def save_snapshot(runtime,source,content,url,meta=None,suffix='html'):
    root=runtime.get('raw_dir') if runtime else None
    if not root: return None
    root=Path(root)/source; root.mkdir(parents=True,exist_ok=True)
    stamp=datetime.now().strftime('%H%M%S_%f')
    sid=hashlib.sha1((url or '').encode()).hexdigest()[:8]
    p=root/f'{stamp}_{sid}.{suffix}'
    p.write_text(content or '',encoding='utf-8',errors='replace')
    mp=p.with_suffix(p.suffix+'.meta.json')
    mp.write_text(json.dumps({'url':url,'collected_at':now_iso(),'http':meta or {}},ensure_ascii=False,indent=2),encoding='utf-8')
    return str(p)
