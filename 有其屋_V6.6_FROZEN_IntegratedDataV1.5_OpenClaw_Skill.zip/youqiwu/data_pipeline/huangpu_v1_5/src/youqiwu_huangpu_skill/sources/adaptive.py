import json
from urllib.parse import quote
from ..utils import fetch,save_snapshot
from ..diagnostics import classify_payload,discover_endpoints,inspect_response
from ..field_mapper import learn_mapping

class AdaptiveFetcher:
    def __init__(self, adapter): self.a=adapter

    def candidate_urls(self, community):
        cfg=self.a.cfg; q=quote(community); urls=[]
        for key in ('api_candidates','search_url_templates'):
            for t in cfg.get(key,[]) or []:
                try: urls.append(t.format(query=q,community=community))
                except Exception: urls.append(t)
        for key in ('search_url','base_url'):
            if cfg.get(key): urls.append(cfg[key])
        return list(dict.fromkeys(u for u in urls if u))

    def fetch_candidates(self, session, community, parser_html, parser_json):
        attempted=[]; records=[]; queue=self.candidate_urls(community); seen=set()
        max_discovered=int(self.a.cfg.get('max_discovered_endpoints',8))
        while queue:
            url=queue.pop(0)
            if url in seen: continue
            seen.add(url)
            try:
                text,meta=fetch(session,url,self.a.http_cfg.get('timeout',5),self.a.http_cfg.get('retries',0))
                diag=inspect_response(text,meta,community); diag['url']=url
                kind=classify_payload(text,meta.get('content_type',''))
                snap=save_snapshot(self.a.runtime,self.a.name,text,url,meta,'json' if kind=='json' else ('html' if kind=='html' else 'txt'))
                rs=[]
                if kind=='json':
                    try:
                        payload=json.loads(text)
                        diag['field_mapping']=learn_mapping(payload,self.a.name)
                        rs=parser_json(payload,url,community)
                    except Exception as e: diag['json_parse_error']=str(e)
                if not rs: rs=parser_html(text,url,community)
                for r in rs:
                    r.raw_snapshot=snap; r.extra=dict(r.extra or {}); r.extra['http']=meta; r.extra['response_diagnostic']=diag
                records.extend(rs); diag['parsed_records']=len(rs); attempted.append(diag)
                if rs: break
                if kind=='html' and self.a.cfg.get('auto_discover_endpoints',True):
                    found=discover_endpoints(text,meta.get('final_url') or url)[:max_discovered]
                    diag['discovered_endpoints']=found
                    for u in found:
                        if u not in seen and u not in queue: queue.append(u)
            except Exception as e:
                attempted.append({'url':url,'error':str(e),'parsed_records':0})
        return records,attempted
