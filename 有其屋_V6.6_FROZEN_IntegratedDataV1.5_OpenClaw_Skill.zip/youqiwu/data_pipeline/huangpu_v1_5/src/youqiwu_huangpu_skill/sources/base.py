from abc import ABC, abstractmethod
class SourceAdapter(ABC):
    name="base"
    def __init__(self, cfg, http_cfg, runtime=None):
        self.cfg=cfg; self.http_cfg=http_cfg; self.runtime=runtime or {}
    @abstractmethod
    def collect(self, community, phases): ...
