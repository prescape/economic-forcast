from .base import SourceAdapter
from ..models import Transaction
from ..utils import fetch,get_session,evidence_id,now_iso,save_snapshot
class GenericDiscoveryAdapter(SourceAdapter):
    def __init__(self,name,cfg,http_cfg,runtime=None): super().__init__(cfg,http_cfg,runtime); self.name=name
    def collect(self,community,phases):
        urls=[u for u in [self.cfg.get('search_url'),self.cfg.get('base_url')] if u]
        if not urls:return []
        errors=[]
        for url in urls:
            try:
                html,meta=fetch(get_session(self.http_cfg),url,self.http_cfg.get('timeout',5),self.http_cfg.get('retries',0)); snap=save_snapshot(self.runtime,self.name,html,url,meta)
                raw=f'landing fetched; bytes={len(html)}; search_target={community}'
                return [Transaction(source=self.name,price_type='DISCOVERY_ONLY',source_url=url,collected_at=now_iso(),confidence=.1,pit_valid=True,
                    evidence_id=evidence_id(self.name,url,raw),raw_text=raw,raw_snapshot=snap,extra={'http':meta,'note':'登录/JS站点仅留证，不猜成交价'})]
            except Exception as e: errors.append(f'{url}: {e}')
        raw='; '.join(errors)
        return [Transaction(source=self.name,price_type='SOURCE_ERROR',source_url=urls[0],collected_at=now_iso(),pit_valid=False,evidence_id=evidence_id(self.name,urls[0],raw),raw_text=raw)]
