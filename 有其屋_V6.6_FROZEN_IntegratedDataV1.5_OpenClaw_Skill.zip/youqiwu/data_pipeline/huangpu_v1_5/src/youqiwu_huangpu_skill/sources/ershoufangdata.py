import re, json
from bs4 import BeautifulSoup
from .base import SourceAdapter
from ..models import Transaction
from ..utils import get_session,evidence_id,now_iso,normalize_phase

DATE_RE=r'(20\d{2})[-/.年](\d{1,2})[-/.月](\d{1,2})日?'
def _date(m): return f"{int(m.group(1)):04d}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"

def _parse_chunk(chunk,url,community):
    dm=re.search(DATE_RE,chunk)
    if not dm or community not in chunk: return None
    area=re.search(r'(?:建面|建筑面积|面积)\s*[:：]?\s*([0-9]+(?:\.[0-9]+)?)\s*(?:㎡|平)',chunk)
    total=re.search(r'(?:成交价|成交总价|总价)\s*[:：]?\s*([0-9]+(?:\.[0-9]+)?)\s*万',chunk)
    unit=re.search(r'(?:成交单价|单价)\s*[:：]?\s*([0-9]{4,6})\s*元/?(?:㎡|平)',chunk)
    if not(total or unit): return None
    if re.search(r'\d+\*+\s*万|\*+\s*万',chunk): return None
    layout=(re.search(r'(\d室\d厅(?:\d卫)?)',chunk) or [None,None])[1]
    raw=chunk[:700]
    return Transaction(community=community,phase=normalize_phase(chunk),transaction_date=_date(dm),
        area_sqm=float(area.group(1)) if area else None,layout=layout,
        total_price_wan=float(total.group(1)) if total else None,unit_price=float(unit.group(1)) if unit else None,
        source='ershoufangdata',price_type='TRANSACTION_PRICE',source_url=url,collected_at=now_iso(),
        confidence=.90,pit_valid=True,evidence_id=evidence_id('ershoufangdata',url,raw),raw_text=raw,
        extra={'parser':'ershoufangdata_v1.3'})

def parse_transactions(html,url,community='黄埔雅苑'):
    soup=BeautifulSoup(html,'html.parser'); out=[]; seen=set()
    candidates=[]
    for node in soup.select('tr,li,article,.item,.record,.deal,.transaction,.list-item'):
        txt=node.get_text(' ',strip=True)
        if community in txt and re.search(DATE_RE,txt): candidates.append(txt)
    if not candidates:
        text=soup.get_text(' ',strip=True)
        for dm in re.finditer(DATE_RE,text): candidates.append(text[max(0,dm.start()-240):min(len(text),dm.end()+400)])
    for c in candidates:
        r=_parse_chunk(c,url,community)
        if r:
            k=(r.phase,r.transaction_date,r.area_sqm,r.total_price_wan,r.unit_price)
            if k not in seen: seen.add(k); out.append(r)
    return out

def parse_json_payload(payload,url,community='黄埔雅苑'):
    out=[]
    def scalar_text(d):
        parts=[]
        for k,v in d.items():
            if isinstance(v,(str,int,float)):
                parts.append(f'{k} {v}')
        return ' '.join(parts)
    def walk(x):
        if isinstance(x,dict):
            text=scalar_text(x)
            if community in text:
                r=_parse_chunk(text,url,community)
                if r: out.append(r)
            for v in x.values(): walk(v)
        elif isinstance(x,list):
            for v in x: walk(v)
    walk(payload); return out

from .adaptive import AdaptiveFetcher

class ErshoufangDataAdapter(SourceAdapter):
    name='ershoufangdata'
    def collect(self,community,phases):
        sess=get_session(self.http_cfg)
        rs,attempts=AdaptiveFetcher(self).fetch_candidates(sess,community,parse_transactions,parse_json_payload)
        if rs: return rs
        errors=[a for a in attempts if a.get('error')]
        raw='; '.join(f"{a.get('url')}: {a.get('error')}" for a in errors) if errors else 'fetched successfully but no explicit transaction records parsed'
        url=(attempts[0].get('url') if attempts else self.cfg.get('base_url'))
        return [Transaction(source=self.name,price_type='SOURCE_ERROR' if errors and len(errors)==len(attempts) else 'DISCOVERY_ONLY',source_url=url,
            collected_at=now_iso(),confidence=0 if errors and len(errors)==len(attempts) else .15,pit_valid=not (errors and len(errors)==len(attempts)),evidence_id=evidence_id(self.name,url or '',raw),raw_text=raw,
            extra={'parser':'ershoufangdata_v1.3','attempts':attempts,'note':'仅接受明确成交价；隐藏价格不推测'})]
