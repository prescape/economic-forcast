import re
from bs4 import BeautifulSoup
from .base import SourceAdapter
from ..models import Transaction
from ..utils import fetch,get_session,evidence_id,now_iso,save_snapshot

class LeyoujiaAdapter(SourceAdapter):
    name='leyoujia'
    def collect(self,community,phases):
        out=[]; sess=get_session(self.http_cfg)
        for phase in phases:
            url=(self.cfg.get('phase_urls') or {}).get(phase)
            if not url: continue
            try:
                html,meta=fetch(sess,url,self.http_cfg.get('timeout',5),self.http_cfg.get('retries',0)); snap=save_snapshot(self.runtime,self.name,html,url,meta)
                text=BeautifulSoup(html,'html.parser').get_text(' ',strip=True)
                avg=re.search(r'(?:在售均价|参考均价|均价)\s*[:：]?\s*([0-9]{4,6})\s*元/㎡',text)
                raw=f'{community}{phase} public page; '+(f'公开参考均价{avg.group(1)}元/㎡' if avg else 'no public average parsed')
                out.append(Transaction(phase=phase,source=self.name,price_type='REFERENCE_PRICE',unit_price=float(avg.group(1)) if avg else None,
                    source_url=url,collected_at=now_iso(),confidence=.45,pit_valid=True,evidence_id=evidence_id(self.name,url,raw),raw_text=raw,raw_snapshot=snap,
                    extra={'http':meta,'parser':'leyoujia_v1.2','note':'挂牌/参考价格不得当作成交价'}))
            except Exception as e:
                out.append(Transaction(phase=phase,source=self.name,price_type='SOURCE_ERROR',source_url=url,collected_at=now_iso(),confidence=0,pit_valid=False,
                    evidence_id=evidence_id(self.name,url,str(e)),raw_text=str(e),extra={'parser':'leyoujia_v1.2'}))
        return out
