import re,json
from bs4 import BeautifulSoup
from .base import SourceAdapter
from ..models import Transaction
from ..utils import get_session,evidence_id,now_iso,normalize_phase
DATE_RE=r'(20\d{2})[-/.年](\d{1,2})[-/.月](\d{1,2})日?'

def _extract(text,url,community):
    out=[]
    for dm in re.finditer(DATE_RE,text):
        c=text[max(0,dm.start()-260):min(len(text),dm.end()+450)]
        if community not in c: continue
        price=re.search(r'(?:网签价|成交价|合同价|成交总价)\s*[:：]?\s*([0-9]+(?:\.[0-9]+)?)\s*万',c)
        unit=re.search(r'(?:网签单价|成交单价)\s*[:：]?\s*([0-9]{4,6})\s*元/?(?:㎡|平)',c)
        area=re.search(r'(?:建筑面积|面积)\s*[:：]?\s*([0-9]+(?:\.[0-9]+)?)\s*(?:㎡|平)',c)
        if not(price or unit): continue
        d=f'{int(dm.group(1)):04d}-{int(dm.group(2)):02d}-{int(dm.group(3)):02d}'; raw=c[:750]
        out.append(Transaction(community=community,phase=normalize_phase(c),transaction_date=d,area_sqm=float(area.group(1)) if area else None,
            total_price_wan=float(price.group(1)) if price else None,unit_price=float(unit.group(1)) if unit else None,
            source='official_sz',price_type='OFFICIAL_SIGNED',source_url=url,collected_at=now_iso(),confidence=.98,pit_valid=True,
            evidence_id=evidence_id('official_sz',url,raw),raw_text=raw,extra={'parser':'official_sz_v1.3'}))
    return out

def parse_official(html,url,community='黄埔雅苑'):
    return _extract(BeautifulSoup(html,'html.parser').get_text(' ',strip=True),url,community)

def parse_official_json(payload,url,community='黄埔雅苑'):
    return _extract(json.dumps(payload,ensure_ascii=False),url,community)

from .adaptive import AdaptiveFetcher

class OfficialSZAdapter(SourceAdapter):
    name='official_sz'
    def collect(self,community,phases):
        sess=get_session(self.http_cfg)
        rs,attempts=AdaptiveFetcher(self).fetch_candidates(sess,community,parse_official,parse_official_json)
        if rs:return rs
        errors=[a for a in attempts if a.get('error')]
        raw='; '.join(f"{a.get('url')}: {a.get('error')}" for a in errors) if errors else 'official endpoint fetched; no explicit signed transaction rows parsed'
        url=(attempts[0].get('url') if attempts else self.cfg.get('base_url'))
        return [Transaction(source=self.name,price_type='SOURCE_ERROR' if errors and len(errors)==len(attempts) else 'DISCOVERY_ONLY',source_url=url,collected_at=now_iso(),
            confidence=0 if errors and len(errors)==len(attempts) else .2,pit_valid=not (errors and len(errors)==len(attempts)),evidence_id=evidence_id(self.name,url or '',raw),raw_text=raw,
            extra={'parser':'official_sz_v1.3','attempts':attempts,'note':'官方参考价不作为单套网签价'})]
