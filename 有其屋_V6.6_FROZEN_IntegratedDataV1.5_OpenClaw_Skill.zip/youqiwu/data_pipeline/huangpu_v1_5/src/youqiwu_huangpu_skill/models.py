from dataclasses import dataclass, asdict, field
from typing import Optional

@dataclass
class Transaction:
    community: str = "黄埔雅苑"
    phase: Optional[str] = None
    transaction_date: Optional[str] = None
    area_sqm: Optional[float] = None
    layout: Optional[str] = None
    floor: Optional[str] = None
    orientation: Optional[str] = None
    total_price_wan: Optional[float] = None
    unit_price: Optional[float] = None
    source: str = "unknown"
    price_type: str = "UNKNOWN"
    source_url: Optional[str] = None
    publication_date: Optional[str] = None
    collected_at: Optional[str] = None
    confidence: float = 0.0
    pit_valid: bool = False
    evidence_id: Optional[str] = None
    raw_text: Optional[str] = None
    raw_snapshot: Optional[str] = None
    extra: dict = field(default_factory=dict)

    def to_dict(self):
        return asdict(self)
