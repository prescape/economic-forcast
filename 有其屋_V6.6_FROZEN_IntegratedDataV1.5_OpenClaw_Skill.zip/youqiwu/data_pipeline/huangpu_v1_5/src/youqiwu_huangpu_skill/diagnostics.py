import json,re
from collections import Counter
from urllib.parse import urljoin
from bs4 import BeautifulSoup

TX_KEYS = ('成交价','成交总价','网签价','合同价','成交单价','网签单价','transaction','deal','price')
API_HINTS = ('api','ajax','search','query','list','deal','trade','transaction','house','fangyuan')


def classify_payload(text, content_type=''):
    t=(text or '').lstrip()
    if 'json' in (content_type or '').lower() or t.startswith('{') or t.startswith('['): return 'json'
    if '<html' in t[:500].lower() or '<!doctype' in t[:500].lower(): return 'html'
    return 'text'


def discover_endpoints(html, base_url):
    """Extract same-page URL/API candidates from links/scripts without executing JS."""
    soup=BeautifulSoup(html or '', 'html.parser'); out=[]
    for tag,attr in [('a','href'),('form','action'),('script','src')]:
        for node in soup.find_all(tag):
            v=node.get(attr)
            if not v: continue
            u=urljoin(base_url,v)
            low=u.lower()
            if any(h in low for h in API_HINTS): out.append(u)
    # URLs embedded in JavaScript/source strings
    for m in re.finditer(r'''["']([^"']{3,240}(?:api|ajax|search|query|deal|trade|transaction|house|fangyuan)[^"']*)["']''', html or '', re.I):
        v=m.group(1)
        if v.startswith(('http://','https://','/','./','../')): out.append(urljoin(base_url,v))
    return list(dict.fromkeys(out))[:30]


def inspect_response(text, meta=None, community='黄埔雅苑'):
    meta=meta or {}; kind=classify_payload(text,meta.get('content_type','')); low=(text or '').lower()
    js_shell=kind=='html' and any(x in low for x in ('enable javascript','doesn\'t work properly without javascript','__webpack','webpackjsonp','vite'))
    return {
        'payload_kind':kind,
        'bytes':len((text or '').encode('utf-8','ignore')),
        'contains_community':community in (text or ''),
        'transaction_keyword_hits':sum((text or '').count(k) for k in TX_KEYS),
        'js_shell':js_shell,
        'status':meta.get('status'),
        'content_type':meta.get('content_type'),
        'final_url':meta.get('final_url'),
    }


def build_diagnostic_report(records, attempts):
    return {
        'attempt_count':len(attempts),
        'attempts':attempts,
        'price_types':dict(Counter(r.price_type for r in records)),
        'sources':dict(Counter(r.source for r in records)),
        'actionable_hints':[
            'SOURCE_ERROR: 检查 DNS/代理/证书/站点可达性。',
            'DISCOVERY_ONLY + js_shell=true: 在联网服务器浏览器开发者工具 Network 中记录 XHR/fetch API，并写入 config.yaml 的 api_candidates。',
            '页面包含黄埔雅苑但 transaction_keyword_hits=0: 该页面多半只有房源/参考价，不应当作成交价。',
            '任何隐藏价（如 8**万）继续禁止估算。'
        ]
    }
