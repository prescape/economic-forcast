import csv,json,yaml
from pathlib import Path
from datetime import datetime
from collections import Counter
from .sources.leyoujia import LeyoujiaAdapter
from .sources.generic import GenericDiscoveryAdapter
from .sources.ershoufangdata import ErshoufangDataAdapter
from .sources.official_sz import OfficialSZAdapter
from .dedupe import dedupe
from .diagnostics import build_diagnostic_report
from .fusion import fuse

def run(config_path='config.yaml'):
    cfg=yaml.safe_load(Path(config_path).read_text(encoding='utf-8')); http=cfg.get('http',{})
    day=datetime.now().strftime('%Y-%m-%d'); root=Path(cfg.get('data_root','data/youqiwu'))/'transactions'/'shenzhen'/'huangpuyayuan'/day
    root.mkdir(parents=True,exist_ok=True); runtime={'raw_dir':str(root/'raw')}
    sc=cfg.get('sources',{}); adapters=[]
    if sc.get('ershoufangdata',{}).get('enabled',False): adapters.append(ErshoufangDataAdapter(sc['ershoufangdata'],http,runtime))
    if sc.get('official_sz',{}).get('enabled',False): adapters.append(OfficialSZAdapter(sc['official_sz'],http,runtime))
    if sc.get('beike',{}).get('enabled',False): adapters.append(GenericDiscoveryAdapter('beike',sc['beike'],http,runtime))
    if sc.get('leyoujia',{}).get('enabled',False): adapters.append(LeyoujiaAdapter(sc['leyoujia'],http,runtime))
    records=[]
    for a in adapters: records.extend(a.collect(cfg['community'],cfg['phases']))
    records=dedupe(records); rows=[r.to_dict() for r in records]
    (root/'transactions.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    flat=[]
    for x in rows:
        y=x.copy(); y['extra']=json.dumps(y.get('extra',{}),ensure_ascii=False); flat.append(y)
    if flat:
        with (root/'transactions.csv').open('w',newline='',encoding='utf-8-sig') as f:
            w=csv.DictWriter(f,fieldnames=flat[0].keys()); w.writeheader(); w.writerows(flat)
    evidence={'community':cfg['community'],'version':'1.5','generated_at':datetime.now().astimezone().isoformat(),
        'sources':[{'source':r.source,'url':r.source_url,'evidence_id':r.evidence_id,'price_type':r.price_type,'pit_valid':r.pit_valid,'raw_snapshot':r.raw_snapshot,'raw_text':r.raw_text} for r in records]}
    (root/'evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
    by_source=Counter(r.source for r in records); by_type=Counter(r.price_type for r in records)
    manifest={'version':'1.5','generated_at':datetime.now().astimezone().isoformat(),'record_count':len(records),'by_source':dict(by_source),'by_price_type':dict(by_type),
        'transaction_count':sum(1 for r in records if r.price_type in ('TRANSACTION_PRICE','OFFICIAL_SIGNED')),
        'pit_valid_count':sum(1 for r in records if r.pit_valid),'raw_archive':str(root/'raw')}
    (root/'run_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    attempts=[]
    for r in records:
        for a in (r.extra or {}).get('attempts',[]): attempts.append({'source':r.source,**a})
        d=(r.extra or {}).get('response_diagnostic')
        if d: attempts.append({'source':r.source,**d})
    diagnostics=build_diagnostic_report(records,attempts)
    (root/'diagnostics.json').write_text(json.dumps(diagnostics,ensure_ascii=False,indent=2),encoding='utf-8')
    mapping_reports=[]
    for a in attempts:
        fm=a.get('field_mapping')
        if fm: mapping_reports.append(fm)
    field_mapping={'version':'1.5','generated_at':datetime.now().astimezone().isoformat(),'reports':mapping_reports}
    (root/'field_mapping_report.json').write_text(json.dumps(field_mapping,ensure_ascii=False,indent=2),encoding='utf-8')
    fused=fuse(records, cfg.get('fusion',{}).get('match_threshold',0.72))
    (root/'fused_transactions.json').write_text(json.dumps(fused,ensure_ascii=False,indent=2),encoding='utf-8')
    if fused:
        csv_rows=[]
        for x in fused:
            y=x.copy()
            for k in ('sources','evidence_ids','conflicts'): y[k]=json.dumps(y.get(k,[]),ensure_ascii=False)
            csv_rows.append(y)
        with (root/'fused_transactions.csv').open('w',newline='',encoding='utf-8-sig') as f:
            w=csv.DictWriter(f,fieldnames=csv_rows[0].keys()); w.writeheader(); w.writerows(csv_rows)
    confidence_report={'version':'1.5','generated_at':datetime.now().astimezone().isoformat(),
        'fused_count':len(fused),
        'verified_count':sum(1 for x in fused if x['verification_status']=='VERIFIED'),
        'review_count':sum(1 for x in fused if x['verification_status']=='REVIEW'),
        'records':fused}
    (root/'confidence_report.json').write_text(json.dumps(confidence_report,ensure_ascii=False,indent=2),encoding='utf-8')
    return root,records
