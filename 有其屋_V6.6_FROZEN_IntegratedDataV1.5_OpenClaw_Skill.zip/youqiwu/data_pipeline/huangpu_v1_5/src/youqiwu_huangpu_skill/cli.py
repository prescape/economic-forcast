import argparse,json
from pathlib import Path
from .pipeline import run

def main():
    p=argparse.ArgumentParser(description='有其屋·黄埔雅苑成交采集 Skill V1.5')
    p.add_argument('--config',default='config.yaml'); args=p.parse_args(); root,rs=run(args.config)
    print(f'OK: {len(rs)} records -> {root}')
    for r in rs: print(r.source,r.phase,r.price_type,r.transaction_date,r.total_price_wan,r.unit_price)
    m=root/'run_manifest.json'
    if m.exists(): print(json.dumps(json.loads(m.read_text(encoding="utf-8")),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
