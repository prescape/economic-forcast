import re
from collections import defaultdict, Counter
from datetime import datetime

CANONICAL = {
    'community': ['community','communityname','xqname','estate','estatename','project','projectname','小区','小区名称','项目名称','楼盘'],
    'phase': ['phase','period','stage','分期','期数','苑区'],
    'transaction_date': ['transactiondate','dealdate','signdate','contractdate','deal_time','tradetime','date','成交日期','网签日期','签约日期','合同日期'],
    'area_sqm': ['area','areasqm','buildarea','buildingarea','housearea','acreage','建筑面积','面积','建面'],
    'layout': ['layout','room','roomtype','housetype','户型','房型'],
    'floor': ['floor','floorname','楼层'],
    'orientation': ['orientation','direction','朝向'],
    'total_price_wan': ['totalprice','dealprice','transactionprice','contractprice','price','成交总价','成交价','总价','合同价','网签价'],
    'unit_price': ['unitprice','pricepersqm','avgprice','单价','成交单价','均价'],
}

def _norm(s):
    return re.sub(r'[^a-z0-9\u4e00-\u9fff]+','',str(s).lower())

def _walk(obj, path='$'):
    if isinstance(obj, dict):
        for k,v in obj.items():
            p=f'{path}.{k}'
            if isinstance(v,(dict,list)):
                yield from _walk(v,p)
            else:
                yield p,k,v
    elif isinstance(obj, list):
        for i,v in enumerate(obj[:200]):
            yield from _walk(v,f'{path}[{i}]')

def _value_bonus(canonical, value):
    s=str(value).strip()
    if canonical=='transaction_date':
        return 0.25 if re.search(r'20\d{2}[-/.年]\d{1,2}',s) else 0
    if canonical in ('area_sqm','total_price_wan','unit_price'):
        try:
            x=float(re.sub(r'[^0-9.]','',s));
            if canonical=='area_sqm' and 10<=x<=1000: return 0.20
            if canonical=='total_price_wan' and 1<=x<=100000: return 0.15
            if canonical=='unit_price' and 1000<=x<=1000000: return 0.20
        except Exception: pass
    if canonical=='community' and '黄埔雅苑' in s: return 0.35
    if canonical=='phase' and re.search(r'[一二三四1234]期',s): return 0.30
    return 0

def score_key(canonical,key,value):
    nk=_norm(key); aliases=[_norm(x) for x in CANONICAL[canonical]]
    best=0.0; reason=[]
    if nk in aliases:
        best=0.72; reason.append('exact_alias')
    else:
        for a in aliases:
            if a and (a in nk or nk in a):
                best=max(best,0.52); reason.append('partial_alias')
    vb=_value_bonus(canonical,value)
    if vb: reason.append('value_pattern')
    return min(0.99,best+vb), reason

def learn_mapping(payload, source='unknown'):
    candidates=defaultdict(list); unknown=Counter(); total=0
    for path,key,value in _walk(payload):
        total+=1; matched=False
        for canonical in CANONICAL:
            score,reason=score_key(canonical,key,value)
            if score>=0.50:
                candidates[canonical].append({'path':path,'field':str(key),'sample':str(value)[:120],'score':round(score,3),'reason':reason})
                matched=True
        if not matched: unknown[str(key)]+=1
    mapping={}
    for canonical,items in candidates.items():
        items.sort(key=lambda x:(-x['score'],x['path']))
        mapping[canonical]=items[0]
    return {
        'source':source,'generated_at':datetime.now().astimezone().isoformat(),'leaf_fields_scanned':total,
        'mapping':mapping,
        'candidates':{k:sorted(v,key=lambda x:-x['score'])[:10] for k,v in candidates.items()},
        'unmapped_fields':[{'field':k,'count':v} for k,v in unknown.most_common(100)]
    }

def aggregate_reports(reports):
    return {'version':'1.4','generated_at':datetime.now().astimezone().isoformat(),'reports':reports}
