
from dataclasses import dataclass, asdict
from datetime import datetime
from math import exp
from typing import Optional

TRUST = {
    "official_sz": 1.00,
    "ershoufangdata": 0.92,
    "beike": 0.82,
    "leyoujia": 0.80,
    "fang": 0.65,
    "anjuke": 0.60,
}
VALID_TYPES = {"TRANSACTION_PRICE", "OFFICIAL_SIGNED"}

def _num(v):
    try: return float(v) if v is not None else None
    except (TypeError, ValueError): return None

def _date_days(a,b):
    if not a or not b: return None
    try:
        da=datetime.fromisoformat(str(a)[:10]).date()
        db=datetime.fromisoformat(str(b)[:10]).date()
        return abs((da-db).days)
    except ValueError: return None

def pair_score(a,b):
    """0..1 probability-like similarity for same physical transaction."""
    if a.community != b.community: return 0.0
    if a.phase and b.phase and a.phase != b.phase: return 0.0
    parts=[]; weights=[]
    dd=_date_days(a.transaction_date,b.transaction_date)
    if dd is not None:
        parts.append(max(0.0, 1-dd/7)); weights.append(0.30)
    aa,ab=_num(a.area_sqm),_num(b.area_sqm)
    if aa and ab:
        parts.append(max(0.0,1-abs(aa-ab)/max(2.0,0.03*max(aa,ab)))); weights.append(0.30)
    pa,pb=_num(a.total_price_wan),_num(b.total_price_wan)
    if pa and pb:
        parts.append(max(0.0,1-abs(pa-pb)/max(5.0,0.03*max(pa,pb)))); weights.append(0.25)
    ua,ub=_num(a.unit_price),_num(b.unit_price)
    if ua and ub:
        parts.append(max(0.0,1-abs(ua-ub)/max(1000.0,0.03*max(ua,ub)))); weights.append(0.15)
    if not weights: return 0.0
    return sum(p*w for p,w in zip(parts,weights))/sum(weights)

def _cluster(records, threshold=0.72):
    tx=[r for r in records if r.price_type in VALID_TYPES and r.pit_valid]
    clusters=[]
    for r in tx:
        best=None; bests=0
        for c in clusters:
            s=max(pair_score(r,x) for x in c)
            if s>bests: best,bests=c,s
        if best is not None and bests>=threshold: best.append(r)
        else: clusters.append([r])
    return clusters

def _weighted(values):
    vals=[(v,w) for v,w in values if v is not None]
    if not vals: return None
    return sum(v*w for v,w in vals)/sum(w for _,w in vals)

def _agreement(values, tolerance=0.03):
    vals=[float(v) for v in values if v is not None]
    if len(vals)<2: return 1.0
    m=sum(vals)/len(vals)
    if not m: return 1.0
    spread=(max(vals)-min(vals))/m
    return max(0.0,1-spread/tolerance)

def fuse(records, threshold=0.72):
    out=[]
    for i,c in enumerate(_cluster(records,threshold),1):
        sources=sorted(set(r.source for r in c))
        official=any(r.source=="official_sz" or r.price_type=="OFFICIAL_SIGNED" for r in c)
        weights=[TRUST.get(r.source,0.55) for r in c]
        total=_weighted([(_num(r.total_price_wan),w) for r,w in zip(c,weights)])
        unit=_weighted([(_num(r.unit_price),w) for r,w in zip(c,weights)])
        area=_weighted([(_num(r.area_sqm),w) for r,w in zip(c,weights)])
        dates=[r.transaction_date for r in c if r.transaction_date]
        # Confidence: source authority + cross-source corroboration + numeric agreement.
        authority=max(weights) if weights else 0
        corroboration=min(1.0, 0.55 + 0.18*(len(sources)-1))
        price_agree=_agreement([r.total_price_wan for r in c])
        unit_agree=_agreement([r.unit_price for r in c])
        agreement=(price_agree+unit_agree)/2
        confidence=min(0.995, 0.48*authority+0.27*corroboration+0.25*agreement+(0.06 if official else 0))
        conflicts=[]
        if price_agree<0.5: conflicts.append("total_price_conflict")
        if unit_agree<0.5: conflicts.append("unit_price_conflict")
        status="VERIFIED" if official and len(sources)>=2 and not conflicts else ("HIGH_CONFIDENCE" if confidence>=0.85 and not conflicts else ("REVIEW" if conflicts else "CORROBORATED"))
        canonical=max(c,key=lambda r:(1 if r.source=="official_sz" else 0, TRUST.get(r.source,0.55)))
        out.append({
            "fusion_id": f"HPYA-{i:05d}",
            "community": canonical.community,
            "phase": canonical.phase,
            "transaction_date": min(dates) if dates else None,
            "area_sqm": round(area,2) if area is not None else None,
            "total_price_wan": round(total,2) if total is not None else None,
            "unit_price": round(unit,2) if unit is not None else None,
            "price_type": "OFFICIAL_SIGNED" if official else "TRANSACTION_PRICE",
            "confidence_score": round(confidence,4),
            "verification_status": status,
            "source_count": len(sources),
            "sources": sources,
            "evidence_ids": [r.evidence_id for r in c if r.evidence_id],
            "conflicts": conflicts,
            "canonical_source": canonical.source,
        })
    return out
