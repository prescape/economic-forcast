from datetime import datetime

def _date(s):
    try: return datetime.fromisoformat(s).date() if s else None
    except: return None

def is_same(a,b):
    if a.community != b.community or a.phase != b.phase: return False
    da,db=_date(a.transaction_date),_date(b.transaction_date)
    if da and db and abs((da-db).days)>3: return False
    if a.area_sqm and b.area_sqm and abs(a.area_sqm-b.area_sqm)>1.0: return False
    if a.total_price_wan and b.total_price_wan and abs(a.total_price_wan-b.total_price_wan)>10: return False
    return bool((da and db) or (a.area_sqm and b.area_sqm))

def dedupe(records):
    groups=[]
    for r in records:
        if r.price_type in {"SOURCE_ERROR","DISCOVERY_ONLY","REFERENCE_PRICE"}: groups.append([r]); continue
        found=None
        for g in groups:
            if g and is_same(g[0],r): found=g; break
        (found if found is not None else groups.append([r]))
        if found is not None: found.append(r)
    out=[]
    for g in groups:
        if len(g)==1: out.append(g[0]); continue
        best=max(g,key=lambda x:x.confidence)
        best.extra=dict(best.extra or {}); best.extra["merged_sources"]=[x.source for x in g]; best.confidence=min(0.99,best.confidence+0.03*(len(g)-1))
        out.append(best)
    return out
