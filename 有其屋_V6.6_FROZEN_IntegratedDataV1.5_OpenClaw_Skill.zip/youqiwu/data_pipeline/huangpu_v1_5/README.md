# 有其屋·黄埔雅苑成交采集 Skill V1.3

V1.3 是服务器实网适配版。在 V1.2 的 PIT / Evidence / Raw Snapshot 基础上，新增自适应页面/API发现和抓取诊断。

## 运行
```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
youqiwu-huangpu --config config.yaml
```
如服务器不便安装包，也可：
```bash
PYTHONPATH=src python -m youqiwu_huangpu_skill.cli --config config.yaml
```

## 输出
`data/youqiwu/transactions/shenzhen/huangpuyayuan/YYYY-MM-DD/`
- `transactions.csv`
- `transactions.json`
- `evidence.json`
- `run_manifest.json`
- `diagnostics.json`
- `raw/<source>/...`

## 实网接口适配
若 `diagnostics.json` 显示 `js_shell=true`，表示站点主要依赖 JavaScript。请在你自己的联网服务器浏览器中正常打开站点，通过开发者工具 Network 查看公开 XHR/fetch 请求，将合法公开接口写入：
```yaml
api_candidates:
  - "https://example/api/search?keyword={query}"
```
Skill 会自动尝试 JSON 和 HTML 解析。它不会绕过验证码、登录、权限或访问控制。

## 数据原则
只有页面/API明确给出的真实成交价进入 `TRANSACTION_PRICE`；官方明确单套网签/合同成交进入 `OFFICIAL_SIGNED`。挂牌价、小区均价和历史参考价不会混入成交价；`8**万` 等隐藏价格不会被猜测。

## V1.5 自动字段映射
联网服务器遇到新的 JSON/API 返回时，V1.5 会自动扫描字段并生成 `field_mapping_report.json`。该报告只用于发现和诊断；成交价仍需满足现有价格类型和 PIT 规则后才能进入正式成交记录，避免因为模糊字段名产生伪成交价。
