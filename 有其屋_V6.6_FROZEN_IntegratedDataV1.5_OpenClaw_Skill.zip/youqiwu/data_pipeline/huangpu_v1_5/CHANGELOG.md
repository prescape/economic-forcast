# V1.5
- 新增多源成交融合引擎：按分期、日期、面积、总价、单价进行跨源匹配。
- 新增来源可信权重与 confidence_score。
- 新增 VERIFIED / HIGH_CONFIDENCE / CORROBORATED / REVIEW 状态。
- 新增价格/单价冲突检测，冲突记录不静默覆盖。
- 新增 fused_transactions.json/csv 与 confidence_report.json。
- 仅 PIT 有效且属于真实成交/官方网签的记录进入融合层；挂牌/参考价绝不参与成交融合。

# CHANGELOG

## V1.3 — 服务器实网适配版
- 新增 AdaptiveFetcher：HTML / JSON / API 候选统一抓取。
- 新增页面内 API/搜索接口自动发现（不执行 JS，不绕过登录/验证码）。
- 新增响应诊断：JSON/HTML 类型、JS Shell、目标小区命中、成交关键词命中。
- 新增 `diagnostics.json`，给出各来源访问/解析诊断及下一步接口适配提示。
- `api_candidates`、`search_url_templates` 完全配置化，可直接粘贴服务器浏览器 Network 中发现的公开 API。
- 深圳官方默认入口更新为 `https://fdc.zjj.sz.gov.cn/`。
- 保留 Raw Snapshot、PIT、Evidence、隐藏价格禁止推测、CSV/JSON 输出。

## V1.5.0
- 新增自动 API/JSON 字段学习器 `field_mapper.py`。
- 自动将 xqName/communityName 等映射到 community，dealDate/signDate 映射到 transaction_date。
- 自动识别 area/buildArea、dealPrice/contractPrice、unitPrice 等常见字段。
- 字段映射采用字段名 + 值模式联合置信度评分，不直接信任未知字段。
- 新增 `field_mapping_report.json`，输出最佳映射、候选映射、置信度和未识别字段。
- AdaptiveFetcher 对 JSON 响应自动执行字段学习，并将结果写入诊断链路。
