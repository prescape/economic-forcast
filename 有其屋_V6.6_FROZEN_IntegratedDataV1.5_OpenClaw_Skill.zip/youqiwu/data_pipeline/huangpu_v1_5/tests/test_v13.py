from youqiwu_huangpu_skill.diagnostics import classify_payload,discover_endpoints,inspect_response

def test_payload_classification():
    assert classify_payload('{"x":1}','application/json')=='json'
    assert classify_payload('<html></html>','text/html')=='html'

def test_endpoint_discovery():
    html='<script>const u="/api/house/deal/list"</script><a href="/search?q=x">x</a>'
    xs=discover_endpoints(html,'https://example.com/a')
    assert 'https://example.com/api/house/deal/list' in xs

def test_js_shell_detection():
    d=inspect_response("<html>We're sorry but app doesn't work properly without JavaScript enabled.</html>",{'content_type':'text/html'})
    assert d['js_shell'] is True
