
from youqiwu_huangpu_skill.models import Transaction
from youqiwu_huangpu_skill.fusion import pair_score, fuse

def tx(source, date="2026-07-05", area=108.0, price=850, unit=78704, ptype="TRANSACTION_PRICE"):
    return Transaction(community="黄埔雅苑", phase="二期", transaction_date=date, area_sqm=area,
        total_price_wan=price, unit_price=unit, source=source, price_type=ptype, pit_valid=True,
        evidence_id=source+"-1")

def test_pair_match():
    assert pair_score(tx("ershoufangdata"), tx("official_sz", area=108.2, price=852, unit=78743, ptype="OFFICIAL_SIGNED")) > .72

def test_official_plus_thirdparty_verified():
    out=fuse([tx("ershoufangdata"),tx("official_sz", area=108.2, price=852, unit=78743, ptype="OFFICIAL_SIGNED")])
    assert len(out)==1
    assert out[0]["verification_status"]=="VERIFIED"
    assert out[0]["source_count"]==2
    assert out[0]["confidence_score"] > .85

def test_reference_price_excluded():
    r=tx("leyoujia", ptype="REFERENCE_PRICE")
    assert fuse([r]) == []

def test_conflict_goes_review():
    # Same date/area/unit enough to cluster, but total price conflicts strongly.
    a=tx("ershoufangdata",price=850,unit=78704)
    b=tx("official_sz",price=950,unit=79000,ptype="OFFICIAL_SIGNED")
    out=fuse([a,b], threshold=.60)
    assert out[0]["verification_status"]=="REVIEW"
    assert "total_price_conflict" in out[0]["conflicts"]
