from youqiwu_huangpu_skill.models import Transaction
from youqiwu_huangpu_skill.dedupe import dedupe

def test_merge():
    a=Transaction(phase="一期",transaction_date="2026-07-05",area_sqm=108,source="a",price_type="TRANSACTION_PRICE",confidence=.8)
    b=Transaction(phase="一期",transaction_date="2026-07-06",area_sqm=108.2,source="b",price_type="TRANSACTION_PRICE",confidence=.9)
    r=dedupe([a,b]); assert len(r)==1 and "merged_sources" in r[0].extra
