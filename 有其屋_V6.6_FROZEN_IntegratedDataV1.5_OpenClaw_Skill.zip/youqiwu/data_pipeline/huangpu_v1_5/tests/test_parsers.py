from youqiwu_huangpu_skill.sources.ershoufangdata import parse_transactions
from youqiwu_huangpu_skill.sources.official_sz import parse_official

def test_ershoufangdata_parser():
    html='<div>黄埔雅苑二期 2026-07-05 建筑面积108.2㎡ 成交价850万 成交单价78558元/㎡</div>'
    r=parse_transactions(html,'https://example')[0]
    assert r.phase=='二期' and r.total_price_wan==850 and r.price_type=='TRANSACTION_PRICE'

def test_official_parser():
    html='<div>黄埔雅苑一期 2026年07月05日 建筑面积107.9㎡ 网签价820万 网签单价75996元/㎡</div>'
    r=parse_official(html,'https://official')[0]
    assert r.phase=='一期' and r.price_type=='OFFICIAL_SIGNED' and r.total_price_wan==820

def test_no_guess_hidden_price():
    html='<div>黄埔雅苑一期 2026-07-05 建筑面积108㎡ 成交价8**万</div>'
    assert parse_transactions(html,'https://example')==[]
