from youqiwu_huangpu_skill.field_mapper import learn_mapping

def test_learns_common_api_fields():
    p={'data':[{'xqName':'黄埔雅苑二期','dealDate':'2026-07-05','buildArea':108.2,'dealPrice':850,'unitPrice':78558}]}
    r=learn_mapping(p,'demo')['mapping']
    assert r['community']['field']=='xqName'
    assert r['transaction_date']['field']=='dealDate'
    assert r['area_sqm']['field']=='buildArea'
    assert r['total_price_wan']['field']=='dealPrice'
    assert r['unit_price']['field']=='unitPrice'

def test_unknown_fields_reported():
    p={'foo':'bar','opaqueCode':'abc'}
    r=learn_mapping(p)
    names={x['field'] for x in r['unmapped_fields']}
    assert 'foo' in names and 'opaqueCode' in names
