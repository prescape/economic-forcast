import json
from youqiwu_huangpu_skill.sources.ershoufangdata import parse_transactions,parse_json_payload
from youqiwu_huangpu_skill.sources.official_sz import parse_official

def test_ershoufang_html_real_transaction():
    h='<li>黄埔雅苑二期 2026-08-01 建筑面积 100.5㎡ 成交价 900万 成交单价 89552元/㎡ 3室2厅</li>'
    r=parse_transactions(h,'u')
    assert len(r)==1 and r[0].price_type=='TRANSACTION_PRICE' and r[0].total_price_wan==900

def test_hidden_price_rejected():
    h='<li>黄埔雅苑一期 2026-07-05 建筑面积108㎡ 成交价8**万</li>'
    assert parse_transactions(h,'u')==[]

def test_json_payload():
    p={'rows':[{'name':'黄埔雅苑三期','date':'2026-06-01','建筑面积':'88㎡','成交价':'780万','成交单价':'88636元/㎡'}]}
    r=parse_json_payload(p,'api')
    assert len(r)>=1 and r[0].phase=='三期'

def test_official_signed():
    h='<div>黄埔雅苑四期 2026年5月2日 建筑面积 120㎡ 网签价 1000万 网签单价 83333元/㎡</div>'
    r=parse_official(h,'official')
    assert r[0].price_type=='OFFICIAL_SIGNED' and r[0].confidence>=.97
