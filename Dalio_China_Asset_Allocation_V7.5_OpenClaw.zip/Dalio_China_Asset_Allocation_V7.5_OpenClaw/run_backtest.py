#!/usr/bin/env python3
import subprocess, sys
from pathlib import Path
r=Path(__file__).resolve().parent
pit=r/'data'/'pit'/'unified_pit.csv'
factors=r/'data'/'reference'/'V7.3_factor_panel_completed.csv'
out=r/'outputs'/'v75_output'
if not pit.exists():
    raise SystemExit('Missing data/pit/unified_pit.csv. Run: python scripts/fetch_all_pit.py')
cmd=[sys.executable,str(r/'engine'/'walk_forward_v75.py'),'--input',str(pit),'--factors',str(factors),'--output-dir',str(out)]
raise SystemExit(subprocess.call(cmd))
