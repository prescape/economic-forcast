#!/usr/bin/env python3
import subprocess, sys
from pathlib import Path
r=Path(__file__).resolve().parent
pit=r/'data'/'pit'/'unified_pit.csv'
factors=r/'data'/'reference'/'V7.3_factor_panel_completed.csv'
v74=r/'outputs'/'v74_output'/'V7.4_walk_forward_132_nodes_results.csv'
v75=r/'outputs'/'v75_output'/'V7.5_backtest_summary.json'
out=r/'outputs'/'v75_robustness_output'
if not pit.exists():
    raise SystemExit('Missing data/pit/unified_pit.csv. Run: python scripts/fetch_all_pit.py')
cmd=[sys.executable,str(r/'tests'/'robustness_test_v75.py'),'--input',str(pit),'--factors',str(factors),'--v74',str(v74),'--v75-summary',str(v75),'--output-dir',str(out)]
raise SystemExit(subprocess.call(cmd))
