#!/usr/bin/env python3
"""有其屋 V6.6 Inventory Vintage.
Separates fresh supply from aged/stale unsold inventory; does not produce a generic score.
"""
from __future__ import annotations
import argparse,json
from datetime import date

def bucket(age):
    if age<=30:return "FRESH_0_30D"
    if age<=90:return "NORMAL_31_90D"
    if age<=180:return "AGED_91_180D"
    return "STALE_180D_PLUS"

def analyze(rows,as_of):
    obs=date.fromisoformat(as_of); buckets={k:0.0 for k in ["FRESH_0_30D","NORMAL_31_90D","AGED_91_180D","STALE_180D_PLUS"]}; detail=[]
    for r in rows:
        age=(obs-date.fromisoformat(r["permit_date"])).days
        if age<0: continue
        rem=max(0,float(r.get("supply",0))-float(r.get("sold_as_of",r.get("sold",0))))
        b=bucket(age); buckets[b]+=rem
        detail.append({"batch_id":r.get("batch_id"),"age_days":age,"remaining":rem,"vintage":b})
    total=sum(buckets.values()); old=buckets["AGED_91_180D"]+buckets["STALE_180D_PLUS"]
    stale_share=None if total<=0 else buckets["STALE_180D_PLUS"]/total
    aged_share=None if total<=0 else old/total
    flag="NO_INVENTORY" if total<=0 else "HIGH_AGED_OVERHANG" if (aged_share or 0)>=0.5 else "MATERIAL_AGED_OVERHANG" if (aged_share or 0)>=0.25 else "MOSTLY_FRESH_OR_NORMAL"
    return {"as_of":as_of,"remaining_total":total,"vintage_buckets":buckets,"aged_plus_share":None if aged_share is None else round(aged_share,4),"stale_share":None if stale_share is None else round(stale_share,4),"inventory_state":flag,"detail":detail}

def main():
    p=argparse.ArgumentParser();p.add_argument("input");p.add_argument("--as-of",required=True);a=p.parse_args();x=json.load(open(a.input,encoding="utf-8"));print(json.dumps(analyze(x.get("batches",x),a.as_of),ensure_ascii=False,indent=2))
if __name__=="__main__":main()
