#!/usr/bin/env python3
"""有其屋 V6.3 Pairwise Comparison Engine.

Compares two independently analyzed properties without replacing their underlying
V6.2 BUY/HOLD/SELL decisions. Supports candidate-vs-candidate and replacement mode.
"""
import argparse, json, math

BUY_ACTIONS = {"STRONG_BUY", "BUY", "NEGOTIATE_BUY", "NEGOTIATE"}
BLOCKED_ACTIONS = {"WAIT", "WATCH", "AVOID", "REJECT", "DATA_INSUFFICIENT"}


def clamp(v, lo=0.0, hi=100.0):
    return max(lo, min(hi, float(v)))


def norm(v, lo, hi, reverse=False):
    if v is None or hi == lo:
        return None
    x = clamp((float(v)-lo)/(hi-lo)*100)
    return 100-x if reverse else x


def get(d, *keys, default=None):
    cur=d
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur=cur[k]
    return cur


def metric(d, key):
    aliases={
        'action': [('decision','action'), ('action',)],
        'confidence': [('decision','confidence'), ('confidence_score',), ('data_confidence','score')],
        'mos': [('valuation','safety_margin'), ('margin_of_safety',)],
        'base_irr': [('returns','base_irr_pct'), ('base_irr_pct',)],
        'bear_irr': [('returns','bear_irr_pct'), ('bear_irr_pct',)],
        'liquidity': [('liquidity','score'), ('liquidity_score',)],
        'supply': [('supply_demand','pressure_score'), ('supply_pressure_score',)],
        'quality': [('scores','asset_quality'), ('asset_quality_score',)],
        'submarket': [('scores','city_submarket'), ('submarket_score',)],
        'trend': [('scores','trend'), ('trend_score',)],
    }
    for path in aliases[key]:
        v=get(d,*path)
        if v is not None: return v
    return None


def pair_score(d, weights=None):
    """Risk-adjusted 0-100 comparison score. Missing metrics reduce confidence, not silently pass."""
    weights = weights or {
        'base_irr':0.23, 'bear_irr':0.12, 'mos':0.18, 'liquidity':0.13,
        'supply':0.10, 'quality':0.09, 'submarket':0.08, 'trend':0.07,
    }
    raw={
        'base_irr': norm(metric(d,'base_irr'), -5, 12),
        'bear_irr': norm(metric(d,'bear_irr'), -12, 6),
        'mos': norm(metric(d,'mos'), -0.20, 0.30),
        'liquidity': norm(metric(d,'liquidity'), 0, 100),
        'supply': norm(metric(d,'supply'), 0, 100, reverse=True),
        'quality': norm(metric(d,'quality'), 0, 100),
        'submarket': norm(metric(d,'submarket'), 0, 100),
        'trend': norm(metric(d,'trend'), 0, 100),
    }
    available={k:v for k,v in raw.items() if v is not None}
    if not available:
        return {'score':None,'coverage':0,'components':raw}
    wsum=sum(weights[k] for k in available)
    score=sum(available[k]*weights[k] for k in available)/wsum
    coverage=wsum/sum(weights.values())*100
    # Confidence penalty prevents sparse evidence from winning on a few flattering metrics.
    conf=metric(d,'confidence')
    if conf is not None:
        score *= (0.75 + 0.25*clamp(conf)/100)
    if coverage < 60:
        score *= 0.90
    return {'score':round(score,2),'coverage':round(coverage,1),'components':raw}


def hard_block(d):
    action=str(metric(d,'action') or '').upper()
    override=get(d,'risk_override','triggered',default=False) or d.get('hard_override',False)
    conf=metric(d,'confidence')
    reasons=[]
    if override: reasons.append('HARD_RISK_OVERRIDE')
    if action in {'REJECT','DATA_INSUFFICIENT'}: reasons.append('UNDERLYING_DECISION_'+action)
    if conf is not None and float(conf)<50: reasons.append('CONFIDENCE_LT_50')
    return reasons


def compare(a,b,mode='purchase',replacement_cost_pct=0.0,min_advantage_points=5.0,
            min_incremental_irr_pct=1.5):
    sa, sb = pair_score(a), pair_score(b)
    ba, bb = hard_block(a), hard_block(b)
    aa=str(metric(a,'action') or 'UNKNOWN').upper(); ab=str(metric(b,'action') or 'UNKNOWN').upper()
    result={'mode':mode,'A':{'action':aa,**sa,'blocks':ba},'B':{'action':ab,**sb,'blocks':bb}}

    if ba and bb:
        result.update({'winner':'NEITHER','decision':'REJECT_BOTH','reason_codes':['BOTH_BLOCKED']}); return result
    if ba:
        result.update({'winner':'B','decision':'PREFER_B','reason_codes':['A_BLOCKED']}); return result
    if bb:
        result.update({'winner':'A','decision':'PREFER_A','reason_codes':['B_BLOCKED']}); return result
    if sa['score'] is None or sb['score'] is None:
        result.update({'winner':'NEITHER','decision':'DATA_INSUFFICIENT','reason_codes':['PAIR_SCORE_MISSING']}); return result

    diff=round(sa['score']-sb['score'],2)
    result['relative_score_delta_A_minus_B']=diff

    if mode=='replacement':
        # A = currently-owned property; B = proposed replacement.
        hold_irr=metric(a,'base_irr'); replace_irr=metric(b,'base_irr')
        if hold_irr is None or replace_irr is None:
            result.update({'winner':'A','decision':'HOLD_A','reason_codes':['MISSING_FORWARD_IRR_FOR_REPLACEMENT']}); return result
        incremental=float(replace_irr)-float(hold_irr)-float(replacement_cost_pct)
        result['incremental_irr_after_switching_cost_pct']=round(incremental,2)
        if ab not in BUY_ACTIONS:
            result.update({'winner':'A','decision':'HOLD_A','reason_codes':['B_NOT_BUYABLE']}); return result
        if diff <= min_advantage_points and incremental >= min_incremental_irr_pct:
            result.update({'winner':'B','decision':'SELL_A_BUY_B','reason_codes':['SWITCH_ECONOMICS_PASS']}); return result
        result.update({'winner':'A','decision':'HOLD_A','reason_codes':['SWITCH_ADVANTAGE_INSUFFICIENT']}); return result

    # Purchase comparison: independent V6.2 decisions remain binding.
    buyable_a=aa in BUY_ACTIONS; buyable_b=ab in BUY_ACTIONS
    if not buyable_a and not buyable_b:
        result.update({'winner':'NEITHER','decision':'BUY_NEITHER','reason_codes':['NO_BUYABLE_CANDIDATE']}); return result
    if buyable_a and not buyable_b:
        result.update({'winner':'A','decision':'PREFER_A','reason_codes':['ONLY_A_BUYABLE']}); return result
    if buyable_b and not buyable_a:
        result.update({'winner':'B','decision':'PREFER_B','reason_codes':['ONLY_B_BUYABLE']}); return result
    if abs(diff)<min_advantage_points:
        result.update({'winner':'TIE','decision':'NO_MATERIAL_ADVANTAGE','reason_codes':['SCORE_GAP_BELOW_THRESHOLD']}); return result
    result.update({'winner':'A' if diff>0 else 'B','decision':'PREFER_A' if diff>0 else 'PREFER_B','reason_codes':['RISK_ADJUSTED_SCORE_ADVANTAGE']})
    return result


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--a',required=True,help='Property A V6.2/V6.3 analysis JSON')
    p.add_argument('--b',required=True,help='Property B V6.2/V6.3 analysis JSON')
    p.add_argument('--mode',choices=['purchase','replacement'],default='purchase')
    p.add_argument('--replacement-cost-pct',type=float,default=0.0,help='Annualized IRR drag from taxes/fees/moving etc.')
    p.add_argument('--min-advantage-points',type=float,default=5.0)
    p.add_argument('--min-incremental-irr-pct',type=float,default=1.5)
    a=p.parse_args()
    with open(a.a,encoding='utf-8') as f: A=json.load(f)
    with open(a.b,encoding='utf-8') as f: B=json.load(f)
    print(json.dumps(compare(A,B,a.mode,a.replacement_cost_pct,a.min_advantage_points,a.min_incremental_irr_pct),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
