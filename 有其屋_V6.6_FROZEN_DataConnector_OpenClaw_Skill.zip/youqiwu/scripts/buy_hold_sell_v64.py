#!/usr/bin/env python3
"""有其屋 V6.4 decision wrapper.
Keeps V6.2 valuation/trend gates binding and adds new-home market intelligence gates.
"""
import argparse, json
from buy_hold_sell_v62 import decide as decide_v62

BUYISH={'BUY','STRONG_BUY'}

def decide(d):
    base=decide_v62(d)
    result=dict(base)
    result['engine']='buy_hold_sell_v64'
    if str(d.get('property_market_type','')).lower() not in {'new_home','primary','new'}:
        result['v64_new_home_gates']='NOT_APPLICABLE'
        return result
    if base.get('action') not in BUYISH:
        result['v64_new_home_gates']='BASE_DECISION_BINDING'
        return result
    reasons=list(base.get('reason_codes') or [])
    absorption=str(d.get('absorption_status') or '').upper()
    exit_risk=str(d.get('secondary_exit_risk') or '').upper()
    timing=str(d.get('timing_action') or '').upper()
    if absorption=='WEAK': reasons.append('NEW_HOME_ABSORPTION_WEAK')
    if exit_risk=='HIGH': reasons.append('SECONDARY_EXIT_RISK_HIGH')
    if timing in {'POOR_ENTRY_WINDOW','NEUTRAL_WAIT_FOR_PRICE'}: reasons.append('ENTRY_TIMING_NOT_CONFIRMED')
    if any(x in reasons for x in ['NEW_HOME_ABSORPTION_WEAK','SECONDARY_EXIT_RISK_HIGH']):
        result.update({'action':'WAIT','confirmation_pass':False,'reason_codes':reasons,'v64_new_home_gates':'FAIL'})
    elif 'ENTRY_TIMING_NOT_CONFIRMED' in reasons:
        result.update({'action':'NEGOTIATE','confirmation_pass':False,'reason_codes':reasons,'v64_new_home_gates':'PARTIAL'})
    else:
        result['v64_new_home_gates']='PASS'
    return result

def main():
    p=argparse.ArgumentParser(); p.add_argument('--input',required=True); a=p.parse_args()
    with open(a.input,encoding='utf-8') as f:d=json.load(f)
    print(json.dumps(decide(d),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
