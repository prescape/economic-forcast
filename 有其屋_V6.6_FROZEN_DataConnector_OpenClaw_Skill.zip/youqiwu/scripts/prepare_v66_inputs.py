#!/usr/bin/env python3
from __future__ import annotations
import json, argparse
from pathlib import Path
from data_connector_v66 import load_project_bundle


def prepare(project, data_root=None):
    b=load_project_bundle(project,data_root)
    ds=b["datasets"]
    return {
      "project_id": b["project_id"],
      "data_gate": b["data_gate"],
      "evidence_records": b["evidence"]["rows"],
      "permits": ds["permits"]["rows"],
      "sales_snapshots": ds["newhouse_sales"]["rows"],
      "inventory_snapshots": ds["inventory"]["rows"],
      "price_snapshots": ds["prices"]["rows"],
      "secondary_listings": ds["secondary_listings"]["rows"],
      "secondary_transactions": ds["secondary_transactions"]["rows"],
      "rent_snapshots": ds["rents"]["rows"],
      "freshness": {k:v["freshness"] for k,v in ds.items()}
    }

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--project',required=True); ap.add_argument('--data-root')
    a=ap.parse_args(); print(json.dumps(prepare(a.project,a.data_root),ensure_ascii=False,indent=2))
