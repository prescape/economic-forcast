#!/usr/bin/env python3
"""External Data Connector binding for 有其屋 V6.6-FROZEN.

This module does NOT change investment logic or thresholds. It only resolves,
reads and validates standardized datasets produced by 有其屋 Data Pipeline.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone, date
import csv, json, os

SKILL_ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = SKILL_ROOT / "config" / "data_connector_v66.json"


def load_config():
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def resolve_data_root(explicit=None):
    cfg = load_config()
    candidates = []
    if explicit: candidates.append(Path(explicit).expanduser())
    if os.getenv("YOUQI_WU_DATA_ROOT"):
        candidates.append(Path(os.environ["YOUQI_WU_DATA_ROOT"]).expanduser())
    candidates.append(Path("~/.openclaw/workspace/data/youqiwu").expanduser())
    for root in candidates:
        if root.exists():
            # Pipeline package may keep data/ under deployment root, or deploy contents directly.
            if (root/"data"/"pit").exists():
                return root, root/"data"
            if (root/"pit").exists():
                return root, root
            # Existing but empty/fresh install: prefer nested data layout used by Pipeline V1.x.
            if (root/"data").exists():
                return root, root/"data"
            return root, root/"data"
    # Return expected default without creating it: reader is non-mutating.
    root = candidates[-1]
    return root, root/"data"


def canonical_project(project):
    aliases = load_config().get("project_aliases", {})
    return aliases.get(project, project)


def _parse_time(value):
    if value in (None, ""): return None
    s = str(value).strip().replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None: dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        try:
            return datetime.fromisoformat(s[:10]).replace(tzinfo=timezone.utc)
        except Exception:
            return None


def _read_jsonl(path):
    rows=[]
    if not path.exists(): return rows
    with path.open("r",encoding="utf-8") as f:
        for n,line in enumerate(f,1):
            line=line.strip()
            if not line: continue
            try: rows.append(json.loads(line))
            except Exception as e: rows.append({"_parse_error":str(e),"_line":n,"_raw":line})
    return rows


def _read_csv(path):
    if not path.exists(): return []
    with path.open("r",encoding="utf-8-sig",newline="") as f:
        return list(csv.DictReader(f))


def _candidate_files(directory, project_id):
    if not directory.exists(): return []
    names = [f"{project_id}.jsonl", f"{project_id}.csv", f"{project_id}.json"]
    files=[directory/n for n in names if (directory/n).exists()]
    if files: return files
    # Allow date-partitioned/project-partitioned normalized outputs.
    files = sorted([p for p in directory.rglob("*") if p.is_file() and project_id.lower() in p.name.lower()])
    return files


def read_dataset(dataset, project, data_root=None):
    cfg=load_config(); pid=canonical_project(project)
    deploy_root, data_dir=resolve_data_root(data_root)
    rel=cfg["datasets"].get(dataset)
    if not rel: raise KeyError(f"Unknown dataset: {dataset}")
    directory=data_dir/rel.replace("pit/", "pit/", 1)
    files=_candidate_files(directory,pid)
    rows=[]
    for p in files:
        if p.suffix==".jsonl": rows.extend(_read_jsonl(p))
        elif p.suffix==".csv": rows.extend(_read_csv(p))
        elif p.suffix==".json":
            try:
                x=json.loads(p.read_text(encoding="utf-8")); rows.extend(x if isinstance(x,list) else [x])
            except Exception as e: rows.append({"_parse_error":str(e),"_file":str(p)})
    # Defensive project filter when project_id field exists.
    filtered=[]
    for r in rows:
        rp=r.get("project_id") if isinstance(r,dict) else None
        if rp is None or canonical_project(str(rp))==pid: filtered.append(r)
    return {"dataset":dataset,"project_id":pid,"files":[str(x) for x in files],"rows":filtered,
            "deploy_root":str(deploy_root),"data_dir":str(data_dir)}


def read_evidence(project, data_root=None):
    pid=canonical_project(project); _,data_dir=resolve_data_root(data_root)
    path=data_dir/load_config()["evidence_registry"]
    rows=_read_jsonl(path)
    rows=[r for r in rows if not isinstance(r,dict) or canonical_project(str(r.get("project_id",pid)))==pid]
    return {"path":str(path),"rows":rows}


def freshness(dataset_result, now=None):
    cfg=load_config(); ds=dataset_result["dataset"]
    threshold=cfg.get("freshness_days",{}).get(ds)
    rows=dataset_result.get("rows",[]); timestamps=[]
    for r in rows:
        if not isinstance(r,dict): continue
        for key in ("observed_at","as_of_date","transaction_date","retrieved_at"):
            dt=_parse_time(r.get(key))
            if dt: timestamps.append(dt); break
    latest=max(timestamps) if timestamps else None
    now=now or datetime.now(timezone.utc)
    age=(now-latest).total_seconds()/86400 if latest else None
    if latest is None: status="MISSING"
    elif threshold is None: status="UNKNOWN"
    elif age <= threshold: status="FRESH"
    else: status="STALE"
    return {"latest_observation": latest.isoformat() if latest else None,
            "age_days": round(age,2) if age is not None else None,
            "threshold_days": threshold,"status":status}


def load_project_bundle(project, data_root=None):
    cfg=load_config(); pid=canonical_project(project)
    bundle={"project_id":pid,"connector":"V6.6-FROZEN Data Connector","datasets":{},"evidence":None}
    for ds in cfg["datasets"]:
        result=read_dataset(ds,pid,data_root)
        result["freshness"]=freshness(result)
        bundle["datasets"][ds]=result
    bundle["evidence"]=read_evidence(pid,data_root)
    statuses=[v["freshness"]["status"] for v in bundle["datasets"].values()]
    required = ["permits","newhouse_sales","inventory","prices"]
    required_status={k:bundle["datasets"][k]["freshness"]["status"] for k in required}
    if all(x=="FRESH" for x in required_status.values()): gate="PASS"
    elif any(x=="MISSING" for x in required_status.values()): gate="DATA_INSUFFICIENT"
    else: gate="STALE_OR_PARTIAL"
    bundle["data_gate"]={"status":gate,"required":required_status}
    return bundle


def summary(bundle):
    return {
        "project_id": bundle["project_id"],
        "data_gate": bundle["data_gate"],
        "datasets": {k:{"rows":len(v["rows"]),"freshness":v["freshness"],"files":v["files"]}
                     for k,v in bundle["datasets"].items()},
        "evidence_rows": len(bundle["evidence"]["rows"]),
        "evidence_path": bundle["evidence"]["path"]
    }

if __name__ == "__main__":
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument("--project",required=True)
    ap.add_argument("--data-root",default=None)
    ap.add_argument("--full",action="store_true")
    a=ap.parse_args()
    b=load_project_bundle(a.project,a.data_root)
    print(json.dumps(b if a.full else summary(b),ensure_ascii=False,indent=2,default=str))
