#!/usr/bin/env python3
"""有其屋 V6.4 Pairwise Engine extension.
Adds new-home absorption, secondary-exit quality and launch timing to V6.3 relative ranking,
while keeping each property's independent decision binding.
"""
import argparse, json
from pairwise_comparison_v63 import pair_score as base_pair_score, hard_block, metric, BUY_ACTIONS


def clamp(v,lo=0,hi=100): return max(lo,min(hi,float(v)))

def nested(d,*path,default=None):
    cur=d
    for k in path:
        if not isinstance(cur,dict) or k not in cur:return default
        cur=cur[k]
    return cur

def mi_score(d):
    vals=[]
    a=nested(d,'new_house_absorption','absorption_score')
    e=nested(d,'primary_secondary_divergence','secondary_exit_score')
    t=nested(d,'launch_inventory_timing','timing_score')
    for v,w,name in [(a,.40,'absorption'),(e,.40,'secondary_exit'),(t,.20,'timing')]:
        if v is not None: vals.append((clamp(v),w,name))
    if not vals:return {'score':None,'coverage':0,'components':{}}
    ws=sum(x[1] for x in vals)
    score=sum(x[0]*x[1] for x in vals)/ws
    return {'score':round(score,2),'coverage':round(ws*100,1),'components':{x[2]:x[0] for x in vals}}

def score(d):
    b=base_pair_score(d); m=mi_score(d)
    if b['score'] is None:return {'score':None,'base':b,'market_intelligence':m}
    if m['score'] is None:return {'score':b['score'],'base':b,'market_intelligence':m}
    return {'score':round(b['score']*.85+m['score']*.15,2),'base':b,'market_intelligence':m}

def compare(A,B,mode='purchase',replacement_cost_pct=0,min_advantage_points=5,min_incremental_irr_pct=1.5):
    sa,sb=score(A),score(B); ba,bb=hard_block(A),hard_block(B)
    aa=str(metric(A,'action') or 'UNKNOWN').upper(); ab=str(metric(B,'action') or 'UNKNOWN').upper()
    out={'engine':'pairwise_comparison_v64','mode':mode,'A':{'action':aa,**sa,'blocks':ba},'B':{'action':ab,**sb,'blocks':bb}}
    if ba and bb: out.update(winner='NEITHER',decision='REJECT_BOTH',reason_codes=['BOTH_BLOCKED']); return out
    if ba: out.update(winner='B',decision='PREFER_B',reason_codes=['A_BLOCKED']); return out
    if bb: out.update(winner='A',decision='PREFER_A',reason_codes=['B_BLOCKED']); return out
    if sa['score'] is None or sb['score'] is None: out.update(winner='NEITHER',decision='DATA_INSUFFICIENT',reason_codes=['PAIR_SCORE_MISSING']); return out
    diff=round(sa['score']-sb['score'],2); out['relative_score_delta_A_minus_B']=diff
    if mode=='replacement':
        ai=metric(A,'base_irr'); bi=metric(B,'base_irr')
        if ai is None or bi is None: out.update(winner='A',decision='HOLD_A',reason_codes=['MISSING_FORWARD_IRR_FOR_REPLACEMENT']); return out
        inc=float(bi)-float(ai)-float(replacement_cost_pct); out['incremental_irr_after_switching_cost_pct']=round(inc,2)
        if ab not in BUY_ACTIONS: out.update(winner='A',decision='HOLD_A',reason_codes=['B_NOT_BUYABLE']); return out
        if diff <= min_advantage_points and inc>=min_incremental_irr_pct: out.update(winner='B',decision='SELL_A_BUY_B',reason_codes=['SWITCH_ECONOMICS_PASS']); return out
        out.update(winner='A',decision='HOLD_A',reason_codes=['SWITCH_ADVANTAGE_INSUFFICIENT']); return out
    buyA=aa in BUY_ACTIONS; buyB=ab in BUY_ACTIONS
    if not buyA and not buyB: out.update(winner='NEITHER',decision='BUY_NEITHER',reason_codes=['NO_BUYABLE_CANDIDATE']); return out
    if buyA and not buyB: out.update(winner='A',decision='PREFER_A',reason_codes=['ONLY_A_BUYABLE']); return out
    if buyB and not buyA: out.update(winner='B',decision='PREFER_B',reason_codes=['ONLY_B_BUYABLE']); return out
    if abs(diff)<min_advantage_points: out.update(winner='TIE',decision='NO_MATERIAL_ADVANTAGE',reason_codes=['SCORE_GAP_BELOW_THRESHOLD']); return out
    out.update(winner='A' if diff>0 else 'B',decision='PREFER_A' if diff>0 else 'PREFER_B',reason_codes=['V64_RISK_ADJUSTED_SCORE_ADVANTAGE']); return out

def main():
    p=argparse.ArgumentParser();p.add_argument('--a',required=True);p.add_argument('--b',required=True);p.add_argument('--mode',choices=['purchase','replacement'],default='purchase');p.add_argument('--replacement-cost-pct',type=float,default=0);p.add_argument('--min-advantage-points',type=float,default=5);p.add_argument('--min-incremental-irr-pct',type=float,default=1.5);a=p.parse_args()
    with open(a.a,encoding='utf-8') as f:A=json.load(f)
    with open(a.b,encoding='utf-8') as f:B=json.load(f)
    print(json.dumps(compare(A,B,a.mode,a.replacement_cost_pct,a.min_advantage_points,a.min_incremental_irr_pct),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
