#!/usr/bin/env python3
"""有其屋 V6.4 - Launch & Inventory Timing Engine."""
import argparse, json


def clamp(v,lo=0,hi=100): return max(lo,min(hi,float(v)))

def analyze(d):
    days=d.get('days_since_latest_permit')
    avail=d.get('available_units')
    supply=d.get('latest_permit_supply_units')
    sold=d.get('sold_since_latest_permit_units')
    discount=d.get('effective_discount_pct')
    selection=d.get('unit_selection_score') # 0-100: floor/orientation/stack choice availability
    future=d.get('future_supply_units_180d')
    monthly=d.get('monthly_sales_units')
    score=50.0; reasons=[]
    absorption=None
    if supply not in (None,0) and sold is not None:
        absorption=float(sold)/float(supply)*100
    if days is not None:
        days=float(days)
        if days<=45: score+=10; reasons.append('FRESH_LAUNCH_WINDOW')
        elif days>180: score-=4
    if selection is not None:
        score+=(float(selection)-50)*0.25
        if float(selection)>=70: reasons.append('GOOD_UNIT_SELECTION')
    if discount is not None:
        score+=max(-5,min(12,float(discount)*1.5))
        if float(discount)>=5: reasons.append('MEANINGFUL_EFFECTIVE_DISCOUNT')
    if absorption is not None:
        if absorption<20 and days is not None and days<=45:
            reasons.append('EARLY_STAGE_LOW_ABSORPTION_NOT_YET_NEGATIVE')
        elif absorption<30 and days is not None and days>90:
            score-=15; reasons.append('SLOW_MATURE_ABSORPTION')
        elif absorption>=70:
            score-=5; reasons.append('HIGH_ABSORPTION_REDUCES_CHOICE_AND_BARGAINING')
    if future not in (None,0) and monthly not in (None,0):
        future_months=float(future)/float(monthly)
        if future_months>=6:
            score+=8; reasons.append('FUTURE_SUPPLY_SUPPORTS_BUYER_BARGAINING')
    else:
        future_months=None
    if avail is not None and monthly not in (None,0):
        moi=float(avail)/float(monthly)
        if moi>=18: score+=8; reasons.append('HIGH_INVENTORY_BUYER_WINDOW')
        elif moi<=4: score-=8; reasons.append('LOW_INVENTORY_SELLER_WINDOW')
    else: moi=None
    score=round(clamp(score),2)
    if score>=70: action='PRIME_NEGOTIATION_WINDOW'
    elif score>=58: action='SELECTIVE_BUY_WINDOW'
    elif score>=42: action='NEUTRAL_WAIT_FOR_PRICE'
    else: action='POOR_ENTRY_WINDOW'
    return {
        'engine':'launch_inventory_timing_v64',
        'timing_score':score,
        'timing_action':action,
        'latest_cohort_absorption_pct':round(absorption,2) if absorption is not None else None,
        'months_of_inventory':round(moi,2) if moi is not None else None,
        'future_supply_months_at_current_velocity':round(future_months,2) if future_months is not None else None,
        'reason_codes':reasons or ['NO_STRONG_TIMING_EDGE'],
        'discipline':'入市窗口只影响谈判与选货，不得覆盖 Fair Value、IRR、Risk Override 和 V6.2 买入确认门。'
    }

def main():
    p=argparse.ArgumentParser(); p.add_argument('--input',required=True); a=p.parse_args()
    with open(a.input,encoding='utf-8') as f:d=json.load(f)
    print(json.dumps(analyze(d),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
