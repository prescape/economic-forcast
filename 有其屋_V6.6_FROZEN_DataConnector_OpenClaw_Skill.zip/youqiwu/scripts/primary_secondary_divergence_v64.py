#!/usr/bin/env python3
"""有其屋 V6.4 - Primary/Secondary Market Divergence Engine.

Detects cases where new-home heat is not confirmed by secondary-market exit liquidity.
"""
import argparse, json


def clamp(v, lo=0, hi=100): return max(lo,min(hi,float(v)))

def analyze(d):
    np=d.get('new_home_price_yoy_pct'); nv=d.get('new_home_volume_yoy_pct')
    sp=d.get('secondary_price_yoy_pct'); sv=d.get('secondary_volume_yoy_pct')
    disc=d.get('secondary_discount_to_listing_pct')
    dom=d.get('secondary_days_on_market')
    viewers=d.get('secondary_viewing_change_pct')
    new_heat=50.0; exit_score=50.0; reasons=[]
    if nv is not None: new_heat += max(-20,min(20,float(nv)*0.45))
    if np is not None: new_heat += max(-15,min(15,float(np)*0.7))
    if sp is not None: exit_score += max(-22,min(22,float(sp)*1.1))
    if sv is not None: exit_score += max(-12,min(12,float(sv)*0.35))
    if disc is not None:
        # discount entered as positive percentage (e.g. 30 means transaction 30% below listing)
        exit_score -= max(0,min(22,(float(disc)-10)*0.8))
    if dom is not None:
        if float(dom)>300: exit_score-=18
        elif float(dom)>180: exit_score-=10
        elif float(dom)<90: exit_score+=8
    if viewers is not None and float(viewers)<-10: exit_score-=7
    new_heat=round(clamp(new_heat),2); exit_score=round(clamp(exit_score),2)
    gap=round(new_heat-exit_score,2)
    if gap>=25:
        state='NEW_HOT_SECONDARY_WEAK'; risk='HIGH'; reasons.append('NEW_HOME_HEAT_NOT_CONFIRMED_BY_EXIT_MARKET')
    elif gap>=12:
        state='DIVERGENT'; risk='MEDIUM'; reasons.append('PRIMARY_SECONDARY_DIVERGENCE')
    elif exit_score<35:
        state='SECONDARY_WEAK'; risk='HIGH'; reasons.append('SECONDARY_EXIT_LIQUIDITY_WEAK')
    else:
        state='BALANCED_OR_CONVERGING'; risk='LOW'
    return {
        'engine':'primary_secondary_divergence_v64',
        'new_home_heat_score':new_heat,
        'secondary_exit_score':exit_score,
        'divergence_gap':gap,
        'market_state':state,
        'secondary_exit_risk':risk,
        'reason_codes':reasons or ['NO_MAJOR_DIVERGENCE_DETECTED'],
        'decision_note':'新房热销只说明当期一手需求；投资判断必须额外验证交付后的二手价格与流动性。'
    }

def main():
    p=argparse.ArgumentParser(); p.add_argument('--input',required=True); a=p.parse_args()
    with open(a.input,encoding='utf-8') as f:d=json.load(f)
    print(json.dumps(analyze(d),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
