#!/usr/bin/env python3
"""有其屋 V6.4 - New-House Absorption Engine.

Measures permit-cohort sell-through, sales velocity, inventory months and supply shock.
Never treats newly permitted zero-sales stock as mature weak demand without considering age.
"""
import argparse, json
from datetime import date, datetime


def clamp(x, lo=0.0, hi=100.0):
    return max(lo, min(hi, float(x)))


def parse_date(s):
    if not s:
        return None
    return datetime.strptime(str(s)[:10], "%Y-%m-%d").date()


def analyze(d):
    obs = parse_date(d.get("observation_date")) or date.today()
    tranches = d.get("permit_tranches") or []
    rows=[]
    total_supply=total_sold=0.0
    sold_30=supply_30=sold_90=supply_90=0.0
    mature_supply=mature_sold=0.0
    for t in tranches:
        supply=float(t.get("supply_units") or 0)
        sold=float(t.get("sold_units") or 0)
        permit=parse_date(t.get("permit_date"))
        age=(obs-permit).days if permit else None
        rate=(sold/supply*100) if supply>0 else None
        total_supply+=supply; total_sold+=sold
        if age is not None and age<=30:
            supply_30+=supply; sold_30+=sold
        if age is not None and age<=90:
            supply_90+=supply; sold_90+=sold
        if age is not None and age>=90:
            mature_supply+=supply; mature_sold+=sold
        rows.append({**t,"age_days":age,"absorption_rate_pct":round(rate,2) if rate is not None else None})

    cumulative=(total_sold/total_supply*100) if total_supply else None
    mature=(mature_sold/mature_supply*100) if mature_supply else None
    current_monthly_sales=d.get("monthly_sales_units")
    available=d.get("available_units")
    moi=None
    if current_monthly_sales not in (None,0) and available is not None:
        moi=float(available)/float(current_monthly_sales)

    recent_new_supply=d.get("recent_new_supply_units")
    prior_available=d.get("prior_available_units")
    supply_shock=None
    if recent_new_supply is not None and prior_available not in (None,0):
        supply_shock=float(recent_new_supply)/float(prior_available)*100

    score=50.0
    reasons=[]
    base = mature if mature is not None else cumulative
    if base is not None:
        score += (base-50)*0.45
        if base>=75: reasons.append("MATURE_ABSORPTION_STRONG")
        elif base<35: reasons.append("MATURE_ABSORPTION_WEAK")
    if moi is not None:
        if moi<=6: score+=15; reasons.append("INVENTORY_MONTHS_LOW")
        elif moi<=12: score+=5
        elif moi>24: score-=20; reasons.append("INVENTORY_MONTHS_HIGH")
        elif moi>18: score-=12
    if supply_shock is not None:
        if supply_shock>=75: score-=12; reasons.append("LARGE_NEW_SUPPLY_SHOCK")
        elif supply_shock>=40: score-=6
    score=round(clamp(score),2)
    status="STRONG" if score>=70 else "HEALTHY" if score>=55 else "MIXED" if score>=40 else "WEAK"
    return {
        "engine":"new_house_absorption_v64",
        "observation_date":obs.isoformat(),
        "permit_tranches":rows,
        "total_supply_units":round(total_supply,2),
        "total_sold_units":round(total_sold,2),
        "cumulative_absorption_rate_pct":round(cumulative,2) if cumulative is not None else None,
        "mature_90d_absorption_rate_pct":round(mature,2) if mature is not None else None,
        "recent_30d_cohort_absorption_pct":round(sold_30/supply_30*100,2) if supply_30 else None,
        "recent_90d_cohort_absorption_pct":round(sold_90/supply_90*100,2) if supply_90 else None,
        "months_of_inventory":round(moi,2) if moi is not None else None,
        "new_supply_shock_pct_of_prior_inventory":round(supply_shock,2) if supply_shock is not None else None,
        "absorption_score":score,
        "absorption_status":status,
        "reason_codes":reasons or ["NEUTRAL_OR_PARTIAL_EVIDENCE"],
        "data_warning":"刚取证批次的低去化不能直接等同需求弱；需结合取证天数、30/90天销售速度和新增供应。"
    }


def main():
    p=argparse.ArgumentParser(); p.add_argument('--input',required=True); a=p.parse_args()
    with open(a.input,encoding='utf-8') as f: d=json.load(f)
    print(json.dumps(analyze(d),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
