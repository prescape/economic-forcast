#!/usr/bin/env python3
"""有其屋 V6.6 Pre-Transaction Verification Gate.
Final BUY cannot pass until transaction-critical, real-time facts are verified.
"""
from __future__ import annotations
import argparse,json

DEFAULT_REQUIRED = ["target_unit_available","unit_price_sheet","actual_discount","subsidy_stackability","floor","orientation","delivery_milestone"]

def check(x):
    required=x.get("required_fields",DEFAULT_REQUIRED); fields=x.get("fields",{})
    missing=[]; unverified=[]; stale=[]
    for k in required:
        r=fields.get(k)
        if not r or r.get("value") in (None,""): missing.append(k); continue
        if str(r.get("status","UNVERIFIED")).upper() not in {"VERIFIED","CORROBORATED"}: unverified.append(k)
        if r.get("freshness") == "STALE": stale.append(k)
    if missing: gate="BLOCK_BUY"
    elif unverified or stale: gate="VERIFY_BEFORE_BUY"
    else: gate="PASS"
    requested=str(x.get("requested_action","WAIT")).upper(); allowed=requested
    if requested in {"BUY","STRONG_BUY"} and gate=="BLOCK_BUY": allowed="WAIT"
    elif requested in {"BUY","STRONG_BUY"} and gate=="VERIFY_BEFORE_BUY": allowed="NEGOTIATE_BUY"
    return {"verification_gate":gate,"requested_action":requested,"allowed_action":allowed,"missing":missing,"unverified":unverified,"stale":stale}

def main():
    p=argparse.ArgumentParser();p.add_argument("input");a=p.parse_args();print(json.dumps(check(json.load(open(a.input,encoding="utf-8"))),ensure_ascii=False,indent=2))
if __name__=="__main__":main()
