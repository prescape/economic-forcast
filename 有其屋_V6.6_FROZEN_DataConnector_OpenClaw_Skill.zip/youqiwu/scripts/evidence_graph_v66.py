#!/usr/bin/env python3
"""有其屋 V6.6 Evidence Graph.

Turns V6.5 evidence records into an auditable directed lineage graph. The graph
is descriptive, not an investment score: it answers which raw facts and model
assumptions feed each derived metric and decision.
"""
from __future__ import annotations
import json, argparse
from collections import defaultdict, deque

CRITICAL_OUTPUTS = {"fair_value", "mos", "irr_base", "irr_bear", "liquidity", "buy_hold_sell", "pairwise_decision"}

def build_graph(records):
    nodes = {}
    children = defaultdict(list)
    missing_parents = []
    duplicate_ids = []
    for r in records:
        eid = r.get("evidence_id")
        if not eid:
            continue
        if eid in nodes:
            duplicate_ids.append(eid)
        nodes[eid] = r
    for eid, r in nodes.items():
        for p in r.get("parent_evidence_ids", []) or []:
            if p not in nodes:
                missing_parents.append({"child": eid, "missing_parent": p})
            else:
                children[p].append(eid)
    return nodes, children, missing_parents, duplicate_ids

def ancestors(target, nodes):
    seen, q = set(), deque([target])
    while q:
        cur = q.popleft()
        for p in nodes.get(cur, {}).get("parent_evidence_ids", []) or []:
            if p in nodes and p not in seen:
                seen.add(p); q.append(p)
    return seen

def detect_cycle(nodes):
    state = {}
    def visit(n):
        state[n] = 1
        for p in nodes.get(n, {}).get("parent_evidence_ids", []) or []:
            if p not in nodes: continue
            if state.get(p) == 1: return True
            if state.get(p, 0) == 0 and visit(p): return True
        state[n] = 2
        return False
    return any(state.get(n,0)==0 and visit(n) for n in nodes)

def summarize(records):
    nodes, children, missing_parents, duplicate_ids = build_graph(records)
    terminal = [eid for eid in nodes if not children.get(eid)]
    critical = {}
    for eid, r in nodes.items():
        metric = str(r.get("metric", "")).lower()
        if metric in CRITICAL_OUTPUTS or r.get("decision_critical") is True:
            anc = ancestors(eid, nodes)
            raw = [a for a in anc if not (nodes[a].get("parent_evidence_ids") or [])]
            assumptions = [a for a in anc if nodes[a].get("evidence_status") == "MODEL_ASSUMPTION"]
            unver = [a for a in anc if nodes[a].get("evidence_status") in {"UNVERIFIED","MISSING"}]
            critical[eid] = {
                "metric": r.get("metric"), "ancestor_count": len(anc), "raw_leaf_count": len(raw),
                "model_assumption_ids": sorted(assumptions), "unverified_or_missing_ids": sorted(unver),
                "traceable": len(anc) > 0 and not missing_parents,
            }
    return {
        "node_count": len(nodes), "edge_count": sum(len(v) for v in children.values()),
        "terminal_node_ids": terminal, "missing_parent_links": missing_parents,
        "duplicate_evidence_ids": sorted(set(duplicate_ids)), "cycle_detected": detect_cycle(nodes),
        "critical_output_trace": critical,
        "graph_gate": "PASS" if not missing_parents and not duplicate_ids and not detect_cycle(nodes) else "FAIL",
    }

def main():
    p=argparse.ArgumentParser(); p.add_argument("input"); p.add_argument("--output")
    a=p.parse_args(); records=json.load(open(a.input,encoding="utf-8"))
    out=summarize(records)
    txt=json.dumps(out,ensure_ascii=False,indent=2)
    if a.output: open(a.output,"w",encoding="utf-8").write(txt+"\n")
    else: print(txt)
if __name__=="__main__": main()
