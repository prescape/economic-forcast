#!/usr/bin/env python3
"""有其屋 V6.5 Evidence Trace utilities.

Build auditable evidence records and calculate evidence confidence. This module
is intentionally data-source agnostic: crawlers/searchers collect evidence;
this module normalizes metadata and enforces decision-quality gates.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Iterable, Optional
import hashlib
import json

TIER_SCORE = {"S": 100.0, "A": 88.0, "B": 74.0, "C": 58.0, "D": 35.0}
STATUS_SCORE = {
    "VERIFIED": 100.0,
    "CORROBORATED": 88.0,
    "RECONSTRUCTED": 65.0,
    "UNVERIFIED": 35.0,
    "MODEL_ASSUMPTION": 50.0,
    "MISSING": 0.0,
}
PIT_SCORE = {
    "PIT_VERIFIED": 100.0,
    "RECONSTRUCTED": 65.0,
    "CURRENT_ONLY": 70.0,
    "NOT_APPLICABLE": 85.0,
    "UNKNOWN": 40.0,
}

@dataclass
class EvidenceRecord:
    metric: str
    raw_value: object = None
    normalized_value: object = None
    unit: Optional[str] = None
    geography: Optional[str] = None
    project: Optional[str] = None
    phase: Optional[str] = None
    observation_date: Optional[str] = None
    publication_date: Optional[str] = None
    retrieved_at: Optional[str] = None
    source_name: Optional[str] = None
    source_url_or_ref: Optional[str] = None
    source_tier: str = "D"
    evidence_status: str = "UNVERIFIED"
    pit_status: str = "UNKNOWN"
    methodology: Optional[str] = None
    transformation: Optional[str] = None
    parent_evidence_ids: tuple[str, ...] = ()
    confidence: Optional[float] = None
    notes: Optional[str] = None
    evidence_id: Optional[str] = None

    def finalize(self) -> dict:
        if self.retrieved_at is None:
            self.retrieved_at = datetime.now(timezone.utc).isoformat()
        if self.evidence_id is None:
            seed = "|".join(map(str, [
                self.metric, self.observation_date, self.source_name,
                self.source_url_or_ref, self.raw_value
            ]))
            self.evidence_id = "ev_" + hashlib.sha256(seed.encode("utf-8")).hexdigest()[:16]
        if self.confidence is None:
            self.confidence = evidence_score(self.source_tier, self.evidence_status, self.pit_status)
        d = asdict(self)
        d["parent_evidence_ids"] = list(self.parent_evidence_ids)
        return d


def evidence_score(source_tier: str, evidence_status: str, pit_status: str,
                   freshness_score: float = 85.0, cross_validation_score: float = 70.0,
                   methodology_score: float = 80.0) -> float:
    """Evidence confidence, 0-100. Investment score is intentionally separate."""
    tier = TIER_SCORE.get(str(source_tier).upper(), 25.0)
    status = STATUS_SCORE.get(str(evidence_status).upper(), 25.0)
    pit = PIT_SCORE.get(str(pit_status).upper(), 35.0)
    score = (0.28*tier + 0.24*status + 0.18*pit + 0.12*freshness_score
             + 0.10*cross_validation_score + 0.08*methodology_score)
    return round(max(0.0, min(100.0, score)), 1)


def aggregate_confidence(records: Iterable[dict], critical_metrics: Optional[set[str]] = None) -> dict:
    records = list(records)
    if not records:
        return {"score": 0.0, "level": "VERY_LOW", "gate": "DATA_INSUFFICIENT", "coverage": 0.0}
    critical_metrics = critical_metrics or set()
    scores, present_critical = [], set()
    blocking = []
    for r in records:
        s = float(r.get("confidence") or evidence_score(
            r.get("source_tier", "D"), r.get("evidence_status", "UNVERIFIED"), r.get("pit_status", "UNKNOWN")
        ))
        scores.append(s)
        m = r.get("metric")
        if m in critical_metrics and r.get("evidence_status") not in {"MISSING", "UNVERIFIED"}:
            present_critical.add(m)
        if m in critical_metrics and r.get("evidence_status") in {"MISSING", "UNVERIFIED"}:
            blocking.append(m)
    coverage = 1.0 if not critical_metrics else len(present_critical) / len(critical_metrics)
    score = sum(scores) / len(scores) * (0.75 + 0.25*coverage)
    score = round(score, 1)
    level = "HIGH" if score >= 85 else "MEDIUM_HIGH" if score >= 70 else "MEDIUM" if score >= 55 else "LOW" if score >= 40 else "VERY_LOW"
    gate = "PASS" if score >= 70 and coverage >= 0.8 and not blocking else "CONDITIONAL" if score >= 55 and coverage >= 0.6 else "DATA_INSUFFICIENT"
    return {"score": score, "level": level, "gate": gate, "coverage": round(coverage, 3), "blocking_metrics": sorted(set(blocking))}


def decision_evidence_gate(evidence_summary: dict, requested_action: str) -> dict:
    action = str(requested_action).upper()
    score = float(evidence_summary.get("score", 0))
    gate = evidence_summary.get("gate", "DATA_INSUFFICIENT")
    allowed = action
    reason = None
    if gate == "DATA_INSUFFICIENT" or score < 55:
        if action in {"STRONG_BUY", "BUY", "SELL"}:
            allowed = "WAIT"
            reason = "EVIDENCE_GATE"
    elif score < 70 and action == "STRONG_BUY":
        allowed = "BUY_CANDIDATE"
        reason = "EVIDENCE_CONFIDENCE_GATE"
    return {"requested_action": action, "allowed_action": allowed, "evidence_gate": gate, "reason": reason}


def main():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("input", help="JSON array of evidence records")
    p.add_argument("--critical", default="", help="comma-separated critical metrics")
    args = p.parse_args()
    with open(args.input, "r", encoding="utf-8") as f:
        rows = json.load(f)
    finalized = [EvidenceRecord(**{k:v for k,v in r.items() if k in EvidenceRecord.__dataclass_fields__}).finalize() for r in rows]
    print(json.dumps({"records": finalized, "summary": aggregate_confidence(finalized, set(filter(None,args.critical.split(','))))}, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
