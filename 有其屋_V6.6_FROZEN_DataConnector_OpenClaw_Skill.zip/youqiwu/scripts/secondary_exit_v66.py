#!/usr/bin/env python3
"""有其屋 V6.6 Primary-to-Secondary Exit diagnostics.
Produces explicit resale-supply estimates and risk flags rather than a new generic score.
"""
from __future__ import annotations
import argparse,json

def analyze(x):
    units=float(x.get("total_units",0)); investor=float(x.get("investor_ratio",0)); resale=float(x.get("expected_resale_rate",0)); window=float(x.get("exit_window_years",2) or 2)
    expected=units*investor*resale
    annual=expected/window if window>0 else None
    local=float(x.get("local_secondary_annual_transactions",0) or 0)
    share=None if local<=0 or annual is None else annual/local
    assumptions=[]
    for k in ("investor_ratio","expected_resale_rate"):
        if x.get(k+"_status","MODEL_ASSUMPTION") == "MODEL_ASSUMPTION": assumptions.append(k)
    flags=[]
    if share is not None and share>=0.30: flags.append("PROJECT_EXIT_SUPPLY_LARGE_VS_LOCAL_MARKET")
    elif share is not None and share>=0.15: flags.append("PROJECT_EXIT_SUPPLY_MATERIAL_VS_LOCAL_MARKET")
    if float(x.get("secondary_days_on_market",0) or 0)>=180: flags.append("SECONDARY_MARKET_SLOW")
    if float(x.get("secondary_listing_discount",0) or 0)>=0.10: flags.append("SECONDARY_DISCOUNT_HIGH")
    if x.get("completion_cluster_risk") is True: flags.append("COMPLETION_CLUSTER")
    risk="HIGH" if len(flags)>=3 else "MEDIUM" if flags else "LOW_OR_UNPROVEN"
    return {"expected_resale_units_in_window":round(expected,1),"expected_resale_units_per_year":None if annual is None else round(annual,1),"project_exit_supply_vs_local_transactions":None if share is None else round(share,4),"risk_flags":flags,"secondary_exit_risk":risk,"model_assumptions":assumptions,"note":"Assumption-driven fields must remain MODEL_ASSUMPTION unless independently evidenced."}

def main():
    p=argparse.ArgumentParser();p.add_argument("input");a=p.parse_args();print(json.dumps(analyze(json.load(open(a.input,encoding="utf-8"))),ensure_ascii=False,indent=2))
if __name__=="__main__":main()
