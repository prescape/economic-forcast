#!/usr/bin/env python3
"""有其屋 V6.6 Project Absorption Curve.
Input JSON: list of batches with permit_date, supply, and snapshots [{date,sold}].
Outputs 7/30/60/90/180d absorption when observable, plus recent 30/90d sales velocity.
"""
from __future__ import annotations
import argparse,json
from datetime import date

def d(s): return date.fromisoformat(s)

def sold_at_or_before(snaps, cutoff):
    eligible=[x for x in snaps if d(x["date"])<=cutoff]
    return max((float(x.get("sold",0)) for x in eligible), default=None)

def analyze(batch, as_of):
    permit=d(batch["permit_date"]); supply=float(batch["supply"]); snaps=sorted(batch.get("snapshots",[]), key=lambda x:x["date"])
    obs=d(as_of); out={"batch_id":batch.get("batch_id"),"permit_date":batch["permit_date"],"supply":supply,"age_days":(obs-permit).days}
    for days in (7,30,60,90,180):
        cutoff=min(obs, permit.fromordinal(permit.toordinal()+days))
        if obs < permit.fromordinal(permit.toordinal()+days):
            out[f"absorption_{days}d"] = None
        else:
            sold=sold_at_or_before(snaps, cutoff)
            out[f"absorption_{days}d"] = None if sold is None or supply<=0 else round(sold/supply,4)
    latest=sold_at_or_before(snaps,obs)
    out["sold_as_of"] = latest
    out["remaining_as_of"] = None if latest is None else max(0.0,supply-latest)
    return out

def portfolio_velocity(batches, as_of):
    obs=d(as_of)
    def total_sold(cut):
        t=0; seen=False
        for b in batches:
            if d(b["permit_date"])>cut: continue
            s=sold_at_or_before(b.get("snapshots",[]), cut)
            if s is not None: t+=s; seen=True
        return t if seen else None
    now=total_sold(obs); s30=total_sold(obs.fromordinal(obs.toordinal()-30)); s90=total_sold(obs.fromordinal(obs.toordinal()-90))
    v30=None if now is None or s30 is None else max(0,now-s30)/30
    v90=None if now is None or s90 is None else max(0,now-s90)/90
    accel=None if v30 is None or v90 is None else v30-v90
    state="UNKNOWN" if accel is None else "ACCELERATING" if accel>0.05 else "DECELERATING" if accel<-0.05 else "STABLE"
    return {"sold_per_day_30d":None if v30 is None else round(v30,3),"sold_per_day_90d":None if v90 is None else round(v90,3),"velocity_state":state}

def main():
    p=argparse.ArgumentParser();p.add_argument("input");p.add_argument("--as-of",required=True);a=p.parse_args()
    x=json.load(open(a.input,encoding="utf-8")); batches=x.get("batches",x)
    print(json.dumps({"as_of":a.as_of,"batches":[analyze(b,a.as_of) for b in batches],"project_velocity":portfolio_velocity(batches,a.as_of)},ensure_ascii=False,indent=2))
if __name__=="__main__":main()
