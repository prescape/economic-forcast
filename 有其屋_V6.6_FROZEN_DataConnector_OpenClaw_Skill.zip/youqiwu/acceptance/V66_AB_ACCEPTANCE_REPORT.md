# 有其屋 V6.6 冻结验收：V6.5 vs V6.6 同案例 A/B

## 结论

**总体：CONDITIONAL PASS。V6.6 功能冻结，不升级 V6.7。**

V6.6 没有推翻 V6.5 对“承宁府 vs 楚宝里”的研究级相对结论：在当前已有证据下仍为 **PREFER_B（楚宝里）**。但 V6.6 明显改变了“结论如何被执行”：库存被按年龄拆开，楚宝里的近期销售动能与项目库存不再和“板块稀缺”混成一个 Supply 分数；未来二手退出在缺乏关键参数时保持 INCONCLUSIVE；未核验一房一价、真实折扣、可售楼层和补贴叠加时，研究层的 STRONG_BUY 不允许直接转为执行层买入。

## A/B 关键变化

| 项目 | V6.5 | V6.6 验收结果 |
|---|---|---|
| Pairwise | PREFER_B | PREFER_B（研究层不变） |
| 楚宝里动作 | NEGOTIATE_BUY | NEGOTIATE_BUY / VERIFY_BEFORE_BUY |
| 106㎡≤265万 | STRONG_BUY | 研究层可为 STRONG_BUY，但执行层必须等 Verification Gate PASS |
| 供需 | 单一 Supply 分数 | 板块稀缺与项目库存分拆 |
| 销售速度 | 未显式进入 | 楚宝里 30d=45、90d=90 → 1.50 vs 1.00 套/日，明确为加速；承宁府数据不足则 UNKNOWN |
| 库存 | 总量为主 | Fresh/Normal/Aged/Stale 分层 |
| 二手退出 | 高流动性判断偏直接 | 数据不足时不生成伪精确退出评分 |
| 证据 | Source Tier | 要求 Evidence Graph lineage；缺链即降低置信度 |

## 5 模块验收

### 1. Evidence Graph — PARTIAL
模块行为正确，但当前 V6.5 报告并没有为 Fair Value、Liquidity、Supply、Pairwise 的每个派生数字提供完整 evidence_id → parent_evidence_ids。因此本案例不能给“全链路 PASS”。正确行为是降置信度，而不是补造证据。

### 2. Absorption Curve — PARTIAL
楚宝里来源直接给出近30天45套、近90天90套，因此可得到 1.50 套/日 vs 1.00 套/日，近期动能为 ACCELERATING。每批7/30/60/90/180天历史快照不足，承宁府也缺完全可比的30/90天套数，所以不应伪造曲线。

### 3. Inventory Vintage — PASS
以 2026-06-30 为统一观察点，能够把刚取证库存和长期库存分开。承宁府 6# 为约32天的新货，而2025年两批未售余量已超过250天；楚宝里既有6月刚取证 Fresh 库存，也有3月批次 Aged 库存和2025首批 Stale 库存。这比 V6.5 单一 Supply Score 更符合真实项目状态。

注意：来源中“分批供应-已售”相加与正文“当前库存145–216套”存在口径/时点差异，所以 V6.6 应保留边界而非强行合并成一个精确库存。

### 4. Secondary Exit — PASS_BY_DISCIPLINE
楚宝里 893–974户明显大于承宁府546户，足以形成“交付后二手竞争需要检查”的事实基础。但投资者比例、预计转售率、局部二手年成交容量等关键变量没有来源。V6.6 正确验收标准是输出 INCONCLUSIVE/MODEL_ASSUMPTION，而不是随意给一个85或55分。

### 5. Verification Gate — PASS
源报告明确要求买前核验当前可售房源/楼层、最新一房一价、案场折扣和补贴叠加。用 V6.6 gate 实测，楚宝里若研究层触发 STRONG_BUY，但上述字段仍 UNVERIFIED，则 allowed_action = NEGOTIATE_BUY。

## 是否需要 V6.7

**不需要。** 当前发现的不足主要是数据缺口，而不是 V6.6 模块逻辑失效。下一阶段应扩充官方网签快照、分批去化历史、真实库存、二手成交容量和案场实时核验，而不是继续加版本或新增泛化评分。
