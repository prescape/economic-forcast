# 有其屋 V6.4 Release Audit

- 基线：有其屋 V6.3
- 升级类型：新房市场情报增量升级，保持 V6.2 单盘 Gate 与 V6.3 Pairwise 兼容。
- 新增引擎：New-House Absorption / Primary-Secondary Divergence / Launch & Inventory Timing。
- 新增决策包装：`buy_hold_sell_v64.py`，只允许对新房 BUY 降级，不允许绕过底层 Gate 升级。
- 新增 Pairwise 扩展：`pairwise_comparison_v64.py`，新房相对排序增加去化、二手退出和 Timing，但底层 BUY/WAIT/REJECT 仍绑定。
- JSON 解析：PASS。
- Python 语法/编译：PASS。
- 去化边界测试：刚取证低去化不会直接判需求弱；成熟批次和新增供应冲击分别计算。
- 一二手分化测试：新房热 + 二手价格/流动性弱可触发 HIGH secondary exit risk。
- Timing 测试：刚取证、选择面大、有效折扣可识别谈判窗口，但不会自动生成 BUY。
