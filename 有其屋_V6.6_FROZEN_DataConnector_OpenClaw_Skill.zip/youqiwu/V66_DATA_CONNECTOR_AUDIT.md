# 有其屋 V6.6-FROZEN Data Connector Audit

- Engine version: V6.6
- Functional status: FROZEN
- Connector: 1.0
- Investment logic changed: NO
- New generic scores: NO
- External PIT reader: PASS
- Evidence Registry binding: PASS
- Freshness/Data Gate: PASS
- Raw data direct-decision fallback: DISALLOWED
- Missing data behavior: DATA_INSUFFICIENT / confidence downgrade
