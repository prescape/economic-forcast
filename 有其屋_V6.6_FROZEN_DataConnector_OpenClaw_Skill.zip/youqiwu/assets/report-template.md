# 房地产投资决策报告 V6.6

## 1. Executive Decision
- Action: BUY / HOLD / SELL / WAIT / REJECT
- Confidence:
- One-line thesis:

## 2. Price Discipline
- Current price:
- Intrinsic value low/mid/high:
- Margin of safety:
- Strong-buy price:
- Buy price:
- Fair price:
- Do-not-chase price:

## 3. Market Regime
宏观、政策、城市周期、板块状态。

## 4. Asset Quality
项目、房源、通勤、产品、开发商/物业、硬伤。

## 5. Supply & Demand
库存、去化、二手挂牌、未来供给、需求基础。

## 6. Valuation
可比成交、租金资本化、历史位置、替代/重置成本与融合估值。

## 7. Returns
Bear/Base/Bull；3Y/5Y IRR；机会成本；现金流压力。

## 8. Liquidity
流动性评分、成交周期、议价、强制出售风险。

## 9. Household / Portfolio Fit
杠杆、现金储备、集中度、自住价值。

## 10. Risk Override
是否触发一票否决及证据。

## 11. Buy Triggers
价格/成交量/政策/供需等可验证触发条件。

## 12. Sell Triggers
高估、基本面、供给、流动性、机会成本、组合再平衡。

## 13. Data Confidence
缺失项、来源等级、观察日期、模型分歧。

## 14. Next Actions
下一步核实、议价、监控或退出动作。


## Pairwise Comparison（V6.3，仅双盘任务）
- A 独立决策 / Confidence：
- B 独立决策 / Confidence：
- Risk-adjusted Pair Score A / B：
- 分差：
- 决胜因素：
- 反对因素：
- 最终：PREFER_A / PREFER_B / BUY_NEITHER / NO_MATERIAL_ADVANTAGE
- 价格反转条件：

### Replacement Comparison（如适用）
- 现有物业 A Forward IRR：
- 目标物业 B Forward IRR：
- 税费/中介/装修/搬迁/融资切换成本：
- 切换后增量 IRR：
- 最终：HOLD_A / SELL_A_BUY_B

## New House Market Intelligence（V6.4，如适用）
- 取证批次与供应/已售：
- 累计去化率 / 90天成熟批次去化：
- 30/90天销售速度：
- 可售库存 / Months of Inventory：
- 新增供应冲击：
- 新房热度 vs 周边二手退出分：
- Primary/Secondary Divergence：
- Secondary Exit Risk：
- Launch Timing：PRIME_NEGOTIATION_WINDOW / SELECTIVE_BUY_WINDOW / NEUTRAL_WAIT_FOR_PRICE / POOR_ENTRY_WINDOW
- 当前议价/选货窗口：

## Evidence Trace（V6.5）
- Evidence Confidence：__/100（HIGH / MEDIUM_HIGH / MEDIUM / LOW / VERY_LOW）
- Evidence Gate：PASS / CONDITIONAL / DATA_INSUFFICIENT
- 关键证据：列出 Evidence ID、指标、观察日、Source Tier、验证/PIT 状态与来源。
- 模型假设：单独列出所有 `MODEL_ASSUMPTION`，尤其是未来升值、出租率、退出折价与情景参数。
- 未核验项：列出 `UNVERIFIED/MISSING` 及其可能影响。
- Fair Value Trace：列出 Comparable/租金/替代成本父证据、修正过程与权重。


## V6.6 Evidence & Market Intelligence
### Evidence Graph
- Graph Gate：PASS / FAIL
- Fair Value lineage：raw evidence → transforms → Fair Value
- Decision lineage：critical evidence → gates → final action
- MODEL_ASSUMPTION nodes：
- Broken/missing parent links：

### Project Absorption Curve
- 每批取证 7/30/60/90/180d 去化：
- 30d sales velocity：
- 90d sales velocity：
- Velocity state：ACCELERATING / STABLE / DECELERATING

### Inventory Vintage
- Fresh 0-30d：
- Normal 31-90d：
- Aged 91-180d：
- Stale 180d+：
- 项目库存状态：
- 板块供应稀缺性（单独）：

### Primary → Secondary Exit
- Expected resale supply：
- Local secondary absorption capacity：
- Completion cluster：
- Exit risk flags：
- Assumptions / sensitivity：

### Pre-Transaction Verification Gate
- Gate：PASS / VERIFY_BEFORE_BUY / BLOCK_BUY
- Current available unit：
- One-unit-one-price / filing：
- Actual discount：
- Subsidy stackability：
- Floor / orientation：
- Delivery milestone：
- Missing/unverified items：
