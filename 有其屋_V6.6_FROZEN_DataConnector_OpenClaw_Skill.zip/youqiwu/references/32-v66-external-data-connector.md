# 32 — V6.6 External Data Connector Binding

## 状态
这是 **V6.6-FROZEN 的部署/数据接入层**，不是 V6.7，也不改变任何投资逻辑、阈值、Pairwise 权重或五大冻结模块。

## 默认数据目录
`~/.openclaw/workspace/data/youqiwu/`

可用环境变量覆盖：
`YOUQI_WU_DATA_ROOT=/path/to/youqiwu`

兼容 Data Pipeline V1.x 两种部署形式：
- `<root>/data/pit`, `<root>/data/evidence`, `<root>/data/features`
- `<root>/pit`, `<root>/evidence`, `<root>/features`

## 决策读取顺序
1. 只把标准化 `pit/` 数据作为主要模型输入。
2. `evidence/evidence_registry.jsonl` 用于 Evidence Graph 和证据门。
3. `features/` 可保存 Data Pipeline 预计算特征，但不得覆盖 V6.6 冻结算法规则。
4. `raw/` 默认不得直接进入 BUY/HOLD/SELL；只用于审计、重新解析或人工核验。
5. 数据缺失时输出 DATA_INSUFFICIENT/降低 Confidence，不允许 fallback 到猜测值。

## 新房关键输入
- permits
- newhouse_sales
- inventory
- prices

四类数据必须同时具备足够新鲜度，Data Gate 才能 PASS。Gate 不通过时，V6.6 仍可输出研究结论，但不能绕过 Verification/Evidence 纪律直接执行高置信度 BUY。

## 命令
```bash
python3 scripts/data_connector_v66.py --project chengningfu
python3 scripts/data_connector_v66.py --project chubaoli
python3 scripts/prepare_v66_inputs.py --project chubaoli
```
