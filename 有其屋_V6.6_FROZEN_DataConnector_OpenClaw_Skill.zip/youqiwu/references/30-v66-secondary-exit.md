# V6.6 Primary → Secondary Exit

新房热销不代表交付后二手好卖。V6.6 单独评估未来退出竞争：项目总户数、交付集中度、可能投资/置换比例、预期转售比例、周边二手成交容量、成交周期、挂牌折价。

涉及 investor_ratio、expected_resale_rate 等无法直接观测字段时必须标 `MODEL_ASSUMPTION`，输出区间/敏感性，不允许伪装为事实。该模块输出风险标记与退出供给估计，不新增一个泛化“总分”。

工具：`scripts/secondary_exit_v66.py`。
