# V6.3 Pairwise Comparison Engine

## 定位
Pairwise Comparison Engine 不替代单盘 V6.2 Quant Decision Engine。必须先分别完成 A、B 两个楼盘/房源的独立分析，再进行相对价值比较，防止“两个都差但硬选一个”。

## 两种模式
### 1. Purchase Comparison
用于两个候选楼盘/房源之间选择。允许四类结果：`PREFER_A`、`PREFER_B`、`NO_MATERIAL_ADVANTAGE`、`BUY_NEITHER`。

### 2. Replacement Comparison
用于“卖掉现有房 A，换成 B 是否划算”。必须纳入卖出税费、中介、买入税费、装修/搬家、贷款重置及持有机会成本。允许 `SELL_A_BUY_B` 或 `HOLD_A`，不得仅因 B 综合分更高就建议换房。

## 前置约束
1. A/B 必须使用相同观察日或明确做时间对齐。
2. 估值口径、持有期、贷款假设、IRR 现金流口径一致。
3. 数据置信度分别披露；低置信度不能靠高分胜出。
4. 任一标的触发 Risk Override 时，相对评分不能覆盖硬风险。
5. 单盘底层动作为 WAIT/REJECT/DATA_INSUFFICIENT 时，不因相对排名而升级为 BUY。

## 相对比较维度（默认）
- Base IRR 23%
- Bear IRR 12%
- Margin of Safety 18%
- Liquidity 13%
- Supply Pressure 10%（反向）
- Asset Quality 9%
- City/Submarket 8%
- Trend 7%

权重只是相对排序层，不得覆盖独立 BUY/HOLD/SELL Gate。用户目标不同可调整，但必须披露。

## 决策阈值
- 默认相对评分差 `<5` 分：`NO_MATERIAL_ADVANTAGE`，视为没有实质优势。
- 两者都没有通过单盘买入条件：`BUY_NEITHER`。
- Replacement 模式默认要求：B 可买 + 换房后增量 IRR 至少 1.5pct + 相对评分没有显著落后，才允许 `SELL_A_BUY_B`。
- 换房交易摩擦必须折算进增量收益；缺少 forward IRR 时默认 `HOLD_A`，不做激进换房建议。

## 必须输出
1. A/B 独立动作与 Confidence
2. A/B Fair Value、MOS、Strong Buy/Buy Price
3. A/B Base/Bear/Bull IRR
4. Liquidity 与 Supply Pressure
5. Risk Override
6. Pairwise Risk-adjusted Score 与差值
7. 决胜因素 / 反对因素
8. 最终动作：PREFER_A / PREFER_B / BUY_NEITHER / NO_MATERIAL_ADVANTAGE
9. 若为换房：HOLD_A / SELL_A_BUY_B + 增量 IRR + 切换成本
10. 价格条件：A/B 各自在什么价格下会改变排序

## 价格敏感性
相对排名必须附带价格条件。推荐至少给出：
- 当前报价下谁优先
- A 降至其 Buy Price 时是否反超 B
- B 降至其 Buy Price 时是否反超 A
- 两者均进入 Strong Buy 时的风险调整排序

Pairwise Engine 的目标不是“选赢家”，而是判断：**哪个资产在当前价格下提供更好的风险调整后回报；若都不合格，就一个都不买。**
