# V6.5 Evidence Trace Engine

## 目标

V6.5 将数据研究能力与投资决策引擎之间增加独立 Evidence Trace Layer。任何可能改变 Fair Value、MOS、IRR、BUY/HOLD/SELL、Pairwise 排名或 Risk Override 的关键输入，都必须能够追溯到来源、观察日、采集日、口径、转换过程与置信度。

## Source Tier

- `S`：官方原始数据。住建/房管/统计/自然资源/央行/政府开放数据、官方备案与网签。
- `A`：专业房地产数据库或研究机构。
- `B`：交易/挂牌/租赁平台。
- `C`：可信媒体、项目报道、研究文章，用于事件与辅助验证。
- `D`：销售口径、用户输入、论坛/社媒等未经独立验证信息。

Source Tier 表示来源等级，不等同于数据正确性。即使 S 级也必须记录统计口径、发布日期和适用范围。

## Evidence Status

- `VERIFIED`：来源可追溯，字段口径清楚，观察日满足任务要求；关键数据原则上至少一条 S/A 证据或两条相互独立证据。
- `CORROBORATED`：存在两条以上独立来源相互支持，但未达到最高核验标准。
- `RECONSTRUCTED`：由后续公开页面恢复历史状态，可用于研究型分析，不得冒充严格 PIT。
- `UNVERIFIED`：只有单一营销/销售/用户输入或缺少原始证据。
- `MODEL_ASSUMPTION`：模型参数或情景假设，不属于观测事实。
- `MISSING`：关键字段无可靠证据。

## 最小 Evidence Record

每条关键证据至少包含：

`evidence_id, metric, raw_value, normalized_value, unit, geography, project, phase, observation_date, publication_date, retrieved_at, source_name, source_url_or_ref, source_tier, evidence_status, pit_status, methodology, transformation, confidence, notes`

`pit_status`：`PIT_VERIFIED / RECONSTRUCTED / CURRENT_ONLY / NOT_APPLICABLE / UNKNOWN`。

## 证据链

派生指标必须记录父证据：

`raw evidence -> normalization -> adjustment -> derived metric -> model output -> decision`

例如 Fair Value 不允许只有最终值，应保存：Comparable 成交 Evidence IDs、时间/楼层/朝向等调整、各可比权重、估值聚合方式以及结果区间。

## 决策闸门

1. 改变 BUY/SELL 的关键字段如果存在 `MISSING` 或多数为 `UNVERIFIED`，不得输出 HIGH confidence。
2. Fair Value 的关键可比证据若无法追溯，输出估值区间并标记 LOW/MEDIUM，不给伪精确单点。
3. `MODEL_ASSUMPTION` 必须与事实分开；IRR 中的未来升值率、出租率、退出折价等必须显式披露。
4. 严格历史回测只接受 `PIT_VERIFIED`；`RECONSTRUCTED` 只能进入 Research Gate。
5. Pairwise 比较要求 A/B 使用同一观察日和相近证据质量；证据质量差距过大时输出 `DATA_QUALITY_MISMATCH` 或降低比较置信度。
6. 风险信息即使来自低 Tier，只要可能构成产权/安全/交付硬风险，也必须进入待核验 Risk Override，不得忽略。

## Evidence Confidence

建议基于来源等级、时效性、PIT 状态、交叉验证、覆盖率与口径一致性综合评分。证据置信度和投资评分必须分开。

建议解释：
- 85–100：HIGH，可支持正式决策。
- 70–84：MEDIUM-HIGH，可决策但披露主要缺口。
- 55–69：MEDIUM，仅条件式决策。
- 40–54：LOW，原则上 WAIT / DATA_INSUFFICIENT。
- <40：VERY_LOW，不输出精确估值或强动作。

## 商业化原则

核心规则：**No Evidence, No Precision; No Trace, No High-Confidence Decision.**
