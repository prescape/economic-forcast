# V6.4 Launch & Inventory Timing Engine

## 目的
回答同一个楼盘“什么时候买更有谈判优势”。它不判断资产本身是否值得买，只判断当前推货/库存阶段是否提供选楼层、折扣和议价窗口。

## 核心变量
- 距最近取证/开盘天数
- 最新批次供应与已售
- 当前可售库存
- 当前月销速度
- 一房一价后的有效折扣
- 楼层/朝向/户型可选度
- 未来180天待推供应

## 输出
- `PRIME_NEGOTIATION_WINDOW`
- `SELECTIVE_BUY_WINDOW`
- `NEUTRAL_WAIT_FOR_PRICE`
- `POOR_ENTRY_WINDOW`

## 纪律
“刚取证、货多、可选多”可以提升谈判窗口，但绝不能覆盖 Fair Value、安全边际、IRR、Risk Override 或 V6.2 Trend Confirmation。好时机不等于好价格。

运行：`scripts/launch_inventory_timing_v64.py`。
