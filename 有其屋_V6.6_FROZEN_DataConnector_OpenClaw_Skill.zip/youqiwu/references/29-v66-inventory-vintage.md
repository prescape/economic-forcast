# V6.6 Inventory Vintage

项目库存按取证年龄拆分，而不是只看剩余套数：
- FRESH_0_30D：刚取证，不应直接视为库存风险；
- NORMAL_31_90D：正常销售期；
- AGED_91_180D：需要观察折扣与去化；
- STALE_180D_PLUS：长期未售，构成真实库存压力。

因此“板块供应稀缺”和“项目自身库存压力”必须是两个不同字段。项目库存压力来自 Vintage 与销售速度，板块稀缺来自区域新增供应/土地/竞品。

工具：`scripts/inventory_vintage_v66.py`。
