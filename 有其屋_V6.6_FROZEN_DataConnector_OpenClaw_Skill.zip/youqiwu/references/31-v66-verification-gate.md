# V6.6 Pre-Transaction Verification Gate

模型研究结论与真正下单之间增加最后一道交易核验门。对于新房至少核验：目标房源是否仍可售、一房一价/备案表、真实折扣、补贴能否叠加、楼层、朝向、交付节点；必要时补充车位、装修包、付款条件和绑定费用。

规则：缺少关键实时字段时 `BLOCK_BUY`；字段存在但未核实时 `VERIFY_BEFORE_BUY`；全部关键字段已验证才 `PASS`。该门只能降级 BUY/STRONG_BUY，不得反向升级投资结论。

工具：`scripts/verification_gate_v66.py`。
