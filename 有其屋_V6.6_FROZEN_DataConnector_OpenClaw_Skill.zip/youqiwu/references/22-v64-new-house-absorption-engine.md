# V6.4 New-House Absorption Engine

## 目的
把新房项目的“去化”从描述性指标升级成结构化决策变量。按每次预售/取证批次记录 `permit_date / supply_units / sold_units`，禁止只看累计去化率。

## 核心指标
- 批次去化率：`sold_units / supply_units`
- 累计去化率：累计已售 / 累计取证供应
- Mature 90d Absorption：仅看取证满90天批次，减少刚取证0成交造成的误判
- 30/90天批次销售速度
- 当前可售库存与 `Months of Inventory = available_units / monthly_sales_units`
- 新增供应冲击：最近新增供应 / 加推前可售库存

## 解释纪律
1. 刚取证批次0%去化不等于需求弱，必须结合取证天数。
2. 累计去化率会被大规模加推摊薄，因此必须拆批次。
3. 高去化既可能说明产品强，也可能意味着好楼层已消耗、议价权下降。
4. 对投资者而言，最终还要与周边二手退出流动性联动。

运行：`scripts/new_house_absorption_v64.py`。
