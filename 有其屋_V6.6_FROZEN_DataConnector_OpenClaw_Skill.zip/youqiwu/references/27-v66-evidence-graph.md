# V6.6 Evidence Graph

V6.5 解决“字段有来源”，V6.6 继续解决“结论能沿计算链回到原始事实”。Evidence Graph 是有向证据血缘图，不是新的投资评分。

每个派生指标必须记录父 `evidence_id`。例如：官方网签批次 → 30/90d 销售速度 → 项目库存状态 → Supply/Timing 判断 → BUY/HOLD/SELL。Fair Value、MOS、IRR、Liquidity、Pairwise 与最终动作必须至少存在一条可回溯原始证据路径。

硬规则：父证据缺失、循环引用或关键输出完全无父证据时，Graph Gate 不得 PASS；`MODEL_ASSUMPTION` 必须在路径上显式展示；`UNVERIFIED/MISSING` 证据不能被派生计算洗成“已验证”。

工具：`scripts/evidence_graph_v66.py`。
