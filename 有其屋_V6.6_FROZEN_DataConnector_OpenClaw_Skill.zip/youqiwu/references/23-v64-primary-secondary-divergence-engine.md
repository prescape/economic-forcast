# V6.4 Primary / Secondary Market Divergence Engine

## 目的
识别“新房热、二手冷”的结构性分化。新房成交被政策、产品迭代、集中推盘激活，不代表交付后二手市场能以同样价格和速度接盘。

## 默认输入
- 新房价格/成交量同比
- 周边二手成交价趋势与成交量
- 二手挂牌价到成交价折让
- 成交周期
- 看房人数变化

## 核心输出
- `new_home_heat_score`
- `secondary_exit_score`
- `divergence_gap`
- `market_state`
- `secondary_exit_risk`

## 重要规则
若出现 `NEW_HOT_SECONDARY_WEAK`，应提高未来退出折价与流动性风险，不能仅凭新房热销给 BUY。对期房尤其要把“今天的新房热度”和“交付后的二手退出市场”分开建模。

运行：`scripts/primary_secondary_divergence_v64.py`。
