# 有其屋 V6.6 Release Audit

## Scope
V6.6 只新增五个结构性市场情报/审计模块，不新增泛化投资评分：
1. Evidence Graph
2. Project Absorption Curve
3. Inventory Vintage
4. Primary → Secondary Exit
5. Pre-Transaction Verification Gate

## Architecture rules
- Submarket supply scarcity and project inventory pressure are separate concepts.
- Fresh inventory is not treated as stale inventory.
- Primary-market heat cannot prove secondary-market exit liquidity.
- MODEL_ASSUMPTION remains visible through Evidence Graph lineage.
- Verification Gate can only downgrade executable BUY, never upgrade WAIT/REJECT.

## Backward compatibility
V6.2 Quant Decision, V6.3 Pairwise, V6.4 New House Market Intelligence and V6.5 Evidence Trace are retained. V6.6 scripts are additive and use separate filenames.
