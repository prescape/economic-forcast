# Dalio China Asset Allocation V7.5.1 Complete / Freeze Candidate

---
name: dalio-china-asset-allocation-v7-5
description: PIT-safe China asset-allocation research skill using a frozen V7.4 alpha layer and V7.5 macro/risk regime engine, with semi-monthly walk-forward and robustness freeze gate.
version: 7.5
---

# Dalio China Asset Allocation V7.5

## Purpose
Run the V7.5 China asset-allocation research workflow with PIT-safe data, semi-monthly walk-forward evaluation, and a robustness freeze gate.

## V7.5 design
- Cross-sectional alpha frozen from V7.4: 55% valuation + 45% fund flow.
- Growth: PMI level + 3-month direction; GDP is slow confirmation.
- Inflation: CPI/PPI 3-month direction.
- Credit: M2 3-month acceleration.
- Policy: LPR/RRR easing signal with corrected RRR sign.
- Fast brake: CSI300 below 120-day MA and negative 20-day return => immediate Risk-Off.
- Hysteresis: downside immediate; upside requires two consecutive semi-monthly confirmations.
- Risk budgets: Risk-On 80%, Neutral 55%, Risk-Off 30%.
- Default one-way transaction cost: 10 bps.

## Standard workflow
1. Install dependencies: `pip install -r requirements.txt`
2. Refresh PIT data: `python scripts/fetch_all_pit.py`
3. Run V7.5 backtest: `python run_backtest.py`
4. Run freeze gate: `python run_robustness.py`
5. Freeze only after robustness result is PASS.

## Safety / research constraints
- Do not silently impute missing PIT features.
- Never use rows whose `available_date` is later than the decision as-of date.
- Do not optimize scenario parameters after viewing robustness outcomes.
- Treat demo/proxy data as lower-quality and report it explicitly.
