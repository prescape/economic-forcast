# Dalio China Asset Allocation V7.5.1 — OpenClaw package

This is the rebuilt V7.5 package assembled from the previously generated V7.5 engine and validation artifacts.

## Included
- `engine/walk_forward_v75.py` — V7.5 regime-engine walk-forward.
- `tests/robustness_test_v75.py` — freeze-gate stress test; outputs PASS / CONDITIONAL PASS / FAIL.
- `scripts/fetch_*_pit.py` — macro, market, valuation, flow, policy, earnings and unified PIT fetchers.
- `scripts/fetch_missing_history_v7_3.py` — historical gap backfill utility.
- `scripts/leakage_audit.py` — PIT date-order audit.
- `data/reference/V7.3_factor_panel_completed.csv` — completed factor panel used by V7.4/V7.5.
- `outputs/v74_output/V7.4_walk_forward_132_nodes_results.csv` — V7.4 comparison baseline.
- `outputs/v75_output/V7.5_backtest_summary.json` — previously frozen V7.5 summary used for reproducibility check.

## Important data note
The original full `unified_pit.csv` master archive was not available as a retrievable standalone file when this package was rebuilt. It is intentionally **not fabricated**. Generate it in your OpenClaw environment by running:

```bash
python scripts/fetch_all_pit.py
```

The fetcher writes `data/pit/unified_pit.csv`.

## Install / run
Windows:
```bat
install.bat
python scripts\fetch_all_pit.py
python run_backtest.py
python run_robustness.py
```

Linux/macOS/OpenClaw container:
```bash
bash install.sh
python scripts/fetch_all_pit.py
python run_backtest.py
python run_robustness.py
```

## Freeze rule
Do not replace V7.4 until `run_robustness.py` produces PASS. A CONDITIONAL PASS remains a candidate version; FAIL must not be frozen.
