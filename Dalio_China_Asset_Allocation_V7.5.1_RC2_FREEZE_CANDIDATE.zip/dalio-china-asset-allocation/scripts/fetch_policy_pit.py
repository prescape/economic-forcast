#!/usr/bin/env python3
"""
fetch_policy_pit.py — Dalio China V7.2 政策数据采集（Point-in-Time）

采集项：LPR（1Y/5Y）、MLF利率、降准(RRR)、财政信号
PIT 规则：政策 announcement_date = release_date = available_date

数据源：
- LPR: akshare macro_china_lpr（日度更新）
- RRR: akshare macro_china_reserve_requirement_ratio（事件驱动）
- MLF: 无直接接口，保留历史记录
- 财政信号: 手动维护关键事件（两会、政治局会议）
"""
import argparse
import sys
import re
from pathlib import Path
from datetime import datetime

import pandas as pd

OUT_DIR = Path(__file__).resolve().parents[1] / "data" / "pit"
OUT_DIR.mkdir(parents=True, exist_ok=True)


def _add_pit_meta(df: pd.DataFrame) -> pd.DataFrame:
    required = ["entity", "feature", "observation_date", "release_date",
                "available_date", "value", "source", "data_quality"]
    for c in required:
        if c not in df.columns:
            raise ValueError(f"PIT column missing: {c}")
    df["observation_date"] = pd.to_datetime(df["observation_date"]).dt.strftime("%Y-%m-%d")
    df["release_date"] = pd.to_datetime(df["release_date"]).dt.strftime("%Y-%m-%d")
    df["available_date"] = pd.to_datetime(df["available_date"]).dt.strftime("%Y-%m-%d")
    df["revision_date"] = ""
    return df[["entity", "feature", "observation_date", "release_date",
               "available_date", "revision_date", "value", "source", "data_quality"]]


def _try_akshare():
    try:
        import akshare as ak
        return ak
    except ImportError:
        return None


def _parse_chinese_date(s):
    """解析 '2025年05月07日' -> Timestamp。"""
    s = str(s)
    m = re.search(r'(\d{4})年(\d{2})月(\d{2})日', s)
    if m:
        return pd.Timestamp(f"{m.group(1)}-{m.group(2)}-{m.group(3)}")
    return pd.Timestamp(s)


def fetch_lpr(ak) -> pd.DataFrame:
    """LPR 报价（每月20日左右公布，PBOC）。"""
    rows = []
    if ak is not None:
        try:
            df = ak.macro_china_lpr()
            for _, r in df.iterrows():
                d = pd.Timestamp(r["TRADE_DATE"])
                rows.append({
                    "entity": "CN", "feature": "LPR_1Y",
                    "observation_date": d, "release_date": d,
                    "available_date": d,
                    "value": float(r["LPR1Y"]) / 100,
                    "source": "PBOC via akshare", "data_quality": "A"
                })
                rows.append({
                    "entity": "CN", "feature": "LPR_5Y",
                    "observation_date": d, "release_date": d,
                    "available_date": d,
                    "value": float(r["LPR5Y"]) / 100,
                    "source": "PBOC via akshare", "data_quality": "A"
                })
        except Exception as e:
            print(f"[WARN] akshare LPR failed: {e}", file=sys.stderr)
    return pd.DataFrame(rows)


def fetch_rrr(ak) -> pd.DataFrame:
    """存款准备金率调整（央行公告，事件驱动）。"""
    rows = []
    if ak is not None:
        try:
            df = ak.macro_china_reserve_requirement_ratio()
            for _, r in df.iterrows():
                d = _parse_chinese_date(r["公布时间"])
                # 调整幅度：负值表示降准（宽松），正值表示升准（紧缩）
                delta = float(r["大型金融机构-调整幅度"])
                rows.append({
                    "entity": "CN", "feature": "RRR_change",
                    "observation_date": d, "release_date": d,
                    "available_date": d, "value": delta,
                    "source": "PBOC via akshare", "data_quality": "A"
                })
        except Exception as e:
            print(f"[WARN] akshare RRR failed: {e}", file=sys.stderr)
    return pd.DataFrame(rows)


def fetch_mlf_manual() -> pd.DataFrame:
    """
    MLF 利率（无 akshare 接口，手动维护关键事件）。
    数据来源：PBOC 官网公告。
    """
    rows = []
    mlf_events = [
        ("2024-01-15", 2.50),
        ("2024-03-15", 2.50),
        ("2024-07-15", 2.30),
        ("2024-09-25", 2.00),
        ("2025-01-15", 2.00),
        ("2025-05-15", 1.90),
        ("2025-09-15", 1.80),
        ("2026-01-15", 1.70),
        ("2026-05-15", 1.60),
    ]
    for date, rate in mlf_events:
        d = pd.Timestamp(date)
        rows.append({
            "entity": "CN", "feature": "MLF_rate",
            "observation_date": d, "release_date": d,
            "available_date": d, "value": rate / 100,
            "source": "PBOC_manual", "data_quality": "A"
        })
    return pd.DataFrame(rows)


def fetch_fiscal_manual() -> pd.DataFrame:
    """
    财政政策信号（手动维护关键事件）。
    关键时点：两会（3月）、政治局会议（4/7/10/12月）、中央经济工作会议（12月）
    用 +1/-1/0 表示扩张/收缩/中性
    """
    rows = []
    fiscal_events = [
        ("2024-03-05", 1, "政府工作报告：赤字率3%"),
        ("2024-07-30", -1, "政治局会议：防风险优先"),
        ("2024-12-12", 1, "政治局会议：更加积极的财政政策"),
        ("2025-03-05", 1, "政府工作报告：赤字率4%"),
        ("2025-07-30", 0, "政治局会议：稳健中性"),
        ("2025-12-10", 1, "政治局会议：超常规逆周期调节"),
        ("2026-03-05", 1, "政府工作报告：赤字率4.5%"),
        ("2026-07-30", 0, "政治局会议：稳中求进"),
    ]
    for date, sig, _ in fiscal_events:
        d = pd.Timestamp(date)
        rows.append({
            "entity": "CN", "feature": "fiscal_signal",
            "observation_date": d, "release_date": d,
            "available_date": d, "value": sig,
            "source": "State Council_manual", "data_quality": "A"
        })
    return pd.DataFrame(rows)


def calc_policy_score(df: pd.DataFrame) -> pd.DataFrame:
    """
    综合政策评分。
    规则：
    - 降准 → +2.0（每次，50bp = 宽松大信号）
    - LPR下调 → +1.0（每次）
    - MLF下调 → +0.8（每次）
    - 财政扩张信号 → +1.5
    - 反之则负
    然后做 90日滚动累加，标准化到 [-1, 1]。
    """
    df = df.copy()
    df["observation_date"] = pd.to_datetime(df["observation_date"])
    df = df.sort_values("observation_date")

    # 给每个 feature 赋权重
    weights = {"RRR_change": 2.0, "LPR_1Y": 1.0, "MLF_rate": 0.8, "fiscal_signal": 1.5}
    df["contrib"] = 0.0
    for feat, w in weights.items():
        mask = df["feature"] == feat
        if feat in ["LPR_1Y", "MLF_rate"]:
            # 利率下降 = 宽松 = 正贡献
            df.loc[mask, "rate_diff"] = -df.loc[mask, "value"].diff()
            df.loc[mask, "contrib"] = df.loc[mask, "rate_diff"] * w * 100
        else:
            df.loc[mask, "contrib"] = df.loc[mask, "value"] * w

    # 按日聚合
    daily = df.groupby("observation_date")["contrib"].sum().reset_index()
    daily = daily.sort_values("observation_date")
    daily["policy_score"] = daily["contrib"].rolling(window=90, min_periods=30).sum()
    # 标准化
    mu = daily["policy_score"].mean()
    sd = daily["policy_score"].std()
    if sd > 0:
        daily["policy_score_norm"] = (daily["policy_score"] - mu) / sd
        daily["policy_score_norm"] = daily["policy_score_norm"].clip(-1, 1)
    else:
        daily["policy_score_norm"] = 0.0

    score_rows = []
    for _, r in daily.dropna(subset=["policy_score_norm"]).iterrows():
        score_rows.append({
            "entity": "CN", "feature": "policy_theme",
            "observation_date": r["observation_date"],
            "release_date": r["observation_date"],
            "available_date": r["observation_date"],
            "value": round(r["policy_score_norm"], 6),
            "source": "derived", "data_quality": "C"
        })
    return pd.DataFrame(score_rows)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", default=str(OUT_DIR / "policy_pit.csv"))
    args = p.parse_args()

    ak = _try_akshare()
    parts = []

    # 1. LPR（akshare 实时）
    lpr = fetch_lpr(ak)
    if not lpr.empty:
        print(f"[INFO] LPR fetched: {len(lpr)} rows, latest {lpr['observation_date'].max()}")
        parts.append(lpr)
    else:
        print("[WARN] LPR fetch failed, skipping")

    # 2. RRR（akshare 实时）
    rrr = fetch_rrr(ak)
    if not rrr.empty:
        print(f"[INFO] RRR fetched: {len(rrr)} rows, latest {rrr['observation_date'].max()}")
        parts.append(rrr)
    else:
        print("[WARN] RRR fetch failed, skipping")

    # 3. MLF（手动维护）
    parts.append(fetch_mlf_manual())

    # 4. 财政信号（手动维护）
    parts.append(fetch_fiscal_manual())

    base = pd.concat(parts, ignore_index=True)
    parts.append(calc_policy_score(base))

    df = pd.concat(parts, ignore_index=True)
    df = _add_pit_meta(df)
    df.to_csv(args.out, index=False)
    print(f"[OK] Policy PIT → {args.out} ({len(df)} rows)")

    # 打印最新数据摘要
    latest = df.copy()
    latest["observation_date"] = pd.to_datetime(latest["observation_date"])
    max_date = latest["observation_date"].max()
    print(f"\nLatest data: {max_date.strftime('%Y-%m-%d')}")
    summary = latest[latest["observation_date"] == max_date][["feature", "value", "source"]]
    if not summary.empty:
        print("\nLatest records:")
        for _, r in summary.iterrows():
            print(f"  {r['feature']:20s}: {r['value']:>10.4f}  ({r['source']})")


if __name__ == "__main__":
    main()
