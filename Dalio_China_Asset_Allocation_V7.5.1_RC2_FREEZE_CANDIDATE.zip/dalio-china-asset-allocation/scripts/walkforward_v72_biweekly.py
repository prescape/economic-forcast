#!/usr/bin/env python3
"""
walkforward_v72_weekly.py — V7.2-FROZEN 半月频/周频 Walk-Forward 回测

- 原版本：每月末执行一次（月度调仓）
- 本版本：每月15日 + 月末执行（半月频调仓）
- 数据已支持：market/valuation/flow 到日频，宏观到月频

解决痛点：
- 之前7月预测偏差大，因为6月底→7月底跨了一个月，风格切换未被捕捉
- 半月频可在月中及时响应风格切换
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
import numpy as np
import yaml
from datetime import datetime

PIT_DIR = Path(__file__).resolve().parents[1] / "data" / "pit"
CONFIG_PATH = Path(__file__).resolve().parents[1] / ".." / "dalio-china-v7-2-frozen" / "config" / "freeze.yaml"
OUTPUT_PATH = Path(__file__).resolve().parents[1] / "data" / "walkforward_v72_biweekly.csv"

INDEX_MAP = {
    "000300": "沪深300", "000852": "中证1000", "399006": "创业板指",
    "000688": "科创50", "000016": "上证50", "930740": "300红利低波",
}
ENTITY_INT_MAP = {300: "000300", 852: "000852", 399006: "399006", 688: "000688", 16: "000016", 930740: "930740"}

def load_cfg():
    with open(CONFIG_PATH) as f:
        return yaml.safe_load(f)

def load_ts(cutoff):
    """加载所有PIT数据，截止cutoff日期"""
    ts = {}
    for name in ["macro", "market", "valuation", "flow", "policy", "earnings"]:
        f = PIT_DIR / f"{name}_pit.csv"
        if not f.exists(): continue
        df = pd.read_csv(f)
        df["available_date"] = pd.to_datetime(df["available_date"])
        df = df[df["available_date"] <= cutoff].copy()
        if name in ("market", "valuation"):
            df["entity"] = df["entity"].map(ENTITY_INT_MAP)
        for (e, feat), g in df.groupby(["entity", "feature"]):
            ts[(e, feat)] = g.sort_values("available_date")[["available_date", "value"]].reset_index(drop=True)
    return ts

def latest(ts, key):
    s = ts.get(key)
    return s["value"].iloc[-1] if s is not None and not s.empty else None

def history(ts, key, months=36):
    s = ts.get(key)
    if s is None or s.empty: return None
    cutoff = list(ts.values())[0]["available_date"].iloc[-1] - pd.DateOffset(months=months)
    hist = s[s["available_date"] >= cutoff]["value"].dropna().values
    return hist if len(hist) >= 6 else None

def pct(value, hist):
    if hist is None or len(hist) == 0: return 0.5
    return np.clip(np.searchsorted(np.sort(hist), value) / len(hist), 0.05, 0.95)

def calc_regime(ts, cfg):
    w = cfg["weights"]["macro_regime"]
    gdp = latest(ts, ("CN", "GDP_yoy")) or 5.0
    pmi = latest(ts, ("CN", "PMI")) or 50.0
    m2 = latest(ts, ("CN", "M2_yoy")) or 8.0
    cpi = latest(ts, ("CN", "CPI_yoy")) or 2.0
    ppi = latest(ts, ("CN", "PPI_yoy")) or 0.0
    growth = pct(gdp, history(ts, ("CN", "GDP_yoy"))) * 0.5 + \
             pct(pmi, history(ts, ("CN", "PMI"))) * 0.5
    liquidity = pct(m2, history(ts, ("CN", "M2_yoy")))
    inflation = (pct(abs(cpi - 2), history(ts, ("CN", "CPI_yoy"))) +
                 pct(abs(ppi), history(ts, ("CN", "PPI_yoy")))) / 2
    score = growth * w["growth"] + 0.5 * w["credit"] + liquidity * w["liquidity"] + \
            0.5 * w["policy"] + inflation * w["inflation"]
    regime = "Risk-On" if score >= 0.55 else ("Risk-Off" if score <= 0.35 else "Neutral")
    return {"score": round(score, 4), "regime": regime}

def calc_alpha(ts, cfg, code):
    aw = cfg["weights"]["alpha"]
    f = {}
    er = latest(ts, (code, "earnings_growth_yoy")) or latest(ts, (code, "earnings_revision_1m")) or latest(ts, (code, "earnings_revision_3m"))
    f["earnings"] = pct(er, history(ts, ("CN", "earnings_growth_yoy"))) if er is not None else 0.5
    pe = latest(ts, (code, "PE_TTM"))
    f["valuation"] = 1 - pct(pe, history(ts, (code, "PE_TTM"))) if pe is not None else 0.5
    flow = latest(ts, (code, "fund_flow"))
    f["flow"] = pct(flow, history(ts, (code, "fund_flow"))) if flow is not None else 0.5

    # 动量：4个月（经过A/B验证的最优）
    close = latest(ts, (code, "close"))
    if close is not None:
        ch = history(ts, (code, "close"), months=4)
        if ch is not None and len(ch) >= 2:
            mom = close / ch[0] - 1
            s = ts.get((code, "close"))
            rets = []
            if s is not None and len(s) >= 7:
                vals = s["value"].values
                for i in range(1, len(vals)): rets.append(vals[i] / vals[i - 1] - 1)
            f["momentum"] = pct(mom, np.array(rets) if rets else None)
        else:
            f["momentum"] = 0.5
    else:
        f["momentum"] = 0.5

    f["crowding"] = 0.5
    pol = latest(ts, ("CN", "policy_theme"))
    f["policy"] = np.clip(pol, 0, 1) if pol is not None else 0.5
    f["macro_style"] = 0.5

    score = (f["earnings"] * aw["earnings"]["weight"] + f["valuation"] * aw["valuation"]["weight"] +
             f["flow"] * aw["flow"]["weight"] + f["momentum"] * aw["momentum"]["weight"] +
             f["crowding"] * aw["crowding"]["weight"] + f["policy"] * aw["policy"]["weight"] +
             f["macro_style"] * aw["macro_style"]["weight"])
    return round(score, 4), f

def softmax(scores, t=0.5):
    vals = np.array(list(scores.values()))
    exp = np.exp((vals - vals.max()) / t)
    return {k: round(v, 4) for k, v in zip(scores.keys(), exp / exp.sum())}

def generate_rebalance_dates(start, end):
    """生成半月频调仓日：每月15日和月末"""
    dates = []
    current = pd.Timestamp(start)
    end = pd.Timestamp(end)
    while current <= end:
        # 每月15日
        d15 = pd.Timestamp(current.year, current.month, 15)
        if d15 >= pd.Timestamp(start) and d15 <= end:
            dates.append(d15)
        # 月末
        d_end = pd.Timestamp(current.year, current.month, 1) + pd.DateOffset(months=1) - pd.DateOffset(days=1)
        if d_end >= pd.Timestamp(start) and d_end <= end:
            dates.append(d_end)
        current += pd.DateOffset(months=1)
    return sorted(set(dates))

def run_biweekly():
    print("=" * 80)
    print("V7.2-FROZEN  半月频 Walk-Forward Backtest")
    print("Rebalance: 每月15日 + 月末")
    print("=" * 80)

    cfg = load_cfg()

    # 生成调仓日期
    rebalance_dates = generate_rebalance_dates("2024-01-01", "2026-08-15")
    print(f"\nTotal rebalance points: {len(rebalance_dates)}")

    records = []
    prev_weights = None

    for i, reb_date in enumerate(rebalance_dates):
        # 数据截止：调仓日前一天
        cutoff = reb_date - pd.DateOffset(days=1)
        ts = load_ts(cutoff)
        if not ts:
            continue

        regime = calc_regime(ts, cfg)
        scores = {}
        feats = {}
        for code, name in INDEX_MAP.items():
            s, f = calc_alpha(ts, cfg, code)
            scores[name] = s
            feats[name] = f

        weights = softmax(scores)
        ranked = sorted(weights.items(), key=lambda x: x[1], reverse=True)

        # 换手率
        turnover = 0
        if prev_weights is not None:
            turnover = sum(abs(weights[n] - prev_weights.get(n, 0)) for n in INDEX_MAP.values()) / 2

        # 集中度 HHI
        hhi = sum(w ** 2 for w in weights.values())

        record = {
            "date": reb_date.strftime("%Y-%m-%d"),
            "regime": regime["regime"],
            "regime_score": regime["score"],
            **{f"w_{k}": v for k, v in weights.items()},
            **{f"s_{k}": scores[k] for k in INDEX_MAP.values()},
            "top1": ranked[0][0],
            "top1_score": scores[ranked[0][0]],
            "bottom1": ranked[-1][0],
            "bottom1_score": scores[ranked[-1][0]],
            "concentration_hhi": round(hhi, 4),
            "turnover": round(turnover, 4),
        }
        records.append(record)
        prev_weights = weights.copy()

        if i % 6 == 0 or i == len(rebalance_dates) - 1:
            print(f"{record['date']} | {record['regime']:7s} | Top: {record['top1']:12s} ({record['top1_score']:.3f}) | Turnover: {record['turnover']:.1%}")

    df = pd.DataFrame(records)
    df.to_csv(OUTPUT_PATH, index=False)
    print(f"\n✅ Saved to {OUTPUT_PATH}")

    # 统计
    print("\n" + "=" * 80)
    print("半月频回测统计")
    print("=" * 80)
    print(f"\nRebalance dates: {len(df)}")
    print(f"\nRegime distribution:")
    print(df["regime"].value_counts())
    print(f"\nTop pick frequency:")
    print(df["top1"].value_counts())
    print(f"\nAverage turnover: {df['turnover'].mean():.2%}")
    print(f"Max turnover: {df['turnover'].max():.2%}")
    print(f"\nAverage allocation:")
    for name in INDEX_MAP.values():
        print(f"  {name:12s}: {df[f'w_{name}'].mean():.2%}")

if __name__ == "__main__":
    run_biweekly()
