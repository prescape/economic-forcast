#!/usr/bin/env python3
"""
walkforward_v72.py — Dalio China V7.2 Walk-Forward 回测 (高效版)

Walk-Forward 设定：
- 回测期：2021-01-01 ~ 2026-06-30（66个月）
- 再平衡：月度（月末）
- 训练窗口：36个月（滚动历史分位数）
- PIT 合规：available_date <= 当前月末

权重：V7.2-FROZEN（config/freeze.yaml）

优化：预计算所有特征时间序列，避免循环内重复查询。
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
import numpy as np
from datetime import datetime
import warnings
warnings.filterwarnings("ignore")

PIT_DIR = Path(__file__).resolve().parents[1] / "data" / "pit"

INDEX_MAP = {
    "000300": "沪深300",
    "000852": "中证1000",
    "399006": "创业板指",
    "000688": "科创50",
    "000016": "上证50",
    "930740": "300红利低波",
}
# Market/Valuation 的 entity 是 int，需映射到字符串代码
ENTITY_INT_MAP = {
    300: "000300",
    852: "000852",
    399006: "399006",
    688: "000688",
    16: "000016",
    930740: "930740",
}

# 反向映射
ENTITY_STR_MAP = {v: k for k, v in ENTITY_INT_MAP.items()}

# V7.2-FROZEN 权重
REGIME_WEIGHTS = {
    "growth": 0.25, "credit": 0.20, "liquidity": 0.20,
    "policy": 0.20, "inflation": 0.15,
}
ALPHA_WEIGHTS = {
    "earnings_revision": 0.25, "valuation": 0.20, "flow": 0.20,
    "momentum": 0.15, "crowding": 0.10,
    "policy_theme": 0.05, "macro_style": 0.05,
}
TRAIN_MONTHS = 36


def load_and_index():
    """
    加载所有 PIT 数据，统一 entity 为字符串代码，构建时间序列字典。
    """
    ts = {}
    for name in ["macro", "market", "valuation", "flow", "policy", "earnings"]:
        f = PIT_DIR / f"{name}_pit.csv"
        if not f.exists():
            continue
        df = pd.read_csv(f)
        df["available_date"] = pd.to_datetime(df["available_date"])
        # 统一 entity 为字符串代码
        if name in ("market", "valuation"):
            df["entity"] = df["entity"].map(ENTITY_INT_MAP)
        for (entity, feature), g in df.groupby(["entity", "feature"]):
            g = g.sort_values("available_date")[["available_date", "value"]].reset_index(drop=True)
            ts[(entity, feature)] = g
    return ts


def build_snapshot(ts: dict, asof: pd.Timestamp):
    """用二分查找快速获取 asof 时刻的最新值。"""
    snap = {}
    for key, g in ts.items():
        idx = g["available_date"].searchsorted(asof, side="right") - 1
        if idx >= 0:
            snap[key] = g.iloc[idx]["value"]
    return snap


def get_series(ts: dict, key: tuple):
    """获取某个特征的全部历史序列。"""
    return ts.get(key, pd.DataFrame({"available_date": [], "value": []}))


def rolling_pct(series: pd.DataFrame, asof: pd.Timestamp, value, min_obs=6):
    """
    计算 value 在 [asof - TRAIN_MONTHS, asof] 历史窗口中的分位数。
    series: DataFrame[available_date, value]
    """
    if series.empty:
        return 0.5
    mask = (series["available_date"] <= asof) & (series["available_date"] > asof - pd.DateOffset(months=TRAIN_MONTHS))
    vals = series.loc[mask, "value"].dropna().values
    if len(vals) < min_obs:
        return 0.5
    return np.clip(np.searchsorted(np.sort(vals), value) / len(vals), 0.05, 0.95)


def calc_regime(ts: dict, asof: pd.Timestamp):
    """Walk-Forward Regime 计算。"""
    # GDP
    gdp_s = get_series(ts, ("CN", "GDP_yoy"))
    gdp = gdp_s["value"].iloc[-1] if not gdp_s.empty else 5.0
    gdp_pct = rolling_pct(gdp_s, asof, gdp)

    # PMI
    pmi_s = get_series(ts, ("CN", "PMI"))
    pmi = pmi_s["value"].iloc[-1] if not pmi_s.empty else 50.0
    pmi_pct = rolling_pct(pmi_s, asof, pmi)
    growth = gdp_pct * 0.5 + pmi_pct * 0.5

    # M2
    m2_s = get_series(ts, ("CN", "M2_yoy"))
    m2 = m2_s["value"].iloc[-1] if not m2_s.empty else 8.0
    liquidity = rolling_pct(m2_s, asof, m2)

    # CPI / PPI
    cpi_s = get_series(ts, ("CN", "CPI_yoy"))
    cpi = cpi_s["value"].iloc[-1] if not cpi_s.empty else 2.0
    cpi_pct = rolling_pct(cpi_s, asof, abs(cpi - 2))

    ppi_s = get_series(ts, ("CN", "PPI_yoy"))
    ppi = ppi_s["value"].iloc[-1] if not ppi_s.empty else 0.0
    ppi_pct = rolling_pct(ppi_s, asof, abs(ppi))
    inflation = (cpi_pct + ppi_pct) / 2

    credit = 0.5
    policy = 0.5

    score = (
        growth * REGIME_WEIGHTS["growth"] +
        credit * REGIME_WEIGHTS["credit"] +
        liquidity * REGIME_WEIGHTS["liquidity"] +
        policy * REGIME_WEIGHTS["policy"] +
        inflation * REGIME_WEIGHTS["inflation"]
    )

    regime = "Risk-On" if score >= 0.55 else ("Risk-Off" if score <= 0.35 else "Neutral")
    return {"score": round(score, 4), "regime": regime,
            "details": {"growth": round(growth, 3), "liquidity": round(liquidity, 3), "inflation": round(inflation, 3)}}


def calc_alpha(ts: dict, asof: pd.Timestamp, code: str):
    """Walk-Forward Alpha 计算。"""
    f = {}

    # 1. Earnings
    er_s = get_series(ts, (code, "earnings_growth_yoy"))
    if er_s.empty:
        er_s = get_series(ts, (code, "earnings_revision_1m"))
    if er_s.empty:
        er_s = get_series(ts, (code, "earnings_revision_3m"))
    if not er_s.empty:
        er_val = er_s["value"].iloc[-1]
        # 横向对比：用全市场 earnings growth 分位数
        cn_er = get_series(ts, ("CN", "earnings_growth_yoy"))
        f["earnings_revision"] = rolling_pct(cn_er, asof, er_val)
    else:
        f["earnings_revision"] = 0.5

    # 2. Valuation (PE 低 = 高吸引力)
    pe_s = get_series(ts, (code, "PE_TTM"))
    if not pe_s.empty:
        pe = pe_s["value"].iloc[-1]
        pe_pct = rolling_pct(pe_s, asof, pe)
        f["valuation"] = 1 - pe_pct
    else:
        f["valuation"] = 0.5

    # 3. Flow
    flow_s = get_series(ts, (code, "fund_flow"))
    if not flow_s.empty:
        fv = flow_s["value"].iloc[-1]
        f["flow"] = rolling_pct(flow_s, asof, fv)
    else:
        f["flow"] = 0.5

    # 4. Momentum (close 的 6个月收益率历史分位数)
    close_s = get_series(ts, (code, "close"))
    if len(close_s) >= 2:
        close = close_s["value"].iloc[-1]
        # 找6个月前的 close
        past = close_s[close_s["available_date"] <= asof - pd.DateOffset(months=6)]
        if not past.empty:
            old_close = past["value"].iloc[-1]
            mom_ret = close / old_close - 1 if old_close != 0 else 0
            # 历史月度收益分位数
            rets = close_s["value"].pct_change().dropna()
            ret_df = pd.DataFrame({"available_date": close_s["available_date"].iloc[1:], "value": rets.values})
            f["momentum"] = rolling_pct(ret_df, asof, mom_ret)
        else:
            f["momentum"] = 0.5
    else:
        f["momentum"] = 0.5

    # 5. Crowding / Policy / Macro
    f["crowding"] = 0.5
    pol_s = get_series(ts, ("CN", "policy_theme"))
    if not pol_s.empty:
        f["policy_theme"] = np.clip(pol_s["value"].iloc[-1], 0, 1)
    else:
        f["policy_theme"] = 0.5
    f["macro_style"] = 0.5

    return f


def softmax_weights(scores: dict, temperature: float = 0.5):
    vals = np.array(list(scores.values()))
    exp = np.exp((vals - vals.max()) / temperature)
    w = exp / exp.sum()
    return {k: round(v, 4) for k, v in zip(scores.keys(), w)}


def run_walkforward(start="2021-01-01", end="2026-06-30"):
    print("=" * 80)
    print("Dalio China V7.2-FROZEN  Walk-Forward Backtest")
    print(f"Period: {start} ~ {end}  |  Train Window: {TRAIN_MONTHS}mo  |  Step: 1mo")
    print("=" * 80)

    ts = load_and_index()
    dates = pd.date_range(start, end, freq="ME")

    records = []
    prev_weights = None

    for d in dates:
        snap = build_snapshot(ts, d)
        if not snap:
            continue

        regime = calc_regime(ts, d)

        asset_scores = {}
        for code, name in INDEX_MAP.items():
            feats = calc_alpha(ts, d, code)
            score = sum(feats.get(k, 0) * w for k, w in ALPHA_WEIGHTS.items())
            asset_scores[name] = round(score, 4)

        weights = softmax_weights(asset_scores, temperature=0.5)
        top_weight = max(weights.values())
        hhi = sum(w ** 2 for w in weights.values())

        turnover = 0.0
        if prev_weights is not None:
            turnover = sum(abs(weights.get(a, 0) - prev_weights.get(a, 0)) for a in weights) / 2

        ranked = sorted(asset_scores.items(), key=lambda x: x[1], reverse=True)

        rec = {
            "date": d.strftime("%Y-%m-%d"),
            "regime": regime["regime"],
            "regime_score": regime["score"],
            **{f"w_{k}": v for k, v in weights.items()},
            **{f"s_{k}": v for k, v in asset_scores.items()},
            "top1": ranked[0][0], "top1_score": ranked[0][1],
            "bottom1": ranked[-1][0], "bottom1_score": ranked[-1][1],
            "concentration_hhi": round(hhi, 4),
            "turnover": round(turnover, 4),
        }
        records.append(rec)
        prev_weights = weights.copy()

    df = pd.DataFrame(records)

    # ── Summary ──
    print(f"\nTotal periods: {len(df)}")
    print(f"\nRegime distribution:")
    print(df["regime"].value_counts().to_string())

    print(f"\nTop pick frequency:")
    print(df["top1"].value_counts().to_string())

    print(f"\nBottom pick frequency:")
    print(df["bottom1"].value_counts().to_string())

    print(f"\nAverage allocation:")
    for c in [c for c in df.columns if c.startswith("w_")]:
        print(f"  {c[2:]:12s}: {df[c].mean():.2%}")

    print(f"\nTurnover: mean={df['turnover'].mean():.2%}, max={df['turnover'].max():.2%}")
    print(f"HHI: mean={df['concentration_hhi'].mean():.3f}, max={df['concentration_hhi'].max():.3f}")

    print(f"\n--- Last 12 Months ---")
    for _, r in df.tail(12).iterrows():
        print(f"{r['date']} | {r['regime']:>8s} | Top: {r['top1']:12s} ({r['top1_score']:.3f}) | TO: {r['turnover']:.1%}")

    out = Path(__file__).resolve().parents[1] / "data" / "walkforward_v72.csv"
    df.to_csv(out, index=False)
    print(f"\n[OK] Saved to {out}")
    return df


if __name__ == "__main__":
    run_walkforward()
