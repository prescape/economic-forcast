#!/usr/bin/env python3
"""
fetch_flow_pit.py — Dalio China V7.2 资金流向数据采集（Point-in-Time）

采集项：北向资金、融资余额变化、南向资金、成交额变化(proxy for 机构活跃度)
覆盖：CN（全市场） + 6只指数

数据源优先级：
1. 融资余额: akshare stock_margin_sse（上交所，日度，到2026-08-07）
2. 北向资金: akshare stock_hsgt_hist_em（到2024-08断更，历史可用）
3. 南向资金: akshare stock_hsgt_hist_em（港股通，实时到2026-08-07）
4. 成交额变化: market_pit 衍生（proxy for 机构活跃度）

PIT 规则：T日盘后公布 T日数据，available_date = T日收盘后
"""
import argparse
import sys
from pathlib import Path

import pandas as pd
import numpy as np

OUT_DIR = Path(__file__).resolve().parents[1] / "data" / "pit"
OUT_DIR.mkdir(parents=True, exist_ok=True)

UNIVERSE = ["000300", "000852", "399006", "000688", "000016", "930740"]


def _add_pit_meta(df: pd.DataFrame) -> pd.DataFrame:
    required = ["entity", "feature", "observation_date", "release_date",
                "available_date", "value", "source", "data_quality"]
    for c in required:
        if c not in df.columns:
            raise ValueError(f"PIT column missing: {c}")
    df["observation_date"] = pd.to_datetime(df["observation_date"]).dt.strftime("%Y-%m-%d")
    df["release_date"] = pd.to_datetime(df["release_date"]).dt.strftime("%Y-%m-%d")
    df["available_date"] = pd.to_datetime(df["available_date"]).dt.strftime("%Y-%m-%d")
    df["revision_date"] = ""
    return df[["entity", "feature", "observation_date", "release_date",
               "available_date", "revision_date", "value", "source", "data_quality"]]


def _try_akshare():
    try:
        import akshare as ak
        return ak
    except ImportError:
        return None


def fetch_margin_balance(ak) -> pd.DataFrame:
    """融资余额变化（上交所，代表杠杆资金/散户情绪）。"""
    rows = []
    if ak is not None:
        try:
            df = ak.stock_margin_sse(start_date='20200101', end_date='20260808')
            df['信用交易日期'] = pd.to_datetime(df['信用交易日期'])
            df = df.sort_values('信用交易日期')
            # 计算融资余额日变化
            df['margin_change'] = df['融资余额'].diff()
            for _, r in df.dropna(subset=['margin_change']).iterrows():
                d = r['信用交易日期']
                rows.append({
                    "entity": "CN", "feature": "margin_balance_change",
                    "observation_date": d, "release_date": d,
                    "available_date": d,
                    "value": round(r['margin_change'] / 1e8, 4),  # 转为亿元
                    "source": "SSE via akshare", "data_quality": "A"
                })
                rows.append({
                    "entity": "CN", "feature": "margin_balance",
                    "observation_date": d, "release_date": d,
                    "available_date": d,
                    "value": round(r['融资余额'] / 1e8, 4),
                    "source": "SSE via akshare", "data_quality": "A"
                })
        except Exception as e:
            print(f"[WARN] akshare margin failed: {e}", file=sys.stderr)
    return pd.DataFrame(rows)


def fetch_northbound(ak) -> pd.DataFrame:
    """北向资金日度净流入（HKEX，2024-08后断更，历史数据可用）。"""
    rows = []
    if ak is not None:
        try:
            df = ak.stock_hsgt_hist_em(symbol='北向资金')
            df['日期'] = pd.to_datetime(df['日期'])
            # 只保留有有效数据的行
            df_valid = df.dropna(subset=['当日成交净买额'])
            for _, r in df_valid.iterrows():
                d = r['日期']
                rows.append({
                    "entity": "CN", "feature": "northbound_net_inflow",
                    "observation_date": d, "release_date": d,
                    "available_date": d,
                    "value": float(r['当日成交净买额']),
                    "source": "HKEX via akshare", "data_quality": "A"
                })
            print(f"[INFO] Northbound: {len(rows)} rows, latest {df_valid['日期'].max().strftime('%Y-%m-%d')}")
        except Exception as e:
            print(f"[WARN] akshare northbound failed: {e}", file=sys.stderr)
    return pd.DataFrame(rows)


def fetch_southbound(ak) -> pd.DataFrame:
    """南向资金日度净流入（港股通，实时到2026-08-07）。"""
    rows = []
    if ak is not None:
        try:
            df = ak.stock_hsgt_hist_em(symbol='南向资金')
            df['日期'] = pd.to_datetime(df['日期'])
            # 南向资金数据基本完整
            for _, r in df.iterrows():
                d = r['日期']
                val = r['当日成交净买额']
                if pd.isna(val):
                    continue
                rows.append({
                    "entity": "CN", "feature": "southbound_net_inflow",
                    "observation_date": d, "release_date": d,
                    "available_date": d,
                    "value": float(val),
                    "source": "HKEX via akshare", "data_quality": "A"
                })
            print(f"[INFO] Southbound: {len(rows)} rows, latest {df['日期'].max().strftime('%Y-%m-%d')}")
        except Exception as e:
            print(f"[WARN] akshare southbound failed: {e}", file=sys.stderr)
    return pd.DataFrame(rows)


def fetch_amount_proxy(market_pit_path: str) -> pd.DataFrame:
    """
    用市场成交额变化作为机构活跃度 proxy。
    逻辑：成交额放大且价格上涨 = 机构流入信号
    """
    rows = []
    path = Path(market_pit_path)
    if not path.exists():
        return pd.DataFrame(rows)
    
    df = pd.read_csv(path)
    amount = df[df["feature"] == "amount"].copy()
    if amount.empty:
        return pd.DataFrame(rows)
    
    amount["observation_date"] = pd.to_datetime(amount["observation_date"])
    amount = amount.sort_values(["entity", "observation_date"])
    
    for code in UNIVERSE:
        sub = amount[amount["entity"] == code].copy()
        if sub.empty:
            continue
        sub["amount_ma20"] = sub["value"].rolling(20).mean()
        sub["amount_ratio"] = sub["value"] / sub["amount_ma20"] - 1
        for _, r in sub.dropna(subset=["amount_ratio"]).iterrows():
            rows.append({
                "entity": code, "feature": "amount_ratio_vs_ma20",
                "observation_date": r["observation_date"],
                "release_date": r["observation_date"],
                "available_date": r["observation_date"],
                "value": round(r["amount_ratio"], 6),
                "source": "derived_proxy", "data_quality": "D"
            })
    return pd.DataFrame(rows)


def _demo_flow(start="2024-01-01", days=400) -> pd.DataFrame:
    """生成示例资金流向数据（北向/融资/ETF）。"""
    rows = []
    import random
    random.seed(2024)
    for i in range(days):
        d = pd.Timestamp(start) + pd.Timedelta(days=i)
        if d.weekday() >= 5:
            continue
        # 北向资金
        nb = random.gauss(15, 80)
        rows.append({"entity": "CN", "feature": "northbound_net_inflow",
                     "observation_date": d, "release_date": d,
                     "available_date": d, "value": round(nb, 4),
                     "source": "demo_HKEX", "data_quality": "A"})
        # 融资余额变化
        mb = random.gauss(5, 30)
        rows.append({"entity": "CN", "feature": "margin_balance_change",
                     "observation_date": d, "release_date": d,
                     "available_date": d, "value": round(mb, 4),
                     "source": "demo_exchange", "data_quality": "B"})
        # 指数 ETF 份额变化
        for code in UNIVERSE:
            etf = random.gauss(0, 0.5)
            rows.append({"entity": code, "feature": "etf_share_change_pct",
                         "observation_date": d, "release_date": d,
                         "available_date": d, "value": round(etf, 6),
                         "source": "demo_fund", "data_quality": "C"})
    return pd.DataFrame(rows)


def calc_fund_flow_score(df: pd.DataFrame) -> pd.DataFrame:
    """汇总 fund_flow 综合评分（标准化到 [-1, 1]）。"""
    score_rows = []
    
    # 1. 北向资金 z-score
    nb = df[df["feature"] == "northbound_net_inflow"].copy()
    if not nb.empty:
        nb["observation_date"] = pd.to_datetime(nb["observation_date"])
        nb = nb.sort_values("observation_date")
        nb["z"] = (nb["value"] - nb["value"].rolling(20).mean()) / nb["value"].rolling(20).std()
        for _, r in nb.dropna(subset=["z"]).iterrows():
            score_rows.append({
                "entity": "CN", "feature": "fund_flow",
                "observation_date": r["observation_date"],
                "release_date": r["observation_date"],
                "available_date": r["observation_date"],
                "value": round(np.clip(r["z"] / 3, -1, 1), 6),
                "source": "derived", "data_quality": "C"
            })
    
    # 2. 融资余额变化 z-score（如果北向没有数据）
    if not score_rows:
        mb = df[df["feature"] == "margin_balance_change"].copy()
        if not mb.empty:
            mb["observation_date"] = pd.to_datetime(mb["observation_date"])
            mb = mb.sort_values("observation_date")
            mb["z"] = (mb["value"] - mb["value"].rolling(20).mean()) / mb["value"].rolling(20).std()
            for _, r in mb.dropna(subset=["z"]).iterrows():
                score_rows.append({
                    "entity": "CN", "feature": "fund_flow",
                    "observation_date": r["observation_date"],
                    "release_date": r["observation_date"],
                    "available_date": r["observation_date"],
                    "value": round(np.clip(r["z"] / 3, -1, 1), 6),
                    "source": "derived_margin", "data_quality": "C"
                })
    
    return pd.DataFrame(score_rows)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", default=str(OUT_DIR / "flow_pit.csv"))
    p.add_argument("--demo", action="store_true")
    p.add_argument("--market-pit", default=str(OUT_DIR / "market_pit.csv"),
                   help="市场数据PIT文件路径")
    args = p.parse_args()

    ak = None if args.demo else _try_akshare()
    parts = []

    # 1. 融资余额（akshare 实时）
    margin = fetch_margin_balance(ak)
    if not margin.empty:
        parts.append(margin)
        print(f"[INFO] Margin balance: {len(margin)} rows")

    # 2. 北向资金（历史到2024-08）
    nb = fetch_northbound(ak)
    if not nb.empty:
        parts.append(nb)

    # 3. 南向资金（实时到2026-08）
    sb = fetch_southbound(ak)
    if not sb.empty:
        parts.append(sb)

    # 4. 成交额 proxy
    amount_proxy = fetch_amount_proxy(args.market_pit)
    if not amount_proxy.empty:
        parts.append(amount_proxy)
        print(f"[INFO] Amount proxy: {len(amount_proxy)} rows")

    # 5. Demo 补全
    if not parts:
        print("[INFO] 使用示例数据")
        parts.append(_demo_flow())

    base = pd.concat(parts, ignore_index=True)
    parts.append(calc_fund_flow_score(base))

    df = pd.concat(parts, ignore_index=True)
    df = _add_pit_meta(df)
    df.to_csv(args.out, index=False)
    print(f"[OK] Flow PIT → {args.out} ({len(df)} rows)")

    # 最新数据摘要
    latest = df.copy()
    latest["observation_date"] = pd.to_datetime(latest["observation_date"])
    max_date = latest["observation_date"].max()
    print(f"\nLatest data: {max_date.strftime('%Y-%m-%d')}")
    summary = latest[latest["observation_date"] == max_date][["entity", "feature", "value", "source"]]
    if not summary.empty:
        print("\nLatest records:")
        for _, r in summary.head(10).iterrows():
            print(f"  {r['entity']:>8s} {r['feature']:25s}: {r['value']:>12.4f}  ({r['source']})")


if __name__ == "__main__":
    main()
