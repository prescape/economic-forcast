---
name: dalio-china-asset-allocation-v7-5-1-rc2
description: PIT-safe China asset-allocation research skill using the frozen V7.4 alpha layer and V7.5.1 macro/risk regime engine, with semi-monthly walk-forward, data-quality checks, robustness tests, and a unified freeze gate.
version: 7.5.1-rc2
---

# Dalio China Asset Allocation V7.5.1-RC2

## Purpose
Run the V7.5.1-RC2 China asset-allocation workflow with PIT-safe data, semi-monthly walk-forward evaluation, and a unified freeze decision. RC2 is an engineering/audit release; model parameters are unchanged from V7.5.1.

## Frozen model design
- Cross-sectional alpha: 55% valuation + 45% fund flow.
- Growth: PMI level + 3-month direction; GDP is slow confirmation.
- Inflation: CPI/PPI 3-month direction.
- Credit: M2 3-month acceleration.
- Policy: LPR/RRR easing signal with corrected RRR sign.
- Fast brake: CSI300 below 120-day MA and negative 20-day return => immediate Risk-Off.
- Hysteresis: downside immediate; upside requires two consecutive semi-monthly confirmations.
- Risk budgets: Risk-On 80%, Neutral 55%, Risk-Off 30%.
- Default one-way transaction cost: 10 bps.

## Standard workflow
1. Install dependencies: `pip install -r requirements.txt`
2. Refresh PIT data when network access is available: `python scripts/fetch_all_pit.py`
3. Reproduce the 132-node baseline: `python run_backtest.py`
4. Run the unified RC2 gate: `python run_freeze_gate.py`
5. Read `outputs/v751_rc2/unified_freeze_report.md`.
6. Do not label the package `V7.5.1-FROZEN` while the unified grade is `CONDITIONAL PASS`.
7. Accumulate untouched future semi-monthly OOS observations without changing model parameters.

## Safety / research constraints
- Do not silently impute missing PIT features.
- Never use rows whose `available_date` is later than the decision as-of date.
- Do not optimize parameters after viewing robustness or OOS results; use a separate future branch for research changes.
- Treat demo/proxy data as lower-quality and report it explicitly.
- A data-quality or leakage hard failure blocks freezing.
