Place or generate PIT CSV files here. `scripts/fetch_all_pit.py` creates macro_pit.csv, market_pit.csv, valuation_pit.csv, flow_pit.csv, policy_pit.csv, earnings_pit.csv and unified_pit.csv.
