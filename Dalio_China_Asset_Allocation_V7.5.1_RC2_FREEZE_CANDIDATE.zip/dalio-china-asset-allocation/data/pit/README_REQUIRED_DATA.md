# unified_pit.csv

`unified_pit.csv` is intentionally not fabricated or reconstructed from partial snippets.

Generate it in the installed environment with Internet access:

```bash
python scripts/fetch_all_pit.py
```

Expected output:

`data/pit/unified_pit.csv`

For historical backfill before a freeze/reproduction run, also use:

```bash
python scripts/fetch_missing_history_v7_3.py
```
