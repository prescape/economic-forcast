"""Dalio China Asset Allocation V7.5 — regime engine upgrade.

Alpha is frozen from V7.4 (55% valuation + 45% fund flow).
V7.5 changes only the macro/risk layer:
- Growth: PMI level + 3m direction; GDP is slow confirmation.
- Inflation: CPI/PPI 3m direction -> Goldilocks/Reflation/Stagflation/Deflation/Mixed.
- Credit: M2 3m acceleration. PBOC_demo credit_yoy is explicitly excluded.
- Policy: LPR cuts and RRR cuts are easing-positive. Fixes the legacy RRR sign bug.
- Fast risk brake: CSI300 below 120d MA and 20d return < 0 => immediate Risk-Off.
- Asymmetric hysteresis: downside immediate; upside requires two consecutive half-month confirmations.
- Risk budgets remain 80% / 55% / 30%; one-way cost remains 10 bps.
"""
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd

ASSETS=["000300","000852","399006","000688","000016"]
RANK_POINTS=np.array([5,4,3,2,1],dtype=float)
REGIME_ALLOC={"Risk-On":0.80,"Neutral":0.55,"Risk-Off":0.30}
REGIME_LEVEL={"Risk-Off":0,"Neutral":1,"Risk-On":2}
LEVEL_REGIME={0:"Risk-Off",1:"Neutral",2:"Risk-On"}

def norm_code(x):
    s=str(x).strip()
    if s.endswith(".0") and s[:-2].isdigit(): s=s[:-2]
    if s.isdigit() and len(s)<6: s=s.zfill(6)
    return s

def hist_series(d,feature,entity,asof):
    q=d[(d.feature==feature)&(d.entity==entity)&(d.available_date<=asof)&(d.observation_date<=asof)].copy()
    q=q.dropna(subset=["observation_date","value"]).sort_values(["observation_date","available_date"])
    q=q.drop_duplicates("observation_date",keep="last")
    return q.set_index("observation_date").value.astype(float)

def lastv(s): return float(s.iloc[-1]) if len(s) else np.nan

def delta_months(s,months):
    if len(s)<2:return np.nan
    cutoff=s.index[-1]-pd.DateOffset(months=months)
    p=s[s.index<=cutoff]
    return float(s.iloc[-1]-p.iloc[-1]) if len(p) else np.nan

def build_macro(d,decision,asof):
    pmi=hist_series(d,"PMI","CN",asof); cpi=hist_series(d,"CPI_yoy","CN",asof)
    ppi=hist_series(d,"PPI_yoy","CN",asof); m2=hist_series(d,"M2_yoy","CN",asof)
    gdp=hist_series(d,"GDP_yoy","CN",asof); lpr=hist_series(d,"LPR_1Y","CN",asof)
    rrr=hist_series(d,"RRR_change","CN",asof)
    pv,pd3=lastv(pmi),delta_months(pmi,3); cv,cd3=lastv(cpi),delta_months(cpi,3)
    ppv,ppd3=lastv(ppi),delta_months(ppi,3); mv,md3=lastv(m2),delta_months(m2,3)
    lpr6=delta_months(lpr,6); recent=rrr[rrr.index>=asof-pd.Timedelta(days=180)]
    pol=0.0
    if np.isfinite(lpr6): pol+=0.6*np.clip(-lpr6/0.0025,-1,1)
    if len(recent): pol+=0.4*np.clip(-float(recent.sum())/0.5,-1,1)

    gu=bool(np.isfinite(pv) and np.isfinite(pd3) and pv>=50 and pd3>=0)
    gw=bool(np.isfinite(pv) and np.isfinite(pd3) and (pv<50 or pd3<=-0.5))
    parts=[]
    if np.isfinite(cd3):parts.append(cd3)
    if np.isfinite(ppd3):parts.append(ppd3/3)
    idir=float(np.mean(parts)) if parts else 0.0
    iu,idd=idir>0.15,idir<-0.15
    if gu and idd:q="Goldilocks"
    elif gu and iu:q="Reflation"
    elif gw and iu:q="Stagflation"
    elif gw and idd:q="Deflation"
    else:q="Mixed"
    cw=bool(np.isfinite(md3) and md3<0); cs=bool(np.isfinite(md3) and md3>=0)

    s=hist_series(d,"close","000300",asof)
    price=float(s.iloc[-1]); ma120=float(s.iloc[-120:].mean())
    r20=float(price/s.iloc[-21]-1); r60=float(price/s.iloc[-61]-1); below=price<ma120

    desired="Neutral"
    if gu and cs and (not below) and r60>0: desired="Risk-On"
    if gw and (cw or q=="Stagflation") and r60<=0: desired="Risk-Off"
    if below and r20<0: desired="Risk-Off"
    return {"quadrant":q,"desired_regime":desired,"GDP_yoy":lastv(gdp),"PMI":pv,"PMI_3m_change":pd3,
            "CPI_yoy":cv,"CPI_3m_change":cd3,"PPI_yoy":ppv,"PPI_3m_change":ppd3,
            "M2_yoy":mv,"M2_3m_change":md3,"policy_easing_score":pol,
            "CSI300_MA120":ma120,"CSI300_ret20":r20,"CSI300_ret60":r60,"CSI300_below_MA120":below}

def perf(r):
    r=pd.Series(r).astype(float);nav=(1+r).cumprod();total=float(nav.iloc[-1]-1);yrs=len(r)/24
    dd=nav/nav.cummax()-1
    return {"total_return":total,"annualized_return":float((1+total)**(1/yrs)-1),
            "annualized_volatility":float(r.std(ddof=1)*np.sqrt(24)),
            "sharpe":float(r.mean()/r.std(ddof=1)*np.sqrt(24)),
            "max_drawdown":float(dd.min()),"win_rate":float((r>0).mean())}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input",required=True)
    ap.add_argument("--factors",required=True)
    ap.add_argument("--start",default="2021-01");ap.add_argument("--end",default="2026-06")
    ap.add_argument("--cost-bps",type=float,default=10.0)
    ap.add_argument("--output-dir",default="v75_backtest_output")
    args=ap.parse_args();out=Path(args.output_dir);out.mkdir(parents=True,exist_ok=True)

    d=pd.read_csv(args.input,low_memory=False)
    d["entity"]=d.entity.map(norm_code);d["observation_date"]=pd.to_datetime(d.observation_date,errors="coerce")
    d["available_date"]=pd.to_datetime(d.available_date,errors="coerce");d["value"]=pd.to_numeric(d.value,errors="coerce")
    p=pd.read_csv(args.factors);p["decision_date"]=pd.to_datetime(p.decision_date);p["as_of_date"]=pd.to_datetime(p.as_of_date);p["asset"]=p.asset.map(norm_code)
    p=p[(p.decision_date.dt.to_period("M")>=pd.Period(args.start))&(p.decision_date.dt.to_period("M")<=pd.Period(args.end))]
    nodes=p[["decision_date","as_of_date"]].drop_duplicates().sort_values("decision_date").reset_index(drop=True)

    macros=[]
    for r in nodes.itertuples(): macros.append(build_macro(d,r.decision_date,r.as_of_date))
    m=pd.concat([nodes,pd.DataFrame(macros)],axis=1)
    cur="Neutral";up_count=0;prev_des=None;final=[]
    for des in m.desired_regime:
        if REGIME_LEVEL[des]<REGIME_LEVEL[cur]:cur=des;up_count=0
        elif REGIME_LEVEL[des]>REGIME_LEVEL[cur]:
            up_count=up_count+1 if des==prev_des else 1
            if up_count>=2:cur=LEVEL_REGIME[min(REGIME_LEVEL[cur]+1,REGIME_LEVEL[des])];up_count=0
        else:up_count=0
        final.append(cur);prev_des=des
    m["regime"]=final;m.to_csv(out/"V7.5_macro_regime_132_nodes.csv",index=False)

    # Price matrix for exact half-month holding returns
    c=d[(d.feature=="close")&d.entity.isin(ASSETS)].copy().sort_values(["entity","observation_date","available_date"]).drop_duplicates(["entity","observation_date"],keep="last")
    px=c.pivot(index="observation_date",columns="entity",values="value").sort_index()
    end_date=pd.Period(args.end).end_time.normalize()
    prev_w={a:0.0 for a in ASSETS};prev_cash=1.0;rows=[]
    for i,n in m.iterrows():
        dt=n.decision_date;g=p[p.decision_date==dt].set_index("asset").reindex(ASSETS)
        g=g.copy();g["alpha_v75"]=0.55*g["valuation"]+0.45*g["flow"]
        risk=REGIME_ALLOC[n.regime]
        ranked=g[["alpha_v75"]].reset_index().sort_values(["alpha_v75","asset"],ascending=[False,False],kind="mergesort").asset.tolist()
        raw={a:0.0 for a in ASSETS}
        for pts,a in zip(RANK_POINTS,ranked):raw[a]=risk*pts/RANK_POINTS.sum()
        if i:
            blend={a:0.5*prev_w[a]+0.5*raw[a] for a in ASSETS};ss=sum(blend.values());w={a:blend[a]*risk/ss for a in ASSETS}
        else:w=raw.copy()
        cash=1-sum(w.values());turn=.5*(sum(abs(w[a]-prev_w[a]) for a in ASSETS)+abs(cash-prev_cash));cost=turn*args.cost_bps/10000
        nxt=m.decision_date.iloc[i+1] if i+1<len(m) else end_date
        rr={}
        for a in ASSETS:
            s=px[a].dropna();s0=s[s.index<=dt];s1=s[s.index<=nxt]
            rr[a]=float(s1.iloc[-1]/s0.iloc[-1]-1)
        gross=sum(w[a]*rr[a] for a in ASSETS);net=gross-cost
        row={"decision_date":dt.date(),"as_of_date":n.as_of_date.date(),"period_end":pd.Timestamp(nxt).date(),
             "quadrant":n.quadrant,"desired_regime":n.desired_regime,"regime":n.regime,"risk_allocation":risk,
             "cash_weight":cash,"turnover":turn,"transaction_cost":cost,"gross_return":gross,"net_return":net,
             "benchmark_return":rr["000300"]}
        for a in ASSETS:row[f"w_{a}"]=w[a];row[f"r_{a}"]=rr[a];row[f"alpha_v75_{a}"]=float(g.loc[a,"alpha_v75"])
        rows.append(row);prev_w=w;prev_cash=cash
    r=pd.DataFrame(rows);r["net_nav"]=(1+r.net_return).cumprod();r["benchmark_nav"]=(1+r.benchmark_return).cumprod()
    r.to_csv(out/"V7.5_walk_forward_132_nodes_results.csv",index=False)
    summ={"version":"V7.5-regime-engine","net":perf(r.net_return),"benchmark_CSI300":perf(r.benchmark_return),
          "mean_turnover_per_node":float(r.turnover.mean()),"total_transaction_cost_nav_points":float(r.transaction_cost.sum()),
          "cost_bps_one_way":args.cost_bps}
    json.dump(summ,open(out/"V7.5_backtest_summary.json","w",encoding="utf-8"),ensure_ascii=False,indent=2)
    print(json.dumps(summ,ensure_ascii=False,indent=2))
if __name__=="__main__":main()
