"""Dalio China Asset Allocation V7.4 evidence-based walk-forward backtest.

V7.4 changes versus V7.3:
1) Cross-sectional alpha = 55% relative valuation + 45% fund flow.
2) earnings_revision, momentum and crowding remain diagnostics/monitors but do not
   enter ranking until a future pre-declared reactivation rule is frozen.
3) policy_theme is removed from cross-sectional ranking because it is common
   across assets at a decision node; macro regime risk allocation is unchanged.
4) Holdings are smoothed: 50% previous portfolio + 50% current rank target,
   then rescaled to the current V7.3 regime risk budget.
5) One-way transaction cost default remains 10 bps.
"""
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd

ASSETS=['000300','000852','399006','000688','000016']
RANK_POINTS=np.array([5,4,3,2,1],dtype=float)
REGIME_ALLOC={'Risk-On':0.80,'Neutral':0.55,'Risk-Off':0.30}
V74_ALPHA_WEIGHTS={'valuation':0.55,'flow':0.45}
SMOOTH_PREVIOUS=0.50
SMOOTH_NEW=0.50

def norm_code(x):
    s=str(x).strip()
    if s.endswith('.0') and s[:-2].isdigit(): s=s[:-2]
    if s.isdigit() and len(s)<6: s=s.zfill(6)
    return s

def regime(m):
    if m>0.20: return 'Risk-On'
    if m<-0.20: return 'Risk-Off'
    return 'Neutral'

def perf(r, periods_per_year=24):
    r=pd.Series(r).dropna().astype(float)
    nav=(1+r).cumprod(); total=nav.iloc[-1]-1; yrs=len(r)/periods_per_year
    ann=(1+total)**(1/yrs)-1
    vol=r.std(ddof=1)*np.sqrt(periods_per_year)
    sharpe=r.mean()/r.std(ddof=1)*np.sqrt(periods_per_year) if r.std(ddof=1)>1e-12 else np.nan
    dd=nav/nav.cummax()-1
    return {'total_return':float(total),'annualized_return':float(ann),'annualized_volatility':float(vol),'sharpe':float(sharpe),'max_drawdown':float(dd.min()),'win_rate':float((r>0).mean())}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input',required=True,help='unified_pit.csv')
    ap.add_argument('--factors',required=True,help='completed PIT-safe factor panel')
    ap.add_argument('--returns',required=True,help='next_month_return.csv monthly cross-check')
    ap.add_argument('--start',default='2021-01'); ap.add_argument('--end',default='2026-06')
    ap.add_argument('--cost-bps',type=float,default=10.0)
    ap.add_argument('--output-dir',default='v74_backtest_output')
    args=ap.parse_args(); out=Path(args.output_dir);out.mkdir(parents=True,exist_ok=True)

    panel=pd.read_csv(args.factors)
    panel['decision_date']=pd.to_datetime(panel.decision_date);panel['as_of_date']=pd.to_datetime(panel.as_of_date);panel['asset']=panel.asset.map(norm_code)
    panel=panel[(panel.decision_date.dt.to_period('M')>=pd.Period(args.start)) & (panel.decision_date.dt.to_period('M')<=pd.Period(args.end))]
    required=['valuation','flow','macro_style']
    missing=[c for c in required if c not in panel.columns]
    if missing: raise SystemExit(f'missing V7.4 factor columns: {missing}')
    if (panel.as_of_date>=panel.decision_date).any():raise SystemExit('PIT violation: as_of_date must be before decision_date')

    pit=pd.read_csv(args.input,low_memory=False)
    pit['entity']=pit.entity.map(norm_code);pit['observation_date']=pd.to_datetime(pit.observation_date,errors='coerce');pit['available_date']=pd.to_datetime(pit.available_date,errors='coerce');pit['value']=pd.to_numeric(pit.value,errors='coerce')
    close=pit[(pit.feature=='close') & pit.entity.isin(ASSETS)].copy().sort_values(['entity','observation_date','available_date']).drop_duplicates(['entity','observation_date'],keep='last')
    px=close.pivot(index='observation_date',columns='entity',values='value').sort_index()

    nodes=sorted(panel.decision_date.unique());end_date=pd.Period(args.end,freq='M').end_time.normalize()
    prev_w={a:0.0 for a in ASSETS};prev_cash=1.0;rows=[]
    for j,dt64 in enumerate(nodes):
        dt=pd.Timestamp(dt64);g=panel[panel.decision_date==dt].set_index('asset').reindex(ASSETS)
        if g[['valuation','flow']].isna().any().any():raise SystemExit(f'missing V7.4 core alpha factor at {dt.date()}')
        # Legacy completed panel carries the common macro regime signal in 399006 macro_style.
        macro=float(g.loc['399006','macro_style'])
        reg=regime(macro);risk=REGIME_ALLOC[reg]
        g=g.copy();g['alpha_v74']=V74_ALPHA_WEIGHTS['valuation']*g['valuation']+V74_ALPHA_WEIGHTS['flow']*g['flow']
        ranked=g[['alpha_v74']].reset_index().sort_values(['alpha_v74','asset'],ascending=[False,False],kind='mergesort').asset.tolist()
        raw={a:0.0 for a in ASSETS}
        for p,a in zip(RANK_POINTS,ranked):raw[a]=risk*p/RANK_POINTS.sum()
        if rows:
            blend={a:SMOOTH_PREVIOUS*prev_w[a]+SMOOTH_NEW*raw[a] for a in ASSETS};s=sum(blend.values());w={a:blend[a]*risk/s for a in ASSETS}
        else:w=raw.copy()
        cash=1-sum(w.values());turnover=.5*(sum(abs(w[a]-prev_w[a]) for a in ASSETS)+abs(cash-prev_cash));cost=turnover*args.cost_bps/10000
        next_dt=pd.Timestamp(nodes[j+1]) if j+1<len(nodes) else end_date
        period_ret={}
        for a in ASSETS:
            s=px[a].dropna();s0=s[s.index<=dt];s1=s[s.index<=next_dt]
            period_ret[a]=np.nan if s0.empty or s1.empty else float(s1.iloc[-1]/s0.iloc[-1]-1)
        gross=sum(w[a]*(0.0 if not np.isfinite(period_ret[a]) else period_ret[a]) for a in ASSETS);net=gross-cost
        row={'decision_date':dt.date(),'as_of_date':g.as_of_date.iloc[0].date(),'period_end':next_dt.date(),'regime':reg,'macro_common':macro,'risk_allocation':risk,'cash_weight':cash,'turnover':turnover,'transaction_cost':cost,'gross_return':gross,'net_return':net,'benchmark_return':period_ret['000300']}
        for a in ASSETS:
            row[f'w_{a}']=w[a];row[f'raw_w_{a}']=raw[a];row[f'r_{a}']=period_ret[a];row[f'alpha_v74_{a}']=float(g.loc[a,'alpha_v74'])
        rows.append(row);prev_w=w;prev_cash=cash
    res=pd.DataFrame(rows);res['net_nav']=(1+res.net_return).cumprod();res['gross_nav']=(1+res.gross_return).cumprod();res['benchmark_nav']=(1+res.benchmark_return).cumprod();res.to_csv(out/'V7.4_walk_forward_132_nodes_results.csv',index=False)

    res['month']=pd.to_datetime(res.decision_date).dt.to_period('M').astype(str)
    monthly=res.groupby('month').agg(net_return=('net_return',lambda x:(1+x).prod()-1),gross_return=('gross_return',lambda x:(1+x).prod()-1),benchmark_return_exact=('benchmark_return',lambda x:(1+x).prod()-1),turnover=('turnover','sum'),transaction_cost=('transaction_cost','sum')).reset_index()
    mret=pd.read_csv(args.returns);mret['asset']=mret.asset.map(norm_code);bm=mret[mret.asset=='000300'][['realized_month','next_month_return']].rename(columns={'realized_month':'month','next_month_return':'benchmark_return_monthly_file'});monthly=monthly.merge(bm,on='month',how='left');monthly['benchmark_gap_vs_file']=monthly.benchmark_return_exact-monthly.benchmark_return_monthly_file;monthly['net_nav']=(1+monthly.net_return).cumprod();monthly['benchmark_nav_exact']=(1+monthly.benchmark_return_exact).cumprod();monthly.to_csv(out/'V7.4_monthly_results_66m.csv',index=False)
    pn=perf(res.net_return);pg=perf(res.gross_return);pb=perf(res.benchmark_return)
    summary={'version':'V7.4-evidence-based','nodes':len(res),'months':len(monthly),'alpha_weights':V74_ALPHA_WEIGHTS,'holding_smoothing':{'previous':SMOOTH_PREVIOUS,'new_target':SMOOTH_NEW},'risk_allocation':REGIME_ALLOC,'net':pn,'gross':pg,'benchmark_CSI300':pb,'annualized_alpha_vs_CSI300':pn['annualized_return']-pb['annualized_return'],'mean_turnover_per_node':float(res.turnover.mean()),'total_transaction_cost_nav_points':float(res.transaction_cost.sum()),'cost_bps_one_way':args.cost_bps,'inactive_alpha_monitors':['earnings_revision','momentum','crowding'],'policy_theme_role':'monitor only; no cross-sectional discrimination','macro_style_role':'regime context'}
    json.dump(summary,open(out/'V7.4_backtest_summary.json','w',encoding='utf-8'),ensure_ascii=False,indent=2);print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
