@echo off
python -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
echo [OK] V7.5 dependencies installed.
echo Next: python scripts\fetch_all_pit.py
echo Then: python run_backtest.py
echo Finally: python run_robustness.py
