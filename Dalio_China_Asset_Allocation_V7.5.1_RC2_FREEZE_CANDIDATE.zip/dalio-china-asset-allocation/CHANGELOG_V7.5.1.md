# V7.5.1 Changelog

V7.5.1 does not change the V7.5 model logic or weights. It is an engineering-completeness release.

Added/recovered:
- V7.4 walk-forward engine for direct baseline comparison.
- V7.4 backtest summary, 66-month monthly results, and 132-node results.
- next_month_return.csv reference data.
- V7.5 132-node results, yearly comparison, diagnostic report, and backtest summary.
- Full V7.5 robustness evidence: scenarios, gate detail, summary, and human-readable report.
- Frozen snapshot evidence under frozen_snapshot/snapshot_20260809/.
- Explicit PIT data-generation note. unified_pit.csv is not fabricated and must be generated with fetch_all_pit.py in a network-enabled environment.

Frozen model logic remains:
- Alpha: 55% valuation + 45% fund flow.
- Risk budgets: Risk-On 80%, Neutral 55%, Risk-Off 30%.
- One-way transaction cost: 10 bps.
- V7.5 regime engine: growth/inflation/credit/policy + fast market brake + asymmetric hysteresis.


## FULL DATA patch - 2026-08-10
- Restored user-provided data.zip into data/pit/.
- Added unified_pit.csv (204,101 rows) plus six component PIT datasets.
- Preserved original data.zip under data/archive/.
- PIT ordering audit passed.
- Reproduced V7.4 and V7.5.1 132-node backtests exactly within floating-point tolerance.
- Added V7.4 diagnostic evidence and final pre-freeze audit outputs.
