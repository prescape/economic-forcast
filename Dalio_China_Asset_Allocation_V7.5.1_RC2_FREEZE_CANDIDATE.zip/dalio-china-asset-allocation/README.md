# Dalio China Asset Allocation V7.5.1-RC2 — OpenClaw Freeze Candidate

V7.5.1-RC2 is an engineering/freeze-audit release built from the recovered V7.5.1 FULL DATA package. It does **not** modify the V7.5.1 model logic, weights, regime thresholds, or default transaction cost.

## Included
- `engine/walk_forward_v75.py` — unchanged V7.5/V7.5.1 regime-engine walk-forward.
- `tests/robustness_test_v75.py` — original 39-scenario, 7-gate robustness screen.
- `tests/freeze_gate_v751_rc2.py` — unified freeze decision combining robustness with concentration/final-audit gates.
- `scripts/data_quality_gate.py` — PIT component/schema/coverage/order integrity checks.
- `scripts/fetch_*_pit.py` — macro, market, valuation, flow, policy, earnings and unified PIT fetchers.
- `scripts/leakage_audit.py` — PIT date-order audit.
- `data/pit/unified_pit.csv` — restored full PIT master archive (204,101 rows in the RC2 audit).
- `outputs/v74_output/` and `outputs/v75_output/` — baseline comparison evidence.
- `outputs/v751_rc2/` — reproducible RC2 data-quality, robustness, concentration and unified freeze outputs.
- `frozen_snapshot/V7.5.1-RC2_FREEZE-CANDIDATE_20260816/` — compact RC2 evidence snapshot.

## Install / run
Windows:
```bat
install.bat
python run_backtest.py
python run_freeze_gate.py
```

Linux/macOS/OpenClaw container:
```bash
bash install.sh
python run_backtest.py
python run_freeze_gate.py
```

Refresh PIT data only when network access is available:
```bash
python scripts/fetch_all_pit.py
```

## RC2 freeze rule
`run_freeze_gate.py` is the authoritative freeze decision. It first runs the PIT data-quality gate and then combines the original robustness evidence with concentration/final-audit evidence.

Current RC2 audit result (2026-08-16): **CONDITIONAL PASS**.

Therefore this package must remain **V7.5.1-RC2 / FREEZE-CANDIDATE**. Do not rename it `V7.5.1-FROZEN` yet. Follow `OOS_VALIDATION_PROTOCOL.md` and accumulate untouched future semi-monthly observations without changing frozen model parameters.
