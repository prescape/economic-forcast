from pathlib import Path
import subprocess, sys
root=Path(__file__).resolve().parent
cmd=[sys.executable,str(root/'engine'/'walk_forward_v74.py'),'--input',str(root/'data'/'pit'/'unified_pit.csv'),'--factors',str(root/'data'/'reference'/'V7.3_factor_panel_completed.csv'),'--returns',str(root/'data'/'reference'/'next_month_return.csv'),'--output-dir',str(root/'outputs'/'v74_output')]
raise SystemExit(subprocess.call(cmd))
