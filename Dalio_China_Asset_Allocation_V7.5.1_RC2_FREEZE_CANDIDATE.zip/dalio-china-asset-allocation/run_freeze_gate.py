from pathlib import Path
import subprocess, sys
root=Path(__file__).resolve().parent
# Data quality is a hard prerequisite.
rc=subprocess.call([sys.executable,str(root/'scripts'/'data_quality_gate.py'),'--pit-dir',str(root/'data'/'pit'),'--output',str(root/'outputs'/'v751_rc2'/'data_quality_summary.json')])
if rc!=0: raise SystemExit(rc)
raise SystemExit(subprocess.call([sys.executable,str(root/'tests'/'freeze_gate_v751_rc2.py'),'--root',str(root)]))
