# V7.5.1 Untouched OOS Validation Protocol

Purpose: validate the already-frozen V7.5.1 logic without using future observations to tune parameters.

Rules:
- Keep alpha 55% valuation + 45% fund flow unchanged.
- Keep Risk-On/Neutral/Risk-Off budgets at 80%/55%/30%.
- Keep MA120 fast brake, 20-day negative-return condition, two-confirmation upside hysteresis, and 10 bps one-way baseline cost unchanged.
- At each semi-monthly decision date, archive the as-of PIT snapshot, regime, target weights, realized next-period returns, and checksum.
- Never backfill a decision using information whose `available_date` was later than that decision.
- Do not change model parameters after observing OOS results; parameter research belongs in a separate future branch (for example V7.6).

Review cadence:
- Interim review after 12 new semi-monthly nodes.
- Stronger freeze decision after 24 new semi-monthly nodes, unless a material data/model defect is discovered earlier.

Promotion principle:
- RC2 remains FREEZE-CANDIDATE while the unified freeze gate is CONDITIONAL PASS.
- `V7.5.1-FROZEN` should be created only after untouched OOS evidence supports the model and the freeze decision is documented.
