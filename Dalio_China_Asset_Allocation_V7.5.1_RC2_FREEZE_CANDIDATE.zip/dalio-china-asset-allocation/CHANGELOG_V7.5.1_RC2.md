# V7.5.1-RC2 Changelog

RC2 is an engineering/freeze-audit release. It does **not** change strategy parameters or model logic.

Added:
- Unified freeze gate combining the existing 7 robustness gates with 9 concentration/final-audit gates.
- Data-quality hard gate for PIT component presence, schema, row/features/entities coverage, PIT ordering, numeric coverage and duplicates.
- Independent RC2 version identity and freeze manifest.
- Reproducible RC2 outputs under `outputs/v751_rc2/`.

Unchanged frozen model settings:
- Alpha: 55% valuation + 45% fund flow.
- Risk budgets: Risk-On 80%, Neutral 55%, Risk-Off 30%.
- Fast brake: CSI300 below MA120 and 20-day return < 0.
- Upside hysteresis: two consecutive semi-monthly confirmations.
- Default one-way transaction cost: 10 bps.

Policy: no parameter optimization based on RC2 audit results. If the unified result remains CONDITIONAL PASS, retain FREEZE-CANDIDATE and validate with untouched future OOS data.
