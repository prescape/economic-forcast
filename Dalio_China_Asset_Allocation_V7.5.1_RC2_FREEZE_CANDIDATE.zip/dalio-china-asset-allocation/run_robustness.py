from pathlib import Path
import subprocess, sys
root=Path(__file__).resolve().parent
cmd=[sys.executable,str(root/'tests'/'robustness_test_v75.py'),'--input',str(root/'data'/'pit'/'unified_pit.csv'),'--factors',str(root/'data'/'reference'/'V7.3_factor_panel_completed.csv'),'--v74',str(root/'outputs'/'v74_output'/'V7.4_walk_forward_132_nodes_results.csv'),'--v75-summary',str(root/'outputs'/'v75_output'/'V7.5_backtest_summary.json'),'--output-dir',str(root/'outputs'/'v75_robustness_output')]
raise SystemExit(subprocess.call(cmd))
