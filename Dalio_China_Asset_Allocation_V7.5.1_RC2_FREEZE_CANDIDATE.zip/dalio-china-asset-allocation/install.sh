#!/usr/bin/env bash
set -e
python -m pip install -r requirements.txt
echo '[OK] V7.5 dependencies installed.'
echo 'Next: python scripts/fetch_all_pit.py'
echo 'Then: python run_backtest.py'
echo 'Finally: python run_robustness.py'
