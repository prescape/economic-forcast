# V7.5 Robustness / Freeze Gate

**Grade: PASS**

Scenarios run: 39
Gates passed: 7/7
Baseline reproduced: True

## Frozen baseline
- V7.5 Sharpe: 0.3793
- V7.5 total return: 19.54%
- V7.5 max drawdown: -15.90%
- V7.4 reference Sharpe: 0.1854
- V7.4 max drawdown: -25.01%

## Gates
- PASS — G1_majority_sharpe_beats_V74: 100.0% of non-rolling stress scenarios have Sharpe > V7.4 (0.185); PASS >=70%
- PASS — G2_majority_drawdown_beats_V74: 100.0% have max drawdown better than V7.4 (-25.0%); PASS >=80%
- PASS — G3_high_cost_survival: 20/30bps must both retain positive total return and positive annualized excess vs CSI300
- PASS — G4_MA_plateau: 4/4 MA windows beat V7.4; median Sharpe=0.379; max/min=1.30; require >=3/4, median>=0.25, ratio<=2
- PASS — G5_release_lag_robust: 4/4 delay scenarios beat V7.4; min Sharpe=0.333; require >=3/4 and all >0
- PASS — G6_single_macro_ablation: Dropping any one slow macro module must keep Sharpe>0, maxDD>-30%, and annualized excess>0
- PASS — G7_rolling_start_OOS_like: 2022: V7.5 0.410 vs V7.4 0.173; 2023: V7.5 0.687 vs V7.4 0.498; 2024: V7.5 0.971 vs V7.4 0.867; require >=2/3 beat same-start V7.4 and all V7.5 Sharpes >0

## Recommendation
Freeze V7.5 as formal version

This test is a robustness screen, not a new optimization round. No scenario is selected because it has the best historical Sharpe.