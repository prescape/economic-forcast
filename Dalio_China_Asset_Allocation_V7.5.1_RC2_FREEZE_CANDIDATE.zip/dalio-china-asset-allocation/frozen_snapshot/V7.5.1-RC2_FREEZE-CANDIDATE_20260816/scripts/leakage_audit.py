#!/usr/bin/env python3
import argparse, sys
import pandas as pd

p=argparse.ArgumentParser(description='PIT leakage audit for V7.5')
p.add_argument('--input', required=True)
p.add_argument('--as-of', required=True)
a=p.parse_args()
df=pd.read_csv(a.input, low_memory=False)
required={'entity','feature','observation_date','available_date','value'}
miss=required-set(df.columns)
if miss:
    print(f'[FAIL] missing columns: {sorted(miss)}'); sys.exit(2)
asof=pd.Timestamp(a.as_of)
obs=pd.to_datetime(df['observation_date'], errors='coerce')
avail=pd.to_datetime(df['available_date'], errors='coerce')
invalid=(avail < obs).fillna(False)
future=(avail > asof).fillna(False)
print(f'rows={len(df)} as_of={asof.date()} invalid_available_before_observation={int(invalid.sum())} rows_not_yet_available={int(future.sum())}')
if invalid.any():
    print('[FAIL] available_date earlier than observation_date'); sys.exit(1)
print('[PASS] PIT date ordering valid. Rows after as-of are expected in a master archive and must be filtered by the engine.')
