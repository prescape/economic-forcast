#!/usr/bin/env python3
"""
fetch_all_pit.py — Dalio China V7.2 PIT 数据统一采集入口

依次运行：
1. fetch_macro_pit.py
2. fetch_market_pit.py
3. fetch_valuation_pit.py
4. fetch_flow_pit.py
5. fetch_policy_pit.py

然后合并为 unified_pit.csv，供 leakage_audit.py 检查。
"""
import subprocess
import sys
import shutil
from pathlib import Path
from datetime import datetime
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
PIT_DIR = BASE / "data" / "pit"
PIT_DIR.mkdir(parents=True, exist_ok=True)

TODAY = datetime.now().strftime("%Y-%m-%d")

SCRIPTS = [
    ("Macro", "scripts/fetch_macro_pit.py", "macro_pit.csv"),
    ("Market", "scripts/fetch_market_pit.py", "market_pit.csv"),
    ("Valuation", "scripts/fetch_valuation_pit.py", "valuation_pit.csv"),
    ("Flow", "scripts/fetch_flow_pit.py", "flow_pit.csv"),
    ("Policy", "scripts/fetch_policy_pit.py", "policy_pit.csv"),
    ("Earnings", "scripts/fetch_earnings_pit.py", "earnings_pit.csv"),
]


def run_script(name, script, out_csv):
    # Transactional refresh: fetch into a temporary file and only replace the
    # last known-good component after basic validation succeeds.
    final_path = PIT_DIR / out_csv
    tmp_path = PIT_DIR / (out_csv + ".tmp")
    if tmp_path.exists():
        tmp_path.unlink()
    cmd = [sys.executable, str(BASE / script), "--out", str(tmp_path)]
    print(f"\n=== [{name}] Running {' '.join(cmd)} ===")
    result = subprocess.run(cmd, capture_output=True, text=True)
    print(result.stdout)
    if result.returncode != 0:
        print(f"[ERROR] {name} failed; existing component preserved:\n{result.stderr}", file=sys.stderr)
        if tmp_path.exists(): tmp_path.unlink()
        return False
    try:
        d = pd.read_csv(tmp_path, low_memory=False)
        required = {"entity","feature","observation_date","available_date","value"}
        if d.empty or not required.issubset(d.columns):
            raise ValueError(f"invalid PIT component shape rows={len(d)} columns={list(d.columns)}")
        obs = pd.to_datetime(d["observation_date"], errors="coerce")
        av = pd.to_datetime(d["available_date"], errors="coerce")
        if obs.isna().any() or av.isna().any() or (av < obs).any():
            raise ValueError("invalid PIT dates or available_date < observation_date")
    except Exception as e:
        print(f"[ERROR] {name} validation failed; existing component preserved: {e}", file=sys.stderr)
        if tmp_path.exists(): tmp_path.unlink()
        return False
    backup = final_path.with_suffix(final_path.suffix + ".last_good")
    if final_path.exists(): shutil.copy2(final_path, backup)
    tmp_path.replace(final_path)
    return True


def merge_pit():
    files = [PIT_DIR / csv for _, _, csv in SCRIPTS]
    parts = []
    for f in files:
        if f.exists():
            parts.append(pd.read_csv(f))
    if not parts:
        print("[ERROR] No PIT files found.")
        return
    unified = pd.concat(parts, ignore_index=True)
    out = PIT_DIR / "unified_pit.csv"
    unified.to_csv(out, index=False)
    print(f"\n[OK] Unified PIT → {out} ({len(unified)} rows, {unified['entity'].nunique()} entities, {unified['feature'].nunique()} features)")


def main():
    ok = True
    for name, script, csv in SCRIPTS:
        if not run_script(name, script, csv):
            ok = False
    if ok:
        merge_pit()
        # 运行 leakage audit（用今天日期）
        audit = subprocess.run(
            [sys.executable, str(BASE / "scripts" / "leakage_audit.py"),
             "--input", str(PIT_DIR / "unified_pit.csv"),
             "--as-of", TODAY],
            capture_output=True, text=True
        )
        print("\n=== Leakage Audit ===")
        print(audit.stdout)
        if audit.returncode != 0:
            print(f"[ERROR] Leakage audit failed:\n{audit.stderr}", file=sys.stderr)
    else:
        print("\n[ERROR] Some fetchers failed, skipping merge & audit.", file=sys.stderr)


if __name__ == "__main__":
    main()
