"""V7.5 robustness / freeze-gate test.

Runs a pre-declared battery of stress tests against the frozen V7.5 regime design.
It does NOT optimize parameters or select the best scenario.

Inputs
------
--input      unified PIT archive (required)
--factors    V7.3/V7.4 completed factor panel with valuation and flow
--v74        V7.4 132-node results (used as the comparison benchmark and exact period returns)
--v75-summary optional frozen V7.5 summary for reproducibility check

Outputs
-------
robustness_scenarios.csv
robustness_gate_detail.csv
robustness_summary.json
robustness_report.md

Freeze grades
-------------
PASS             : baseline reproduces + >= 6 of 7 gates pass + no hard failure
CONDITIONAL PASS : baseline reproduces + 4-5 gates pass + no hard failure
FAIL             : baseline does not reproduce, hard failure, or <= 3 gates pass

The gates are intentionally fixed before reading stress-test results.
"""
from __future__ import annotations
import argparse, json, math
from dataclasses import dataclass, asdict, replace
from pathlib import Path
import numpy as np
import pandas as pd

ASSETS=["000300","000852","399006","000688","000016"]
RANK_POINTS=np.array([5,4,3,2,1],dtype=float)
REGIME_ALLOC={"Risk-On":0.80,"Neutral":0.55,"Risk-Off":0.30}
REGIME_LEVEL={"Risk-Off":0,"Neutral":1,"Risk-On":2}
LEVEL_REGIME={0:"Risk-Off",1:"Neutral",2:"Risk-On"}

@dataclass(frozen=True)
class Config:
    name:str="BASELINE"
    cost_bps:float=10.0
    ma_window:int=120
    up_confirm:int=2
    release_delay_days:int=0
    drop_growth:bool=False
    drop_inflation:bool=False
    drop_credit:bool=False
    drop_policy:bool=False
    drop_fast_brake:bool=False
    start_year:int=2021
    group:str="baseline"


def norm_code(x):
    s=str(x).strip()
    if s.endswith('.0') and s[:-2].isdigit(): s=s[:-2]
    if s.isdigit() and len(s)<6: s=s.zfill(6)
    return s


def perf(r, periods_per_year=24):
    r=pd.Series(r,dtype=float).replace([np.inf,-np.inf],np.nan).dropna()
    if len(r)<2: return {k:np.nan for k in ["total_return","annualized_return","annualized_volatility","sharpe","max_drawdown","win_rate"]}
    nav=(1+r).cumprod(); total=float(nav.iloc[-1]-1); yrs=len(r)/periods_per_year
    ann=float((1+total)**(1/yrs)-1) if total>-1 else -1.0
    sd=float(r.std(ddof=1)); vol=sd*np.sqrt(periods_per_year)
    sh=float(r.mean()/sd*np.sqrt(periods_per_year)) if sd>0 else np.nan
    dd=nav/nav.cummax()-1
    return {"total_return":total,"annualized_return":ann,"annualized_volatility":float(vol),"sharpe":sh,
            "max_drawdown":float(dd.min()),"win_rate":float((r>0).mean())}

class PITStore:
    def __init__(self, pit:pd.DataFrame):
        self.data={}
        keep=pit.dropna(subset=["observation_date","available_date","value"]).copy()
        for (f,e),g in keep.groupby(["feature","entity"], sort=False):
            g=g.sort_values(["observation_date","available_date"]).drop_duplicates("observation_date",keep="last")
            self.data[(str(f),str(e))]=g[["observation_date","available_date","value"]].reset_index(drop=True)
    def series(self,feature,entity,asof,delay=0):
        g=self.data.get((feature,entity))
        if g is None or g.empty:return pd.Series(dtype=float)
        eff_asof=asof-pd.Timedelta(days=int(delay)) if delay else asof
        q=g[(g.available_date<=eff_asof)&(g.observation_date<=asof)]
        if q.empty:return pd.Series(dtype=float)
        return pd.Series(q.value.to_numpy(float),index=pd.DatetimeIndex(q.observation_date))


def lastv(s): return float(s.iloc[-1]) if len(s) else np.nan

def delta_months(s,months):
    if len(s)<2:return np.nan
    cutoff=s.index[-1]-pd.DateOffset(months=months)
    p=s[s.index<=cutoff]
    return float(s.iloc[-1]-p.iloc[-1]) if len(p) else np.nan


def macro_state(store:PITStore, asof:pd.Timestamp, cfg:Config):
    delay=cfg.release_delay_days
    pmi=store.series("PMI","CN",asof,delay); cpi=store.series("CPI_yoy","CN",asof,delay)
    ppi=store.series("PPI_yoy","CN",asof,delay); m2=store.series("M2_yoy","CN",asof,delay)
    gdp=store.series("GDP_yoy","CN",asof,delay); lpr=store.series("LPR_1Y","CN",asof,delay)
    rrr=store.series("RRR_change","CN",asof,delay)
    pmi_v,pmi_d3=lastv(pmi),delta_months(pmi,3)
    cpi_v,cpi_d3=lastv(cpi),delta_months(cpi,3)
    ppi_v,ppi_d3=lastv(ppi),delta_months(ppi,3)
    m2_v,m2_d3=lastv(m2),delta_months(m2,3)

    # Growth state. If ablated, neutralize rather than invent a replacement.
    if cfg.drop_growth:
        growth_up=False; growth_weak=False
    else:
        growth_up=bool(np.isfinite(pmi_v) and np.isfinite(pmi_d3) and pmi_v>=50 and pmi_d3>=0)
        growth_weak=bool(np.isfinite(pmi_v) and np.isfinite(pmi_d3) and (pmi_v<50 or pmi_d3<=-0.5))

    if cfg.drop_inflation:
        quadrant="Mixed"
    else:
        parts=[]
        if np.isfinite(cpi_d3):parts.append(cpi_d3)
        if np.isfinite(ppi_d3):parts.append(ppi_d3/3.0)
        idir=float(np.mean(parts)) if parts else 0.0
        iu,idd=idir>0.15,idir<-0.15
        if growth_up and idd: quadrant="Goldilocks"
        elif growth_up and iu: quadrant="Reflation"
        elif growth_weak and iu: quadrant="Stagflation"
        elif growth_weak and idd: quadrant="Deflation"
        else: quadrant="Mixed"

    if cfg.drop_credit:
        credit_weak=False; credit_support=False
    else:
        credit_weak=bool(np.isfinite(m2_d3) and m2_d3<0)
        credit_support=bool(np.isfinite(m2_d3) and m2_d3>=0)

    # Policy is audited even though it cannot independently trigger Risk-On.
    policy_easing=0.0
    if not cfg.drop_policy:
        lpr_d6=delta_months(lpr,6)
        recent=rrr[rrr.index>=asof-pd.Timedelta(days=180)]
        if np.isfinite(lpr_d6): policy_easing+=0.6*np.clip(-lpr_d6/0.0025,-1,1)
        if len(recent): policy_easing+=0.4*np.clip(-float(recent.sum())/0.5,-1,1)

    close=store.series("close","000300",asof,0) # market data has no artificial macro release delay
    need=max(cfg.ma_window,61,21)
    if len(close)<need:
        ma=np.nan;r20=np.nan;r60=np.nan;below=False
    else:
        price=float(close.iloc[-1]); ma=float(close.iloc[-cfg.ma_window:].mean())
        r20=float(price/close.iloc[-21]-1); r60=float(price/close.iloc[-61]-1); below=price<ma

    desired="Neutral"
    # Slow macro layer. Policy easing is supportive context, not sufficient evidence of recovery.
    if growth_up and credit_support and (not below) and np.isfinite(r60) and r60>0:
        desired="Risk-On"
    if growth_weak and (credit_weak or quadrant=="Stagflation") and np.isfinite(r60) and r60<=0:
        desired="Risk-Off"
    # Fast brake covers publication lag.
    if (not cfg.drop_fast_brake) and below and np.isfinite(r20) and r20<0:
        desired="Risk-Off"
    return desired,quadrant,policy_easing


def apply_hysteresis(desired,up_confirm):
    cur="Neutral";count=0;prev=None;out=[]
    for des in desired:
        if REGIME_LEVEL[des]<REGIME_LEVEL[cur]:
            cur=des;count=0
        elif REGIME_LEVEL[des]>REGIME_LEVEL[cur]:
            count=count+1 if des==prev else 1
            if count>=up_confirm:
                cur=LEVEL_REGIME[min(REGIME_LEVEL[cur]+1,REGIME_LEVEL[des])];count=0
        else: count=0
        out.append(cur);prev=des
    return out


def run_scenario(cfg, store, factors, returns):
    # Always build full history first so rolling-start tests do not reset the regime state artificially.
    nodes=returns[["decision_date","as_of_date"]].copy().reset_index(drop=True)
    desired=[];quadrants=[]
    for r in nodes.itertuples(index=False):
        d,q,_=macro_state(store,r.as_of_date,cfg); desired.append(d); quadrants.append(q)
    regimes=apply_hysteresis(desired,cfg.up_confirm)

    prev_w={a:0.0 for a in ASSETS};prev_cash=1.0;rows=[]
    fp=factors.set_index(["decision_date","asset"])
    for i,r in returns.reset_index(drop=True).iterrows():
        dt=r.decision_date; reg=regimes[i];risk=REGIME_ALLOC[reg]
        alphas={}
        for a in ASSETS:
            z=fp.loc[(dt,a)]
            alphas[a]=0.55*float(z["valuation"])+0.45*float(z["flow"])
        ranked=sorted(ASSETS,key=lambda a:(alphas[a],a),reverse=True)
        raw={a:0.0 for a in ASSETS}
        for pts,a in zip(RANK_POINTS,ranked):raw[a]=risk*pts/RANK_POINTS.sum()
        if i:
            blend={a:0.5*prev_w[a]+0.5*raw[a] for a in ASSETS}; ss=sum(blend.values())
            w={a:blend[a]*risk/ss for a in ASSETS}
        else:w=raw.copy()
        cash=1-sum(w.values())
        turn=.5*(sum(abs(w[a]-prev_w[a]) for a in ASSETS)+abs(cash-prev_cash))
        cost=turn*cfg.cost_bps/10000.0
        gross=sum(w[a]*float(r[f"r_{a}"]) for a in ASSETS); net=gross-cost
        rows.append((dt,reg,quadrants[i],turn,cost,gross,net,float(r.benchmark_return)))
        prev_w=w;prev_cash=cash
    rr=pd.DataFrame(rows,columns=["decision_date","regime","quadrant","turnover","cost","gross","net","benchmark"])
    rr=rr[rr.decision_date.dt.year>=cfg.start_year].copy()
    ps=perf(rr.net); pb=perf(rr.benchmark)
    return {
        **asdict(cfg),"nodes":len(rr),
        "total_return":ps["total_return"],"annualized_return":ps["annualized_return"],"volatility":ps["annualized_volatility"],
        "sharpe":ps["sharpe"],"max_drawdown":ps["max_drawdown"],"win_rate":ps["win_rate"],
        "benchmark_total_return":pb["total_return"],"benchmark_annualized_return":pb["annualized_return"],
        "annualized_excess":ps["annualized_return"]-pb["annualized_return"],
        "mean_turnover":float(rr.turnover.mean()),"total_cost_nav_points":float(rr.cost.sum()),
        "riskoff_share":float((rr.regime=="Risk-Off").mean()),"riskon_share":float((rr.regime=="Risk-On").mean())
    }


def scenario_plan():
    b=Config()
    out=[b]
    # 1D sensitivities
    for c in [5,20,30]: out.append(replace(b,name=f"COST_{c}bps",cost_bps=c,group="cost"))
    for w in [100,150,200]: out.append(replace(b,name=f"MA_{w}",ma_window=w,group="ma_window"))
    for u in [1,3]: out.append(replace(b,name=f"UPCONF_{u}",up_confirm=u,group="up_confirm"))
    for d in [5,10,20]: out.append(replace(b,name=f"DELAY_{d}d",release_delay_days=d,group="release_delay"))
    for field,label in [("drop_growth","DROP_GROWTH"),("drop_inflation","DROP_INFLATION"),("drop_credit","DROP_CREDIT"),("drop_policy","DROP_POLICY"),("drop_fast_brake","DROP_FAST_BRAKE")]:
        out.append(replace(b,name=label,group="ablation",**{field:True}))
    for y in [2022,2023,2024]: out.append(replace(b,name=f"START_{y}",start_year=y,group="rolling_start"))
    # Cost x MA grid (excluding exact baseline duplicate)
    for c in [5,10,20,30]:
        for w in [100,120,150,200]:
            if c==10 and w==120: continue
            out.append(replace(b,name=f"GRID_COST{c}_MA{w}",cost_bps=c,ma_window=w,group="cost_ma_grid"))
    # Delay x confirmation grid (excluding exact baseline duplicate)
    for d in [0,5,10,20]:
        for u in [1,2,3]:
            if d==0 and u==2: continue
            out.append(replace(b,name=f"GRID_DELAY{d}_CONF{u}",release_delay_days=d,up_confirm=u,group="delay_confirm_grid"))
    # Deliberately harsh corners
    out += [
        replace(b,name="HARSH_COST30_DELAY20",cost_bps=30,release_delay_days=20,group="harsh"),
        replace(b,name="HARSH_COST30_MA200",cost_bps=30,ma_window=200,group="harsh"),
        replace(b,name="HARSH_DELAY20_CONF3",release_delay_days=20,up_confirm=3,group="harsh"),
        replace(b,name="HARSH_NO_BRAKE_COST20",drop_fast_brake=True,cost_bps=20,group="harsh"),
        replace(b,name="HARSH_NO_GROWTH_DELAY10",drop_growth=True,release_delay_days=10,group="harsh"),
        replace(b,name="HARSH_MA100_CONF1",ma_window=100,up_confirm=1,group="harsh"),
    ]
    # Deduplicate by all functional parameters, keep first label.
    seen=set(); uniq=[]
    for x in out:
        key=(x.cost_bps,x.ma_window,x.up_confirm,x.release_delay_days,x.drop_growth,x.drop_inflation,x.drop_credit,x.drop_policy,x.drop_fast_brake,x.start_year)
        if key not in seen: seen.add(key);uniq.append(x)
    return uniq


def gate(df,v74):
    b=df[df.name=="BASELINE"].iloc[0]
    gates=[]
    def add(name,passed,detail,mandatory=False):gates.append({"gate":name,"pass":bool(passed),"mandatory":mandatory,"detail":detail})

    # Gate 1: broad scenario superiority to full-sample V7.4 baseline.
    stress=df[df.group!="rolling_start"]
    share_sh=float((stress.sharpe>v74["sharpe"]).mean())
    add("G1_majority_sharpe_beats_V74",share_sh>=0.70,f"{share_sh:.1%} of non-rolling stress scenarios have Sharpe > V7.4 ({v74['sharpe']:.3f}); PASS >=70%")

    share_dd=float((stress.max_drawdown>v74["max_drawdown"]).mean())
    add("G2_majority_drawdown_beats_V74",share_dd>=0.80,f"{share_dd:.1%} have max drawdown better than V7.4 ({v74['max_drawdown']:.1%}); PASS >=80%")

    # Cost gate
    cost=df[df.name.isin(["COST_20bps","COST_30bps"])]
    ok=bool((cost.annualized_excess>0).all() and (cost.total_return>0).all())
    add("G3_high_cost_survival",ok,"20/30bps must both retain positive total return and positive annualized excess vs CSI300")

    # MA stable plateau
    ma=df[df.name.isin(["BASELINE","MA_100","MA_150","MA_200"])]
    count=int((ma.sharpe>v74["sharpe"]).sum())
    ratio=float(ma.sharpe.max()/ma.sharpe.min()) if ma.sharpe.min()>0 else np.inf
    ok=(count>=3 and ma.sharpe.median()>=0.25 and ratio<=2.0)
    add("G4_MA_plateau",ok,f"{count}/4 MA windows beat V7.4; median Sharpe={ma.sharpe.median():.3f}; max/min={ratio:.2f}; require >=3/4, median>=0.25, ratio<=2")

    # Release lag robustness
    dl=df[df.name.isin(["BASELINE","DELAY_5d","DELAY_10d","DELAY_20d"])]
    ok=bool((dl.sharpe>v74["sharpe"]).sum()>=3 and dl.sharpe.min()>0)
    add("G5_release_lag_robust",ok,f"{int((dl.sharpe>v74['sharpe']).sum())}/4 delay scenarios beat V7.4; min Sharpe={dl.sharpe.min():.3f}; require >=3/4 and all >0")

    # Slow macro module ablation; fast brake treated separately because it is a safety layer, not a slow macro input.
    abl=df[df.name.isin(["DROP_GROWTH","DROP_INFLATION","DROP_CREDIT","DROP_POLICY"])]
    ok=bool((abl.sharpe>0).all() and (abl.max_drawdown>-0.30).all() and (abl.annualized_excess>0).all())
    add("G6_single_macro_ablation",ok,"Dropping any one slow macro module must keep Sharpe>0, maxDD>-30%, and annualized excess>0")

    # Rolling starts compared with V7.4 on the same subperiod.
    roll=df[df.group=="rolling_start"]
    wins=[];details=[]
    for _,r in roll.iterrows():
        y=int(r.start_year); vv=v74.get(f"start_{y}_sharpe",np.nan)
        win=bool(np.isfinite(vv) and r.sharpe>vv and r.sharpe>0)
        wins.append(win);details.append(f"{y}: V7.5 {r.sharpe:.3f} vs V7.4 {vv:.3f}")
    ok=sum(wins)>=2 and all(roll.sharpe>0)
    add("G7_rolling_start_OOS_like",ok,"; ".join(details)+"; require >=2/3 beat same-start V7.4 and all V7.5 Sharpes >0")
    return pd.DataFrame(gates)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input",default="unified_pit.csv")
    ap.add_argument("--factors",default="V7.3_factor_panel_completed.csv")
    ap.add_argument("--v74",default="v74_output/V7.4_walk_forward_132_nodes_results.csv")
    ap.add_argument("--v75-summary",default="v75_output/V7.5_backtest_summary.json")
    ap.add_argument("--output-dir",default="v75_robustness_output")
    args=ap.parse_args(); out=Path(args.output_dir);out.mkdir(parents=True,exist_ok=True)

    pit=pd.read_csv(args.input,low_memory=False)
    pit["entity"]=pit.entity.map(norm_code);pit["observation_date"]=pd.to_datetime(pit.observation_date,errors="coerce")
    pit["available_date"]=pd.to_datetime(pit.available_date,errors="coerce");pit["value"]=pd.to_numeric(pit.value,errors="coerce")
    store=PITStore(pit)
    f=pd.read_csv(args.factors);f["decision_date"]=pd.to_datetime(f.decision_date);f["asset"]=f.asset.map(norm_code)
    r74=pd.read_csv(args.v74);r74["decision_date"]=pd.to_datetime(r74.decision_date);r74["as_of_date"]=pd.to_datetime(r74.as_of_date)

    # V7.4 reference metrics, including same-start comparisons.
    v74ref=perf(r74.net_return)
    for y in [2022,2023,2024]:v74ref[f"start_{y}_sharpe"]=perf(r74[r74.decision_date.dt.year>=y].net_return)["sharpe"]

    plan=scenario_plan(); rows=[]
    for i,cfg in enumerate(plan,1):
        print(f"[{i:02d}/{len(plan)}] {cfg.name}")
        rows.append(run_scenario(cfg,store,f,r74))
    df=pd.DataFrame(rows)

    # Baseline reproducibility is a hard prerequisite.
    baseline=df[df.name=="BASELINE"].iloc[0]
    expected=None
    p=Path(args.v75_summary)
    if p.exists():
        expected=json.load(open(p,encoding="utf-8"))
        # Supports both earlier detailed summary and production summary shapes.
        if "V7.5" in expected: exp_sh=expected["V7.5"]["sharpe"];exp_ret=expected["V7.5"]["total_return"]
        elif "net" in expected: exp_sh=expected["net"]["sharpe"];exp_ret=expected["net"]["total_return"]
        else: exp_sh=expected.get("sharpe",np.nan);exp_ret=expected.get("net_total_return",np.nan)
        reproducible=(abs(baseline.sharpe-exp_sh)<1e-8 and abs(baseline.total_return-exp_ret)<1e-8)
    else:
        exp_sh=exp_ret=np.nan; reproducible=True

    gd=gate(df,v74ref)
    passed=int(gd["pass"].sum());hard=[]
    if not reproducible: hard.append("Baseline V7.5 does not reproduce frozen summary")
    # Hard survival checks.
    c30=df[df.name=="COST_30bps"].iloc[0]
    if c30.annualized_excess<=0: hard.append("30bps annualized excess <= 0")
    if baseline.max_drawdown<=-0.30: hard.append("Baseline max drawdown <= -30%")

    if hard or passed<=3: grade="FAIL"
    elif passed>=6: grade="PASS"
    else: grade="CONDITIONAL PASS"

    df.to_csv(out/"robustness_scenarios.csv",index=False)
    gd.to_csv(out/"robustness_gate_detail.csv",index=False)
    summary={
        "version":"V7.5 robustness freeze gate","grade":grade,"gates_passed":passed,"gates_total":len(gd),
        "baseline_reproduced":bool(reproducible),"expected_sharpe":float(exp_sh) if np.isfinite(exp_sh) else None,
        "actual_sharpe":float(baseline.sharpe),"expected_total_return":float(exp_ret) if np.isfinite(exp_ret) else None,
        "actual_total_return":float(baseline.total_return),"V7.4_reference":v74ref,"hard_failures":hard,
        "scenario_count":len(df),"scenario_groups":df.group.value_counts().to_dict(),
        "stress_sharpe_median":float(df[df.group!="rolling_start"].sharpe.median()),
        "stress_sharpe_p10":float(df[df.group!="rolling_start"].sharpe.quantile(.10)),
        "stress_maxdd_median":float(df[df.group!="rolling_start"].max_drawdown.median()),
        "freeze_recommendation":"Freeze V7.5 as formal version" if grade=="PASS" else ("Keep V7.5 as candidate; freeze only after resolving failed gates" if grade=="CONDITIONAL PASS" else "Do not freeze V7.5")
    }
    json.dump(summary,open(out/"robustness_summary.json","w",encoding="utf-8"),ensure_ascii=False,indent=2)

    # Human-readable report
    lines=["# V7.5 Robustness / Freeze Gate", "", f"**Grade: {grade}**", "", f"Scenarios run: {len(df)}", f"Gates passed: {passed}/{len(gd)}", f"Baseline reproduced: {reproducible}", "",
           "## Frozen baseline", f"- V7.5 Sharpe: {baseline.sharpe:.4f}", f"- V7.5 total return: {baseline.total_return:.2%}", f"- V7.5 max drawdown: {baseline.max_drawdown:.2%}",
           f"- V7.4 reference Sharpe: {v74ref['sharpe']:.4f}", f"- V7.4 max drawdown: {v74ref['max_drawdown']:.2%}", "", "## Gates"]
    for _,x in gd.iterrows(): lines.append(f"- {'PASS' if bool(x['pass']) else 'FAIL'} — {x['gate']}: {x['detail']}")
    if hard:
        lines += ["","## Hard failures"]+[f"- {x}" for x in hard]
    lines += ["","## Recommendation",summary["freeze_recommendation"],"",
              "This test is a robustness screen, not a new optimization round. No scenario is selected because it has the best historical Sharpe."]
    (out/"robustness_report.md").write_text("\n".join(lines),encoding="utf-8")
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=="__main__":main()
