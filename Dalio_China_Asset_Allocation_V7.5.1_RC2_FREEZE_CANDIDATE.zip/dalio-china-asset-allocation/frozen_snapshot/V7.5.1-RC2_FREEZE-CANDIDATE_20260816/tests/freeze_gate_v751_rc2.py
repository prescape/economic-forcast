#!/usr/bin/env python3
"""Unified V7.5.1-RC2 freeze decision.
Combines the existing 7 robustness gates with concentration/final-audit evidence.
No model parameters are optimized or changed.
"""
from __future__ import annotations
import argparse, json, subprocess, sys
from pathlib import Path
import numpy as np, pandas as pd

def perf(r, ppy=24):
    r=pd.Series(r,dtype=float).dropna(); nav=(1+r).cumprod(); total=float(nav.iloc[-1]-1)
    sd=float(r.std(ddof=1)); sharpe=float(r.mean()/sd*np.sqrt(ppy)) if sd>0 else np.nan
    dd=nav/nav.cummax()-1
    return {'total_return':total,'sharpe':sharpe,'max_drawdown':float(dd.min())}

def remove_top_adv(v74,v75,k,monthly=False):
    a=v74[['decision_date','net_return']].rename(columns={'net_return':'r74'}).copy()
    b=v75[['decision_date','net_return']].rename(columns={'net_return':'r751'}).copy()
    a['decision_date']=pd.to_datetime(a.decision_date); b['decision_date']=pd.to_datetime(b.decision_date)
    m=a.merge(b,on='decision_date'); m['adv']=m.r751-m.r74
    if monthly:
        m['bucket']=m.decision_date.dt.to_period('M').astype(str)
        top=m.groupby('bucket').adv.sum().nlargest(k).index
        keep=~m.bucket.isin(top)
    else:
        top=m.nlargest(k,'adv').index; keep=~m.index.isin(top)
    p74,p75=perf(m.loc[keep,'r74']),perf(m.loc[keep,'r751'])
    return {'v74_total_return':p74['total_return'],'v751_total_return':p75['total_return'],'total_return_advantage':p75['total_return']-p74['total_return'],'v74_sharpe':p74['sharpe'],'v751_sharpe':p75['sharpe'],'sharpe_advantage':p75['sharpe']-p74['sharpe']}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',default='.'); args=ap.parse_args(); root=Path(args.root).resolve()
    rob_out=root/'outputs'/'v751_rc2'/'robustness'; rob_out.mkdir(parents=True,exist_ok=True)
    cmd=[sys.executable,str(root/'tests'/'robustness_test_v75.py'),'--input',str(root/'data/pit/unified_pit.csv'),'--factors',str(root/'data/reference/V7.3_factor_panel_completed.csv'),'--v74',str(root/'outputs/v74_output/V7.4_walk_forward_132_nodes_results.csv'),'--v75-summary',str(root/'outputs/v75_output/V7.5_backtest_summary.json'),'--output-dir',str(rob_out)]
    rc=subprocess.call(cmd)
    if rc!=0: raise SystemExit(rc)
    rob=json.load(open(rob_out/'robustness_summary.json',encoding='utf-8'))
    gd=pd.read_csv(rob_out/'robustness_gate_detail.csv')
    v74=pd.read_csv(root/'outputs/v74_output/V7.4_walk_forward_132_nodes_results.csv')
    v75=pd.read_csv(root/'outputs/v75_output/V7.5_walk_forward_132_nodes_results.csv')
    v74['decision_date']=pd.to_datetime(v74.decision_date); v75['decision_date']=pd.to_datetime(v75.decision_date)
    m=v74[['decision_date','net_return','regime']].rename(columns={'net_return':'r74','regime':'reg74'}).merge(v75[['decision_date','net_return','regime']].rename(columns={'net_return':'r751','regime':'reg751'}),on='decision_date')
    m['adv']=m.r751-m.r74
    wins=int((m.adv>1e-12).sum()); losses=int((m.adv<-1e-12).sum()); ties=len(m)-wins-losses
    years=m.assign(year=m.decision_date.dt.year).groupby('year').adv.sum()
    broad_2224=all(float(years.get(y,0))>0 for y in [2022,2023,2024])
    reg=m.groupby(['reg74','reg751']).adv.sum(); main_mech=float(reg.get(('Neutral','Risk-Off'),0))>0 and reg.get(('Neutral','Risk-Off'),0)==reg.max()
    assets=[]
    for a in ['000300','000852','399006','000688','000016']:
        x=(v75[f'w_{a}']*v75[f'r_{a}']-v74[f'w_{a}']*v74[f'r_{a}']).sum(); assets.append(float(x))
    asset_breadth=all(x>0 for x in assets)
    n1,n3,n5=[remove_top_adv(v74,v75,k,False) for k in [1,3,5]]
    mo3,mo5=[remove_top_adv(v74,v75,k,True) for k in [3,5]]
    base74,base75=perf(v74.net_return),perf(v75.net_return)
    extra=[
      {'gate':'C1_full_sample_outperformance','pass':base75['total_return']>base74['total_return'] and base75['sharpe']>base74['sharpe'],'detail':f"return {base75['total_return']:.2%} vs {base74['total_return']:.2%}; Sharpe {base75['sharpe']:.3f} vs {base74['sharpe']:.3f}"},
      {'gate':'C2_2022_2024_broad_improvement','pass':broad_2224,'detail':'; '.join(f'{y}:{years.get(y,0):.2%}' for y in [2022,2023,2024])},
      {'gate':'C3_regime_mechanism_consistent','pass':main_mech,'detail':f"Neutral->Risk-Off aggregate advantage={reg.get(('Neutral','Risk-Off'),0):.2%}"},
      {'gate':'C4_asset_breadth','pass':asset_breadth,'detail':'asset contribution advantages='+','.join(f'{x:.2%}' for x in assets)},
      {'gate':'C5_remove_top1_node','pass':n1['total_return_advantage']>0,'detail':f"advantage={n1['total_return_advantage']:.2%}"},
      {'gate':'C6_remove_top3_nodes','pass':n3['total_return_advantage']>0,'detail':f"advantage={n3['total_return_advantage']:.2%}"},
      {'gate':'C7_remove_top5_nodes','pass':n5['total_return_advantage']>0,'detail':f"advantage={n5['total_return_advantage']:.2%}"},
      {'gate':'C8_remove_top3_months','pass':mo3['total_return_advantage']>0,'detail':f"advantage={mo3['total_return_advantage']:.2%}"},
      {'gate':'C9_remove_top5_months','pass':mo5['total_return_advantage']>0,'detail':f"advantage={mo5['total_return_advantage']:.2%}"},
    ]
    # Concentration failures cap an otherwise PASS robustness result at CONDITIONAL PASS.
    conc_pass=sum(x['pass'] for x in extra); robust_pass=int(gd['pass'].sum())
    hard=list(rob.get('hard_failures',[]))
    if hard or rob['grade']=='FAIL' or conc_pass<=4: grade='FAIL'
    elif rob['grade']=='PASS' and conc_pass==len(extra): grade='PASS'
    else: grade='CONDITIONAL PASS'
    allg=pd.concat([gd[['gate','pass','detail']],pd.DataFrame(extra)],ignore_index=True)
    allg.to_csv(root/'outputs/v751_rc2/unified_freeze_gates.csv',index=False)
    conc=pd.DataFrame([
      {'remove_type':'node','remove_top_k':1,**n1},{'remove_type':'node','remove_top_k':3,**n3},{'remove_type':'node','remove_top_k':5,**n5},
      {'remove_type':'month','remove_top_k':3,**mo3},{'remove_type':'month','remove_top_k':5,**mo5},
    ]); conc.to_csv(root/'outputs/v751_rc2/concentration_stress.csv',index=False)
    summary={'version':'V7.5.1-RC2 unified freeze gate','grade':grade,'robustness_grade':rob['grade'],'robustness_gates_passed':robust_pass,'robustness_gates_total':len(gd),'concentration_audit_passed':conc_pass,'concentration_audit_total':len(extra),'combined_gates_passed':int(allg['pass'].sum()),'combined_gates_total':len(allg),'wins':wins,'losses':losses,'ties':ties,'baseline_v74':base74,'baseline_v751':base75,'hard_failures':hard,'freeze_recommendation':'Eligible for V7.5.1-FROZEN only after untouched OOS validation' if grade=='PASS' else ('Keep as V7.5.1 FREEZE-CANDIDATE; do not change frozen model parameters' if grade=='CONDITIONAL PASS' else 'Do not freeze')}
    (root/'outputs/v751_rc2/unified_freeze_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,default=lambda o: o.item() if hasattr(o,'item') else str(o)),encoding='utf-8')
    report=['# V7.5.1-RC2 Unified Freeze Gate','',f"**Grade: {grade}**",'',f"Robustness: {robust_pass}/{len(gd)} ({rob['grade']})",f"Concentration/final audit: {conc_pass}/{len(extra)}",f"Combined: {summary['combined_gates_passed']}/{summary['combined_gates_total']}",f"Node record: {wins} wins / {losses} losses / {ties} ties",'', '## Gates']+[f"- {'PASS' if bool(x['pass']) else 'FAIL'} — {x['gate']}: {x['detail']}" for _,x in allg.iterrows()]+['','## Recommendation',summary['freeze_recommendation'],'','No model weights, risk budgets, MA window, transaction cost baseline, fast-brake logic, or hysteresis parameters were optimized in RC2.']
    (root/'outputs/v751_rc2/unified_freeze_report.md').write_text('\n'.join(report),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2,default=lambda o: o.item() if hasattr(o,'item') else str(o)))
    raise SystemExit(0 if grade!='FAIL' else 2)
if __name__=='__main__': main()
