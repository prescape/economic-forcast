# V7.5.1-RC2 Unified Freeze Gate

**Grade: CONDITIONAL PASS**

Robustness: 7/7 (PASS)
Concentration/final audit: 7/9
Combined: 14/16
Node record: 68 wins / 63 losses / 1 ties

## Gates
- PASS — G1_majority_sharpe_beats_V74: 100.0% of non-rolling stress scenarios have Sharpe > V7.4 (0.185); PASS >=70%
- PASS — G2_majority_drawdown_beats_V74: 100.0% have max drawdown better than V7.4 (-25.0%); PASS >=80%
- PASS — G3_high_cost_survival: 20/30bps must both retain positive total return and positive annualized excess vs CSI300
- PASS — G4_MA_plateau: 4/4 MA windows beat V7.4; median Sharpe=0.379; max/min=1.30; require >=3/4, median>=0.25, ratio<=2
- PASS — G5_release_lag_robust: 4/4 delay scenarios beat V7.4; min Sharpe=0.333; require >=3/4 and all >0
- PASS — G6_single_macro_ablation: Dropping any one slow macro module must keep Sharpe>0, maxDD>-30%, and annualized excess>0
- PASS — G7_rolling_start_OOS_like: 2022: V7.5 0.410 vs V7.4 0.173; 2023: V7.5 0.687 vs V7.4 0.498; 2024: V7.5 0.971 vs V7.4 0.867; require >=2/3 beat same-start V7.4 and all V7.5 Sharpes >0
- PASS — C1_full_sample_outperformance: return 19.54% vs 8.62%; Sharpe 0.379 vs 0.185
- PASS — C2_2022_2024_broad_improvement: 2022:4.30%; 2023:4.62%; 2024:3.11%
- PASS — C3_regime_mechanism_consistent: Neutral->Risk-Off aggregate advantage=7.69%
- PASS — C4_asset_breadth: asset contribution advantages=3.14%,0.89%,2.47%,1.49%,0.76%
- PASS — C5_remove_top1_node: advantage=7.45%
- PASS — C6_remove_top3_nodes: advantage=1.48%
- FAIL — C7_remove_top5_nodes: advantage=-2.72%
- PASS — C8_remove_top3_months: advantage=0.52%
- FAIL — C9_remove_top5_months: advantage=-6.04%

## Recommendation
Keep as V7.5.1 FREEZE-CANDIDATE; do not change frozen model parameters

No model weights, risk budgets, MA window, transaction cost baseline, fast-brake logic, or hysteresis parameters were optimized in RC2.